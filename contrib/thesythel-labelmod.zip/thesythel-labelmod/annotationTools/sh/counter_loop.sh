#!/bin/sh
while ./anno_count.sh; do
    sleep 1m
done
