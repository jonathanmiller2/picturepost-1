package com.citizapps.dew;

import java.util.HashMap;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.provider.LiveFolders;
import android.text.TextUtils;

import com.citizapps.dew.model.ImageRecord;
import com.citizapps.dew.model.ImageRecord.Images;

public class ImageRecordProvider extends ContentProvider {
  private static final String LOG_TAG = "ImageRecordProvider";

  public static final String DATABASE_NAME = "dew.db";
  private static final int DATABASE_VERSION = 2;
  private static final String IMAGES_TABLE_NAME = "images";

  private static HashMap<String, String> sImagesProjectionMap;
  private static HashMap<String, String> sLiveFolderProjectionMap;

  private static final int IMAGES = 1;
  private static final int IMAGE_ID = 2;
  private static final int LIVE_FOLDER_IMAGES= 3;

  private static final UriMatcher sUriMatcher;

  /**
   * This class helps open, create, and upgrade the database file.
   */
  private static class DatabaseHelper extends SQLiteOpenHelper {
    private final static String LOG_TAG = "DatabaseHelper";
    
    public static void log(String s) {
      DEW.getDEW().log(LOG_TAG, s);
    }

    DatabaseHelper(Context context) {
      super(context, DATABASE_NAME, null, DATABASE_VERSION);
      // log("Inside DatabaseHelper constructor");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
      // log(" ######################    Creating SQLite database: " + db.getPath() + " ##############################");
      db.execSQL("CREATE TABLE " + IMAGES_TABLE_NAME + " ("
          + Images._ID + " INTEGER PRIMARY KEY,"
          + Images.FILE_NAME_AND_PATH + " TEXT,"
          + Images.POST_ID + " INTEGER,"
          + Images.PICTURE_SET_ID + " INTEGER,"
          + Images.PICTURE_ID + " INTEGER,"
          + Images.PICTURE_ORIENTATION + " TEXT,"
          + Images.PICTURE_SIZE + " TEXT,"
          + Images.RECORD_CREATE_TIME + " Text,"
          + Images.THUMBNAIL + " BLOB"
          + ");");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
      // log("Upgrading database from version " + oldVersion + " to " + 
      //            newVersion + ", which will destroy all old data");
      db.execSQL("DROP TABLE IF EXISTS " + IMAGES_TABLE_NAME);
      onCreate(db);
    }
  }

  private DatabaseHelper mOpenHelper;

  @Override
  public boolean onCreate() {
    // log("Inside ImageRecordProvider onCreate()");
      mOpenHelper = new DatabaseHelper(getContext());
      return true;
  }

  @Override
  public Cursor query(Uri uri, 
                      String[] projection, 
                      String selection, 
                      String[] selectionArgs,
                      String sortOrder) {
    // log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Inside my own query function @@@@@@@@@@@@@@@@@@@@@@@@@@@");
    SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
    qb.setTables(IMAGES_TABLE_NAME);

    switch (sUriMatcher.match(uri)) {
      case IMAGES:
          qb.setProjectionMap(sImagesProjectionMap);
          break;

      case IMAGE_ID:
          qb.setProjectionMap(sImagesProjectionMap);
          qb.appendWhere(Images._ID + "=" + uri.getPathSegments().get(1));
          break;

      case LIVE_FOLDER_IMAGES:
          qb.setProjectionMap(sLiveFolderProjectionMap);
          break;

      default:
          throw new IllegalArgumentException("Unknown URI " + uri);
    }

      // If no sort order is specified use the default
      String orderBy;
      if (TextUtils.isEmpty(sortOrder)) {
          orderBy = ImageRecord.Images.DEFAULT_SORT_ORDER;
      } else {
          orderBy = sortOrder;
      }

      // Get the database and run the query
      SQLiteDatabase db = mOpenHelper.getReadableDatabase();
      Cursor c = qb.query(db, projection, selection, selectionArgs, null, null, orderBy);

      // Tell the cursor what uri to watch, so it knows when its source data changes
      c.setNotificationUri(getContext().getContentResolver(), uri);
      return c;
  }

  @Override
  public String getType(Uri uri) {
      switch (sUriMatcher.match(uri)) {
      case IMAGES:
      case LIVE_FOLDER_IMAGES:
          return Images.CONTENT_TYPE;
      case IMAGE_ID:
          return Images.CONTENT_ITEM_TYPE;
      default:
          throw new IllegalArgumentException("Unknown URI " + uri);
      }
  }

  @Override
  public Uri insert(Uri uri, ContentValues initialValues) {
    // Validate the requested uri
    if (sUriMatcher.match(uri) != IMAGES) {
      throw new IllegalArgumentException("Unknown URI " + uri);
    }

    ContentValues values;
    if (initialValues != null) {
      values = new ContentValues(initialValues);
    } else {
      values = new ContentValues();
    }

    Long now = Long.valueOf(System.currentTimeMillis());

    // Make sure that the fields are all set
    if (values.containsKey(ImageRecord.Images.RECORD_CREATE_TIME) == false) {
      values.put(ImageRecord.Images.RECORD_CREATE_TIME, now);
    }

    if (values.containsKey(ImageRecord.Images.PICTURE_ORIENTATION) == false) {
      values.put(ImageRecord.Images.PICTURE_ORIENTATION, "");
    }
    
    if (values.containsKey(ImageRecord.Images.PICTURE_SIZE) == false) {
      values.put(ImageRecord.Images.PICTURE_SIZE, "");
    }

    if (values.containsKey(ImageRecord.Images.POST_ID) == false) {
      values.put(ImageRecord.Images.POST_ID, -1);
    }

    if (values.containsKey(ImageRecord.Images.PICTURE_SET_ID) == false) {
      values.put(ImageRecord.Images.PICTURE_SET_ID, -1);
    }

    if (values.containsKey(ImageRecord.Images.FILE_NAME_AND_PATH) == false) {
      values.put(ImageRecord.Images.FILE_NAME_AND_PATH, "");
    }

    if (values.containsKey(ImageRecord.Images.PICTURE_ID) == false) {
      values.put(ImageRecord.Images.PICTURE_ID, -1);
    }
      
    SQLiteDatabase db = mOpenHelper.getWritableDatabase();
    long rowId = db.insert(IMAGES_TABLE_NAME, ImageRecord.Images.PICTURE_ORIENTATION, values);
    if (rowId > 0) {
      Uri imageUri = ContentUris.withAppendedId(ImageRecord.Images.CONTENT_URI, rowId);
      getContext().getContentResolver().notifyChange(imageUri, null);
      return imageUri;
    }

    throw new SQLException("Failed to insert row into " + uri);
  }

  @Override
  public int delete(Uri uri, String where, String[] whereArgs) {
      SQLiteDatabase db = mOpenHelper.getWritableDatabase();
      int count;
      switch (sUriMatcher.match(uri)) {
      case IMAGES:
          count = db.delete(IMAGES_TABLE_NAME, where, whereArgs);
          break;

      case IMAGE_ID:
          String imageId = uri.getPathSegments().get(1);
          count = db.delete(IMAGES_TABLE_NAME, Images._ID + "=" + imageId
                  + (!TextUtils.isEmpty(where) ? " AND (" + where + ')' : ""), whereArgs);
          break;

      default:
          throw new IllegalArgumentException("Unknown URI " + uri);
      }

      getContext().getContentResolver().notifyChange(uri, null);
      return count;
  }

  @Override
  public int update(Uri uri, ContentValues values, String where, String[] whereArgs) {
      SQLiteDatabase db = mOpenHelper.getWritableDatabase();
      int count;
      switch (sUriMatcher.match(uri)) {
      case IMAGES:
          count = db.update(IMAGES_TABLE_NAME, values, where, whereArgs);
          break;

      case IMAGE_ID:
          String imageId = uri.getPathSegments().get(1);
          count = db.update(IMAGES_TABLE_NAME, values, Images._ID + "=" + imageId
                  + (!TextUtils.isEmpty(where) ? " AND (" + where + ')' : ""), whereArgs);
          break;

      default:
          throw new IllegalArgumentException("Unknown URI " + uri);
      }

      getContext().getContentResolver().notifyChange(uri, null);
      return count;
  }

  static {
      sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
      sUriMatcher.addURI(ImageRecord.AUTHORITY, "images", IMAGES);
      sUriMatcher.addURI(ImageRecord.AUTHORITY, "images/#", IMAGE_ID);
      sUriMatcher.addURI(ImageRecord.AUTHORITY, "live_folders/dewimages", LIVE_FOLDER_IMAGES);

      sImagesProjectionMap = new HashMap<String, String>();
      sImagesProjectionMap.put(Images._ID, Images._ID);
      sImagesProjectionMap.put(Images.FILE_NAME_AND_PATH, Images.FILE_NAME_AND_PATH);
      sImagesProjectionMap.put(Images.POST_ID, Images.POST_ID);
      sImagesProjectionMap.put(Images.PICTURE_SET_ID, Images.PICTURE_SET_ID);
      sImagesProjectionMap.put(Images.PICTURE_ID, Images.PICTURE_ID);
      sImagesProjectionMap.put(Images.PICTURE_ORIENTATION, Images.PICTURE_ORIENTATION);
      sImagesProjectionMap.put(Images.PICTURE_SIZE, Images.PICTURE_SIZE);
      sImagesProjectionMap.put(Images.RECORD_CREATE_TIME, Images.RECORD_CREATE_TIME);
      sImagesProjectionMap.put(Images.THUMBNAIL, Images.THUMBNAIL);

      // Support for Live Folders.
      sLiveFolderProjectionMap = new HashMap<String, String>();
      sLiveFolderProjectionMap.put(LiveFolders._ID, Images._ID + " AS " + LiveFolders._ID);
      sLiveFolderProjectionMap.put(LiveFolders.NAME, Images.PICTURE_ID + " AS " + LiveFolders.NAME);
      // Add more columns here for more robust Live Folders.
  }
}
