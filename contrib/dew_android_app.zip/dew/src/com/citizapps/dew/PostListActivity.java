package com.citizapps.dew;

import java.io.InputStream;
import java.util.ArrayList;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.citizapps.dew.io.PictureFileHandling;
import com.citizapps.dew.model.PicturePost;

public class PostListActivity extends ListActivity {
  private final static String LOG_TAG = "PostListActivity";
  
  private String picturePostHost = null;
  private ProgressDialog pDiag = null;
  
  static final int GET_LIST_FAILED_GO_BACK = 0;
  
  public static void log(String msg) {
    DEW.getDEW().log(LOG_TAG, msg);
  }
  
  protected Dialog onCreateDialog(int id) {
    log("Ok, I'm going a chance to create my own dialog, id=" + id);
    Dialog dialog;
    switch (id) {
    case GET_LIST_FAILED_GO_BACK:
      AlertDialog.Builder builder = new AlertDialog.Builder(this);
      builder.setMessage("Failed to retrieve post list.  Check your internet connection and try again.");
      builder.setCancelable(false);
      builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User clicked 'Ok' on the message box");
          PostListActivity.this.finish();
        }
      });
      AlertDialog alert = builder.create();
      dialog = alert;
      break;
    default:
      dialog = null;
    }
    return dialog;
  }
  
  
  private class RetrievePostListTask extends AsyncTask<String, Void, ArrayList<PicturePost>> {
    protected ArrayList<PicturePost> doInBackground(String... urls) {
      ArrayList<PicturePost> returnValue = null;      
      try {
        returnValue = PictureFileHandling.getAllPicturePosts(urls[0]);
      } catch (Exception e) {
        e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
      }
      return returnValue;
    }

    protected void onProgressUpdate() {
      // setProgressPercent(progress[0]);
    }

    protected void onPostExecute(ArrayList<PicturePost> picturePostList) {
      try {
        pDiag.cancel();
        if (picturePostList == null) {
          showDialog(GET_LIST_FAILED_GO_BACK);
        } else {
          ListView lv = getListView();
          lv.setAdapter(new ArrayAdapter<PicturePost>(PostListActivity.this, R.layout.postlist, picturePostList));
        }
      } catch (Exception e) {
        e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
      }
    }
  }
  
  private class ReadPostListTask extends AsyncTask<InputStream, Void, ArrayList<PicturePost>> {
    protected ArrayList<PicturePost> doInBackground(InputStream... streams) {
      ArrayList<PicturePost> returnValue = null;
      try {
        returnValue = PictureFileHandling.readPostFile(streams[0]);
      } catch (Exception e) {
        e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
      }
      return returnValue;
    }

    protected void onProgressUpdate() {
      // setProgressPercent(progress[0]);
    }

    protected void onPostExecute(ArrayList<PicturePost> picturePostList) {
      try {
        ListView lv = getListView();
        lv.setAdapter(new ArrayAdapter<PicturePost>(PostListActivity.this, R.layout.postlist, picturePostList));
      } catch (Exception e) {
        e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
      }
    }
  }

  
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    // setListAdapter(new ArrayAdapter<String>(this, R.layout.postlist, COUNTRIES));
    
    picturePostHost = DEW.getDEW().getPicturePostHost();

    final ListView lv = getListView();
    lv.setTextFilterEnabled(true);

    lv.setOnItemClickListener(new OnItemClickListener() {
      public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        
        PicturePost post = (PicturePost) lv.getItemAtPosition(position);
        log("Here's the PicturePost: " + post.toString());
        
        DEW.getDEW().setPostID((Integer) post.postAttributeMap.get("postId"));
        DEW.getDEW().setCurrentPicturePost(post);
        Intent viewPostActivity = new Intent(getBaseContext(),PostViewActivity.class);
        startActivity(viewPostActivity);    
        
        // if (PicPostCamera.getSingleton() != null) {
        //   PicPostCamera.getSingleton().setShouldFetchImages(true);
        // }
        
        /*
        System.out.println("Here's what we're sending as intent data: " + url);
        Uri uri = Uri.parse(url);
        Intent takePictureActivity = new Intent(getBaseContext(), PicPostCamera.class);
        takePictureActivity.setData(uri);
        startActivity(takePictureActivity);
        */
      }
    });
    
    String url = picturePostHost + "/app/GetPostList?orderBy=name&includePosts=all";
    new RetrievePostListTask().execute(url);
    
    pDiag = ProgressDialog.show(this, "Retrieving Post List", "Please wait while post list is retrieved", true, true);
    
    // InputStream inputStream = getResources().openRawResource(R.raw.get_post_list);
    // new ReadPostListTask().execute(inputStream);
  }
  
  
  /* (non-Javadoc)
   * @see android.app.Activity#onDestroy()
   */
  @Override
  protected void onDestroy() {
    // TODO Auto-generated method stub
    super.onDestroy();
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onPause()
   */
  @Override
  protected void onPause() {
    // TODO Auto-generated method stub
    super.onPause();
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onResume()
   */
  @Override
  protected void onResume() {
    // TODO Auto-generated method stub
    super.onResume();
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onStart()
   */
  @Override
  protected void onStart() {
    // TODO Auto-generated method stub
    super.onStart();
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onStop()
   */
  @Override
  protected void onStop() {
    // TODO Auto-generated method stub
    super.onStop();
  }
  
}
