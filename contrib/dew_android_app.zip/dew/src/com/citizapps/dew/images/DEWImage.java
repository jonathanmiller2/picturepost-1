package com.citizapps.dew.images;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.citizapps.dew.DEW;

public class DEWImage {
	private String fullImageFileName = null;
	
	private Bitmap screenImage = null;
	private Bitmap thumbImage = null;
	
	private boolean uploaded = false;
	private int postID;
	private int pictureSetID;
	
	private boolean cached = false;
	private String cacheFileName = null;
	
	private float realOrientation;
	private int orientationInt;
	
	private DEW dew;
	
	public DEWImage(DEW _dew) {
		dew = _dew;		
	}
	
	
	/**
	 * @return the fullImage
	 */
	Bitmap getFullImage() {
		return BitmapFactory.decodeFile(fullImageFileName);
	}
	
	/**
	 * 
	 * @return
	 */
	String getFullImageFileName() {
		return fullImageFileName;
	}
	
	/**
	 * @param fullImageFileName the fullImageFileName to set
	 */
	public void setFullImageFileName(String fullImageFileName) {
		this.fullImageFileName = fullImageFileName;
		screenImage = null;
		thumbImage = null;
	}
	
	/**
	 * @return the screenImage
	 */
	public Bitmap getScreenImage() {
	  // log("I'm inside getScreenImage");

	  if (screenImage == null && fullImageFileName != null) {
		  log("screenImage is null and fullImageFileName is not null");
		  
		  Bitmap fullImage = getFullImage();

			if (fullImage == null) {
			  log("fullImage was null, calling setFullImageFileName(null)");
				setFullImageFileName(null);
				return null;
			}
			
			float screenWidth = dew.getResources().getDisplayMetrics().widthPixels;
			float screenHeight = dew.getResources().getDisplayMetrics().heightPixels;
			float aspect = screenWidth/screenHeight;
			float imgAspect = ((float)fullImage.getWidth())/fullImage.getHeight();
			
			// int dstW = (aspect == imgAspect) ? (int) screenWidth : (aspect > imgAspect) ? (int) (fullImage.getWidth() * (screenHeight/fullImage.getHeight())) : (int) screenWidth;
			// int dstH = (aspect == imgAspect) ? (int) screenHeight : (aspect > imgAspect) ? (int) screenHeight : (int) (fullImage.getHeight() * (screenWidth/fullImage.getWidth()));
			
		  int dstW = 0;
		  
		  if (aspect == imgAspect) {
		    dstW = (int) screenWidth;
		  } else if (aspect > imgAspect) {
		    dstW = (int) (fullImage.getWidth() * (screenHeight/fullImage.getHeight()));
		  } else { 
		    dstW = (int) screenWidth;
		  }
		  
      int dstH = 0;
      
      if (aspect == imgAspect) {
        dstH = (int) screenHeight;
      } else if (aspect > imgAspect) {
        dstH = (int) screenHeight;
      } else {
        dstH = (int) (fullImage.getHeight() * (screenWidth/fullImage.getWidth()));
      }
			
			log("Resizing image: sW: " + screenWidth + " sH: " + screenHeight + " iW: " + fullImage.getWidth() + " iH: " + fullImage.getHeight() + " sA: " + aspect + " iA: " + imgAspect + " dstW:" + dstW + " dstH: " + dstH);
			
			screenImage = Bitmap.createScaledBitmap(fullImage, dstW, dstH, false);
			fullImage.recycle();
			fullImage = null;
		}
		
		return screenImage;
	}
	
	/**
	 * @param screenImage the screenImage to set
	 */
	void setScreenImage(Bitmap screenImage) {
	  log("Somebody called setScreenImage with an image!");
		this.screenImage = screenImage;
	}
	
	/**
	 * @return the thumbImage
	 */
	Bitmap getThumbImage() {
		return thumbImage;
	}
	
	/**
	 * @param thumbImage the thumbImage to set
	 */
	void setThumbImage(Bitmap thumbImage) {
		this.thumbImage = thumbImage;
	}
	
	/**
	 * @return the uploaded
	 */
	public boolean isUploaded() {
		return uploaded;
	}
	
	/**
	 * @param uploaded the uploaded to set
	 */
	public void setUploaded(boolean uploaded) {
		this.uploaded = uploaded;
	}
	
	/**
	 * @return the postID
	 */
	int getPostID() {
		return postID;
	}
	/**
	 * @param postID the postID to set
	 */
	void setPostID(int postID) {
		this.postID = postID;
	}
	
	/**
	 * @return the pictureSetID
	 */
	int getPictureSetID() {
		return pictureSetID;
	}
	/**
	 * @param pictureSetID the pictureSetID to set
	 */
	void setPictureSetID(int pictureSetID) {
		this.pictureSetID = pictureSetID;
	}
	
	/**
	 * @return the cached
	 */
	boolean isCached() {
		return cached;
	}
	/**
	 * @param cached the cached to set
	 */
	void setCached(boolean cached) {
		this.cached = cached;
	}
	
	/**
	 * @return the cacheFileName
	 */
	String getCacheFileName() {
		return cacheFileName;
	}
	/**
	 * @param cacheFileName the cacheFileName to set
	 */
	void setCacheFileName(String cacheFileName) {
		this.cacheFileName = cacheFileName;
	}
	
	/**
	 * @return the realOrientation
	 */
	public float getRealOrientation() {
		return realOrientation;
	}
	/**
	 * @param realOrientation the realOrientation to set
	 */
	public void setRealOrientation(float realOrientation) {
		this.realOrientation = realOrientation;
	}
	
	/**
	 * @return the orientationInt
	 */
	public int getOrientationInt() {
		return orientationInt;
	}
	/**
	 * @param orientationInt the orientationInt to set
	 */
	public void setOrientationInt(int orientationInt) {
		this.orientationInt = orientationInt;
	}
	
	DEW getDEW() {
		return dew;
	}
	
	private static final String LOG_TAG = "DEWImage";
	
	public static void log(String s) {
		DEW.getDEW().log(LOG_TAG, s);
	}

}
