package com.citizapps.dew;

import android.os.Bundle;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceClickListener;
import android.preference.PreferenceActivity;
import android.widget.Toast;

public class DEWPreference extends PreferenceActivity {
  private static final String LOG_TAG = "DEWPreference";
  
  static void log(String s) {
    DEW.getDEW().log(LOG_TAG, s);
  }
  
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		addPreferencesFromResource(R.xml.preferences);
		
		/*
		//Get the custom preference
		Preference customPref = (Preference) findPreference("DEW Viewer");
		customPref.setOnPreferenceClickListener(new OnPreferenceClickListener() {

			public boolean onPreferenceClick(Preference preference) {
				//Toast.makeText(getBaseContext(), "Launching DEW viewer", Toast.LENGTH_LONG).show();
				//SharedPreferences customSharedPreference = getSharedPreferences("DEW Viewer", Activity.MODE_PRIVATE);
				//SharedPreferences.Editor editor = customSharedPreference.edit();
				//editor.putString("DEW viewer","launches DEW Viewer");
				//editor.commit();
				//startActivity(new Intent(DEWPreference.this, PostViewer.class));
				return true;
			}
		});
		*/
		
		/*
		Preference customPref2 = (Preference) findPreference("clear images");
		customPref2.setOnPreferenceClickListener(new OnPreferenceClickListener() {
			public boolean onPreferenceClick(Preference preference) {
				Toast.makeText(getBaseContext(), "This functionality is temporarily disabled", Toast.LENGTH_LONG).show();
				//PictureFileHandling.removeFiles();
				return true;
			}
		});
		
		Preference customPref3 = (Preference) findPreference("delete database");
    customPref3.setOnPreferenceClickListener(new OnPreferenceClickListener() {
      public boolean onPreferenceClick(Preference preference) {
        Toast.makeText(getBaseContext(), "This functionality is temporarily disabled", Toast.LENGTH_LONG).show();
        // DEW.getDEW().getApplicationContext().deleteDatabase(ImageRecordProvider.DATABASE_NAME);
        return true;
      }
    });

    Preference customPref4 = (Preference) findPreference("logToFile");
    customPref4.setOnPreferenceClickListener(new OnPreferenceClickListener() {
      public boolean onPreferenceClick(Preference preference) {
        Toast.makeText(getBaseContext(), "logToFile: " + preference.toString(), Toast.LENGTH_LONG).show();
        return true;
      }
    });
    */
	}
	
	@Override
	protected void onPause() {
	  super.onPause();
	  // This call will have the side effect of setting the DEW object's
	  // internal loggingToFile variable, which is in turn checked to
	  // see if incoming log messages need to be logged to file.	  
	  boolean nowLogging = getDEW().getLoggingToFile();
	  if (nowLogging == false) {
	    DEW.getDEW().closeLogFile();
	  }
	}
	
	DEW getDEW() {
		return (DEW) getApplication();
	}

}



