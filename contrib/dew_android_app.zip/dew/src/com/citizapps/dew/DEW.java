package com.citizapps.dew;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.Application;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;

import com.citizapps.dew.camera.PicPostCamera;
import com.citizapps.dew.images.DEWImage;
import com.citizapps.dew.io.PictureFileHandling;
import com.citizapps.dew.logging.MessageLogger;
import com.citizapps.dew.model.PicturePost;
import com.citizapps.dew.sensors.DEWService;
import com.citizapps.dew.service.ImageUploadService;
import com.citizapps.dew.service.ImageUploadService.ImageUploadServiceBinder;

public class DEW extends Application {
	public static final String TAG = "DEW";
	public static final String VERSION = "v0.9.0";

	public MessageLogger log = new MessageLogger();
	public DEWService service;
	public PicPostCamera cam;
	private PicturePost currentPicturePost;
	
	private int postId = 42;
	
	public static final int THUMBNAIL_WIDTH = 150;
	public static final int THUMBNAIL_HEIGHT = 100;
	
	private BufferedWriter logWriter = null;
	private File logFile = new File(DEW.getDirectory() + File.separator + "dew.log");

	// public final static String[] directions = {"N","NE","E","SE","S","SW","W","NW"};
	public final static String[] directions = {"N","NE","E","SE","S","SW","W","NW","UP"};
	
	private boolean imageUploadServiceBound = false;
	private ImageUploadService imageUploadService = null;
	
  public int getOrientationIndex(String orientation) {
    int index = 0;
    for (int i = 0; i < directions.length; i++) {
      if (orientation.equals(directions[i])) {
        return i;
      }
    }
    return index;
  }
  
  
  /*
   *  Defines callbacks for service binding, passed to bindService() 
   */
  private ServiceConnection mConnection = new ServiceConnection() {
    @Override
    public void onServiceConnected(ComponentName className, IBinder service) {
      // We've bound to LocalService, cast the IBinder and get LocalService instance
      log("Binding the ImageUploadService");
      ImageUploadServiceBinder binder = (ImageUploadServiceBinder) service;
      imageUploadService = binder.getService();
      imageUploadServiceBound = true;
    }

    @Override
    public void onServiceDisconnected(ComponentName arg0) {
      log("Unbinding the ImageUploadService");
      imageUploadService = null;
      imageUploadServiceBound = false;
    }
  };
  
  
  /*
   * Returns the post id of the currently uploading post if the service
   * is running, returns -1 if the service is not running.
   */
  public int isIUServiceRunning() {
    ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
    for (RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
      if ("com.citizapps.dew.service.ImageUploadService".equals(service.service.getClassName())) {
        int uploadingPostId = -1;
        // Bind to LocalService
        Intent intent = new Intent(this, ImageUploadService.class);
        boolean success = bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
        if (success == true && imageUploadServiceBound == true && imageUploadService != null) {
          uploadingPostId = imageUploadService.getUploadingPostId();
          unbindService(mConnection);
        } else {
          log("BUMMER, I was unable to bind to the ImageUploadService, even though it appears to be running.");
        }
        return uploadingPostId;
      }
    }
    return -1;
  }
  
  
	public static final long uiFreq = 250;
	private DEWImage[] images = new DEWImage[directions.length];
	//private DEWImage[] currentPostCameraImages = new DEWImage[directions.length];
	//private DEWImage[] currentPostCanonicalImages = new DEWImage[directions.length];
	
	private boolean loggingToFile = false;
	private boolean gpsToExif = false;
	
	public void setLoggingToFile(boolean b) {
	  SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);

    Editor editor = prefs.edit();
    editor.putBoolean("logToFile", b);
    editor.commit();
    loggingToFile = b;
	}
	
	public boolean getLoggingToFile() {
	  SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
    Boolean doLogging = prefs.getBoolean("logToFile", false);
    loggingToFile = ((doLogging == Boolean.FALSE) ? false : true);
    log("loggingToFile is now: " + loggingToFile);
    return loggingToFile;
	}
	
	 public void setGpsToExif(boolean b) {
	    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
	    Editor editor = prefs.edit();
	    editor.putBoolean("gpsToExif", b);
	    editor.commit();
	    gpsToExif = b;
	 }  
	  
	  public boolean getGpsToExif() {
	    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
	    Boolean xtraExif = prefs.getBoolean("gpsToExif", false);
	    gpsToExif = ((xtraExif == Boolean.FALSE) ? false : true);
	    log("gpsToExif is now: " + gpsToExif);
	    return gpsToExif;
	  }
	
  private class DownloadOnionSkinImageTask extends AsyncTask<Integer, Void, String> {
    long pictureSetId;
    int orientationIdx;
    String imageFileAndPath = null;
    
    public DownloadOnionSkinImageTask(long picSetId) {
      pictureSetId = picSetId;
    }
    
    protected String doInBackground(Integer... orientationIdxs) {
      try {
        orientationIdx = orientationIdxs[0].intValue();
        String orientation = directions[orientationIdx];
        String tmpPath = getDirectory() + File.separator + "ps_" + pictureSetId + "_" + orientationIdx + ".jpg";
        log("The path for this onion skin will be: " + tmpPath);

        // First check the disk for this file existing already, and return the path
        // immediately if we do.
        File f = new File(tmpPath);
        if (f.exists() && f.canRead()) {
          return tmpPath;
        }

        // So we don't have it, let's download into a Bitmap
        Bitmap onionSkinImage = PictureFileHandling.getImage(pictureSetId, orientation, "medium");

        if (onionSkinImage != null) {

          // Now write the bitmap to the disk and then return the path and file name in a string
          FileOutputStream out = new FileOutputStream(tmpPath);
          onionSkinImage.compress(Bitmap.CompressFormat.JPEG, 100, out);
          out.close();
          imageFileAndPath = tmpPath;

          // This was being done in the example code I found, I'm not sure what it's
          // doing, but how could recycling be a bad thing? ;-)
          onionSkinImage.recycle();
        }
      } catch (Exception e) {
        e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
      }

      return imageFileAndPath;
    }

    protected void onProgressUpdate() {
      // setProgressPercent(progress[0]);
    }

    protected void onPostExecute(String onionSkinImageFileAndPath) {
      try {
        setImage(orientationIdx, new DEWImage(DEW.this));

        if (onionSkinImageFileAndPath != null) {
          getImage(orientationIdx).setFullImageFileName(onionSkinImageFileAndPath);
        }

        getImage(orientationIdx).setRealOrientation(orientationIdx * 45);
        getImage(orientationIdx).setUploaded(true);
      } catch (Exception e) {
        e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
      }
    }
  }

	private static DEW singleton;

	public DEW() {
		singleton = this;
	}
	
	public PicturePost getCurrentPicturePost() {
	  return currentPicturePost;
	}
	
	public void setCurrentPicturePost(PicturePost post) {
	  currentPicturePost = post;
	}

	public String getUsername() {
	  /*
		SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
		String username = prefs.getString("username", "user");
		if (username.contains(",")) {
			username.replaceAll(",", ".");
			prefs.edit().putString("username", username);
		}
		log("The current username preference is: " + username);
		*/
	  String username = "user";
		return username;
	}

	public int getPostID() {
	  /*
		SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
		int postID = 42;

		try {
			postID = Integer.decode(prefs.getString("postID", "42"));
		} catch (Exception e) {
			postID = 42;
		}
		*/
		
		log("The current postId preference is: " + postId);

		return postId;
	}

	public void setPostID(int postID) {
	  /*
		SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);

		Editor editor = prefs.edit();
		editor.putString("postID", "" + postID);
		editor.commit();
		*/
	  
	  postId = postID;
	}
	
	
	public String getPicturePostHost() {
	  /*
	  SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
	  String host = prefs.getString("picPostHost", "");
	  log("The current picPostHost preference is: " + host);
	  return host;
	  */
	  return "http://picturepost-dev.sr.unh.edu";
	}
	
	
	public void setPicturePostHost(String hostUrl) {
	  /*
    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);

    Editor editor = prefs.edit();
    editor.putString("picPostHost", "" + hostUrl);
    editor.commit();
    */
	}
	
	
  public String getAddPictureServletName() {
    /*
    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
    String servletName = prefs.getString("addPictureServlet", "");
    log("The current addPictureServlet preference is: " + servletName);
    return servletName;
    */
    return "/app/AddPicture";
  }
  
  
  public void setAddPictureServletName(String name) {
    /*
    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);

    Editor editor = prefs.edit();
    editor.putString("addPictureServlet", "" + name);
    editor.commit();
    */
  }
  
  
  public String getMobilePhoneNumber() {
    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
    String mobileNumber = prefs.getString("mobilePhoneNumber", "");
    log("The current mobilePhoneNumber preference is: " + mobileNumber);
    return mobileNumber;
  }
  
  
  public void setMobilePhoneNumber(String number) {
    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);

    Editor editor = prefs.edit();
    editor.putString("mobilePhoneNumber", "" + number);
    editor.commit();
  }
  
  
	public boolean getShowTextSetting() {
		boolean b = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("showtext", false);
		return b;
	}

	public boolean getShowDebugTextSetting() {
		boolean b = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("showdebugtext", false);
		return b;
	}

	public void notifyOrientationChange() {
	
	}
	
	
	public void notifyAccelerometerChange() {
	  
	}


	public void startSensors() {
	  log("DEW starting sensors");
		Intent intent = new Intent(this, DEWService.class);		
		startService(intent);
	}
	
	public void stopSensors() {
	  log("DEW stopping sensors");
	  Intent intent = new Intent(this, DEWService.class);    
    stopService(intent);
	}


	public void setupImage(int i, boolean uploaded) {
		if (getImage(i) == null) {
		  setImage(i, new DEWImage(this));
		}
		
		log("Seting up image " + i);

		if (PictureFileHandling.orientationExists(i)) {
			getImage(i).setFullImageFileName(PictureFileHandling.getNewFile(i).getAbsolutePath());
			getImage(i).setRealOrientation(i * 45);
			getImage(i).setUploaded(uploaded);
		}
	}

	public void setupImages(boolean b) {
		for (int i=0; i<getImages().length; i++) {
			setupImage(i, b);
		}
	}
	
	public void setupImages(PicturePost post) {
    long pictureSetId = -1;
    
    log("Inside setupImages");
    
    try {
      pictureSetId = Long.parseLong(post.postAttributeMap.get(PicturePost.REFERENCE_PICTURE_SET_ID).toString());
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    if (pictureSetId > 0) {
	    for (int i = 0; i < getImages().length; i++) {
	      new DownloadOnionSkinImageTask(pictureSetId).execute(i);
      }
    } else {
      // need to empty out all the DEWImage objects in images
      for (int i=0; i<getImages().length; i++) {
        setImage(i, new DEWImage(DEW.this));
        getImage(i).setRealOrientation(i * 45);
        getImage(i).setUploaded(true);
      }
    }
	}

	public void removeImages() {
		if (images == null) return;
		
		for (int i=0; i<images.length; i++) {
			images[i].setFullImageFileName(null);
			images[i].setUploaded(true);
		}
		
	}

	public void setImages(DEWImage[] images) {
		this.images = images;
	}


	public DEWImage[] getImages() {
		return images;
	}

	public DEWImage getImage(int i) {
		if (images == null || images.length<=i) return null;

		return images[i];
	}

	public void setImage(int i, DEWImage image) {
		images[i] = image;
	}

	public void setCurrentPicture(String name, int pictureOrientationIndex, float pictureRealOrientation, boolean uploaded) {
	  DEWImage img = images[pictureOrientationIndex];
	  if (img != null) {
	    img.setFullImageFileName(name);
	    img.setRealOrientation(pictureRealOrientation);		
	    img.setOrientationInt(pictureOrientationIndex);	
	    img.setUploaded(uploaded);
		  log("Made new picture: Orientation: " + images[pictureOrientationIndex].getRealOrientation() + 
		      " index:" + images[pictureOrientationIndex].getOrientationInt());
		  img.getScreenImage();
	  } else {
	    log("Unable to setCurrentPicture(" + name + ", " + pictureOrientationIndex + ", " + pictureRealOrientation + ", " + uploaded + ")");
	  }
	}

	public void log(String tag, String msg) {
	  log.addMessage(Log.INFO, tag, msg);
	  
	  if (loggingToFile == true) {
      try {
        if (!logFile.exists() || !logFile.canRead()) {
          try {
            boolean created = logFile.createNewFile();
            log("File " + logFile.toString() + " did " + (created == true ? "" : "not") + " need to be created");
          } catch (Exception exp) {
            exp.printStackTrace();
          }
        }
        if (logWriter == null) {
          logWriter = new BufferedWriter(new FileWriter(logFile, true));
        }
        
        logWriter.append(tag + ": " + msg + "\n");
        logWriter.flush();
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
	}
	
	public void closeLogFile() { 
	  if (logWriter != null) {
	    try {
	      logWriter.flush();
	      logWriter.close();
	      logWriter = null;
	    } catch (Exception e) {
	      e.printStackTrace();
	    }
	  }
	}
	
	void log(String s) {
		log(DEW.TAG, s);
	}

	void logD(String s) {
		log.addMessage(Log.DEBUG, DEW.TAG, s);
	}

	public static DEW getDEW() {
		return singleton;
	}
	
  private static File getDirectory() {
    File root = Environment.getExternalStorageDirectory();
    File dir = new File(root, "DEW-PicturePost");
    boolean made = dir.mkdirs();
    // Log.d(TAG, "Did " + (made == true ? "" : "not") + " need to create directory: " + dir.getPath());
	  return dir;
	}
}
