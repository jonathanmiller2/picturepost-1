package com.citizapps.dew.camera;

import java.util.List;

import android.hardware.Camera;

import com.citizapps.dew.DEW;


public class CameraParameterManager {
  private static final String LOG_TAG = "Camera Parameter Manager";
  
  public static void logCameraParameters(Camera.Parameters parameters) {
    log(parameters.flatten());
  }
  
  public static void logCameraCapabilities(Camera.Parameters parameters) {
    StringBuilder bldr = new StringBuilder("\nSupported Options\n");
    
    // Gets the supported antibanding values.
    List<String> antiBandingOptions = parameters.getSupportedAntibanding();
    bldr.append("  Antibanding options\n");
    if (antiBandingOptions != null) {
      for (String s : antiBandingOptions) {
        bldr.append("    " + s + "\n");
      }
    } else {
      bldr.append("   NONE\n");
    }
    
    // Gets the supported color effects.
    List<String> colorEffects = parameters.getSupportedColorEffects();
    bldr.append("  Color effects:\n");
    if (colorEffects != null) {
      for (String s : colorEffects) {
        bldr.append("    " + s + "\n");
      }
    } else {
      bldr.append("    NONE\n");
    }
    
    // Gets the supported flash modes.
    List<String> flashModes = parameters.getSupportedFlashModes();
    bldr.append("  Flash modes:\n");
    if (flashModes != null) {
      for (String s : flashModes) {
        bldr.append("    " + s + "\n");
      }
    } else {
      bldr.append("    NONE\n");
    }
    
    // Gets the supported focus modes.
    List<String> focusModes = parameters.getSupportedFocusModes();
    bldr.append("  Focus modes:\n");
    if (focusModes != null) {
      for (String s : focusModes) {
        bldr.append("    " + s + "\n");
      }
    } else {
      bldr.append("    NONE\n");
    }
    
    // Gets the supported jpeg thumbnail sizes.
    // List<Camera.Size> thumbNailSizes = parameters.getSupportedJpegThumbnailSizes();
    List<Camera.Size> thumbNailSizes = null;
    bldr.append("  Thumbnail sizes:\n");
    if (thumbNailSizes != null) {
      for (Camera.Size camSize : thumbNailSizes) {
        bldr.append("    " + camSize.width + "x" + camSize.height + "\n");
      } 
    } else {
      bldr.append("    NONE\n");
    }
    
    
    // Gets the supported picture formats.
    List<Integer> pictureFormats = parameters.getSupportedPictureFormats();
    bldr.append("  Picture formats:\n");
    if (pictureFormats != null) {
      for (Integer format : pictureFormats) {
        bldr.append("    " + format.intValue() + "\n");
      }
    } else {
      bldr.append("    NONE\n");
    }
    
    // Gets the supported picture sizes.
    List<Camera.Size> pictureSizes = parameters.getSupportedPictureSizes();
    bldr.append("  Picture sizes:\n");
    if (pictureSizes != null) {
      for (Camera.Size picSize : pictureSizes) {
        bldr.append("    " + picSize.width + "x" + picSize.height + "\n");
      }
    } else {
      bldr.append("    NONE\n");
    }
    
    // Gets the supported preview formats.
    List<Integer> previewFormats = parameters.getSupportedPreviewFormats();
    bldr.append("  Preview formats:\n");
    if (previewFormats != null) {
      for (Integer format : previewFormats) {
        bldr.append("    " + format.intValue() + "\n");
      }
    } else {
      bldr.append("    NONE\n");
    }
    
    // Gets the supported preview fps (frame-per-second) ranges.
    List<Integer> previewFrameRates = parameters.getSupportedPreviewFrameRates();
    bldr.append("  Preview frame rates:\n");
    if (previewFrameRates != null) {
      for (Integer frameRate : previewFrameRates) {
        bldr.append("    " + frameRate.intValue() + "\n");
      }
    } else {
      bldr.append("    NONE\n");
    }
    
    // This method is deprecated. replaced by getSupportedPreviewFpsRange()
    // List<Integer>  getSupportedPreviewFrameRates()
    
    // Gets the supported preview sizes.
    List<Camera.Size> previewSizes = parameters.getSupportedPreviewSizes();
    bldr.append("  Preview sizes:\n");
    if (previewSizes != null) {
      for (Camera.Size previewSize : previewSizes) {
        bldr.append("    " + previewSize.width + "x" + previewSize.height + "\n");
      }
    } else {
      bldr.append("    NONE\n");
    }
    
    // Gets the supported scene modes.
    List<String> sceneModes = parameters.getSupportedSceneModes();
    bldr.append("  Scene modes:\n");
    if (sceneModes != null) {
      for (String s : sceneModes) {
        bldr.append("    " + s + "\n");
      }
    } else {
      bldr.append("    NONE\n");
    }
    
    // Gets the supported video frame sizes that can be used by MediaRecorder.
    // List<Camera.Size> videoFrameSize = parameters.getSupportedVideoSizes();
    
    // Gets the supported white balance.
    List<String> whiteBalances = parameters.getSupportedWhiteBalance();
    bldr.append("  White balance values:\n");
    for (String s : whiteBalances) {
      bldr.append("    " + s + "\n");
    }
    
    log(bldr.toString());
  }
  
  public static Camera.Parameters setAppropriateCameraParameters(Camera.Parameters currentParameters) {
    return currentParameters;
  }
  
  public static void log(String s) {
    DEW.getDEW().log(LOG_TAG, s);
  }
}
