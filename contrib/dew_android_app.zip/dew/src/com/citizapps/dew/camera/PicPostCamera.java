package com.citizapps.dew.camera;


import java.io.File;

import android.app.Activity;
import android.content.Intent;
import android.hardware.Camera;
import android.hardware.Camera.ErrorCallback;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.citizapps.dew.DEW;
import com.citizapps.dew.R;
import com.citizapps.dew.io.PictureFileHandling;
import com.citizapps.dew.model.SensorDataBundle;

public class PicPostCamera extends Activity implements OnKeyListener {
	PicPostPreview preview;
	private CameraOverlay overlay = null;
	PictureFileHandling pfh;
	Handler handler;
	Runnable updateScreenTask;
	Runnable addViewsToLayoutTask;
	boolean isActive = true;
	// private boolean doIncludeSensorDataInExif = false;
	
	private boolean shouldFetchImages = false;

	private class RetrievePictureSetImage extends AsyncTask<String, Void, Boolean> {
		protected Boolean doInBackground(String... urls) {
		  Boolean returnValue = Boolean.TRUE;
		  try {
			  PictureFileHandling.fetchImages(urls[0]);
		  } catch (Exception e) {
		    e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
        returnValue = Boolean.FALSE;
		  }
			return returnValue;
		}
		protected void onProgressUpdate() {}
		protected void onPostExecute(Boolean value) {}
	}
	
	/*
	public void setDoIncludeSensorDataInExif(boolean b) {
	  doIncludeSensorDataInExif = b;
	}
	
	public boolean getDoIncludeSensorDataInExif() {
	  return doIncludeSensorDataInExif;
	}
	*/

	public void startScreenUpdateTask() {
	  log("Inside startScreenUpdateTask");
	  if (overlay != null) {
	    log("overlay is non-null");
	    
	    if (isShouldFetchImages()) {
        log("We're supposed to fetch images, so let's do it.");
        PictureFileHandling.downloadImagesOnThread();
      }
	    
	    if (updateScreenTask == null) {
	      log("updateScreenTask is null, so we need to initialize it");
	      updateScreenTask = new Runnable() {
	        public void run() {
	          if (PicPostCamera.this.isActive) {	
	            log("Inside the updateScreenTask Runnable, going to set orientation and invalidate the overlay.");
	            overlay.setCurrentOrientation();
	            overlay.invalidate();
	            getHandler().postDelayed(updateScreenTask, DEW.uiFreq);
	          } else {
	            updateScreenTask = null;
	            log("killing screen update");
	          }
	        }
	      };

	      getHandler().postDelayed(updateScreenTask, DEW.uiFreq);
	    }
	  }
	}


	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		log("Inside PicPostCamera.onCreate()");
		
		pfh = new PictureFileHandling(getApplication());

		setContentView(R.layout.camera);	

		Intent intent = getIntent();
		Uri intentData = intent.getData();
		if (intentData != null) {
			log("The intent has a data uri: " + intentData.toString());
			String url = intentData.toString();
			setShouldFetchImages(true);
		} else {
			log("The intent had no data uri");
		}
		
		log("onCreate -- complete");
	}

	Handler getHandler() {
		if (handler == null) {
			handler = new Handler();
		}
		
		return handler;
	}

	public void setupPreview() {
	  log("Inside PicPostCamera.setupPreview()");
	  
		preview = new PicPostPreview(this);
		
		final FrameLayout layout = ((FrameLayout) findViewById(R.id.preview));   
		
		layout.removeAllViews();
    layout.addView(preview);
    log("In setupPreview: added SurfaceView (PicPostPreview) to the FrameLayout");
		
    overlay = new CameraOverlay(PicPostCamera.this);
    overlay.setMessageText("Touch Screen to take picture...");

    if (overlay != null) {
      getDEW().log.addListener(overlay);
      layout.addView(overlay);
      log("in setupPreview: added CameraOverlay to the FrameLayout");
    }

    int diff = 75; //(preview.getWidth() - preview.targetX)/2;
    layout.setPadding(diff, 0, diff, 0);
		      
		log("Setting the DEW.cam reference to " + this.toString());
		getDEW().cam = this;
		
		isActive = true;
    startScreenUpdateTask();
	}


	public void onStart() {
		super.onStart();
		log("onStart");
	}

	public void onResume() {
		super.onResume();
		log("Inside PicPostCamera.onResume()");		

		// setupPreview();

		getDEW().startSensors();
		
		setupPreview();
	}

	public void onPause() {
		super.onPause();
		log("Inside PicPostCamera.onPause()");
		
		isActive = false;

		preview.releaseCamera();
		if (getDEW().cam != null) {
			getDEW().cam = null;
		}

		setOverlay(null);
		FrameLayout layout = ((FrameLayout) findViewById(R.id.preview));
		layout.removeAllViews();

		log("onPause");
	}

	public void onStop() {
		super.onStop();

		log("onStop");
	}

	public void onDestroy() {
		super.onDestroy();

		log("onDestroy");
	}

	public void onRestart() {
		super.onRestart();
		log("onRestart");
	}	

	public boolean onKey(View v, int keyCode, KeyEvent event) {
		log("Inside PicPostCamera.onKey(): " + " view: " + v + " keyCode: <"+keyCode+"> event: " + event);

		return true;
	}

	ShutterCallback shutterCallback = new ShutterCallback() {
		public void onShutter() {
			log("onShutter");
			
			if (overlay != null) {
			  overlay.setMessageText("shutter...");
			  overlay.saveNewPictureOrientation();
			}

			// getOverlay().saveNewPictureOrientation();

		}
	};

	/** Handles data for raw picture */
	PictureCallback rawCallback = new PictureCallback() {
		public void onPictureTaken(byte[] data, Camera camera) {
			log("onPictureTaken - raw");
			if (overlay != null) {
			  overlay.setMessageText("processing...");
			}
		}
	};
	
	private class WritePictureToFileTask extends AsyncTask<Void, Void, File> {
	  byte[] d;
	  Camera c;
	  int i;
	  float r;
	  SensorDataBundle b;
	  public WritePictureToFileTask(byte[] data, Camera cam, int orientationIdx, SensorDataBundle bundle) {
	    d = data;
	    c = cam;
	    i = orientationIdx;
	    b = bundle;
	  }
	  protected File doInBackground(Void... urls) {
	    File file = null;
	    try {
	      file = PictureFileHandling.writePicture(d, i);
	      log("writePicture returned " + (file == null ? "NULL" : file.getName()));
	    } catch (Exception e) {
	      e.printStackTrace();
	      Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
	    }
	    return file;
	  }
	  protected void onProgressUpdate() {}
	  protected void onPostExecute(File f) {
	    try {
	      if (f != null) {
	        getDEW().setCurrentPicture(f.getAbsolutePath(), i, r, false);
	      }
	      d = null;
	      Runtime.getRuntime().gc();
	      getHandler().postDelayed(new Runnable() {
	        public void run() {   
	          // log("restarting sensors");
	          // getDEW().startSensors();
	          // preview.startupCamera();
	          if (overlay != null) {
	            // overlay.holdDrawing(false);
	            overlay.setMessageText("Touch Screen to take picture...");
	          }
	        }
	      }, 500);
	    } catch (Exception e) {
	      e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
	    }
	  }
	}

	/** Handles data for jpeg picture */
	PictureCallback jpegCallback = new PictureCallback() {
		public void onPictureTaken(byte[] data, Camera camera) {
		  log("onPictureTaken - jpeg");
		  
		  int idx = 0;
      float orient = 0.0f;
      
      SensorDataBundle bundle = null;
		  
		  if (overlay != null) {
        overlay.setMessageText("writing picture to disk...");
        idx = overlay.currentOrientationIndex;
        
        // if (doIncludeSensorDataInExif == true) {
        if (DEW.getDEW().getGpsToExif() == true) {
          log(" $$$$$$$$$$$$$$$$$$$$ Going to write extra exif data $$$$$$$$$$$$$$$$$$$$$ ");
          bundle = new SensorDataBundle();
          bundle.setAccelerometerX(overlay.currentAccelX);
          bundle.setAccelerometerY(overlay.currentAccelY);
          bundle.setAccelerometerZ(overlay.currentAccelZ);
          bundle.setAltitude(overlay.getLastAlt());
          bundle.setLatitude(overlay.getLastLat());
          bundle.setLongitude(overlay.getLastLon());
          bundle.setOrientationDirection(overlay.pictureRealOrientation);
        } else {
          log(" $$$$$$$$$$$$$$$$$$$$ Not going to write extra exif data $$$$$$$$$$$$$$$$$$$$$ ");
        }
		  }
		  
		  log(" ################### The bundle is " + (bundle == null ? "NULL" : "not NULL") + " ###################");
		  
		  new WritePictureToFileTask(data, camera, idx, bundle).execute();
      
			// File file = PictureFileHandling.writePicture(data, getOverlay().currentOrientationIndex);	
      
			// data = null;
			// getDEW().setCurrentPicture(file.getAbsolutePath(), getOverlay().currentOrientationIndex, getOverlay().pictureRealOrientation, false);
      
			// This is only a hint to the garbage collector, but 
			// Runtime.getRuntime().gc();
      
			// getHandler().postDelayed(new Runnable() {
			// 	public void run() {					
			// 		preview.startupCamera();
			// 		overlay.setMessageText("Touch Screen to take picture...");
			// 	}
			// }, 500);
		}
	};
	
	ErrorCallback errorCallback = new ErrorCallback() {
    @Override
    public void onError(int error, Camera camera) {
      log("Received an error with number <" + error + ">, camera is: " + camera.toString());
    }
	};


	//  MENUS ------------------------------------------------------------------------
	/* Creates the menu items */
	/*
	public static final int MENU_QUIT = 43;

	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.options_menu, menu);
		return true;	    
	}

	// Handles item selections 
	public boolean onOptionsItemSelected(MenuItem item) {
		String url;
		Uri u;
		switch (item.getItemId()) {
		case R.id.quit:
			log("Quit");
			finish();       
			return true;

		case R.id.downloadimages:
			setShouldFetchImages(true);
			return true;

		case R.id.ppwebpage:
			url = getString(R.string.ppwebpage);
			Intent i = new Intent(Intent.ACTION_VIEW);
			u = Uri.parse(url);
			i.setData(u);
			try {
				startActivity(i);
			} catch (ActivityNotFoundException e) {
				alertInfo("Browser not found.");
			}

			return true;

		case R.id.info:
			String s =   "DEW!\n\tusername: " + getDEW().getUsername() 
			+ "\n\t\t\t\tversion: " + DEW.VERSION;
			log(s);
			alertInfo(s);


			s = "Preferences:\n";

			SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
			Map<String, ?> map = prefs.getAll();

			for (String name: map.keySet()) {
				s += "\t" + name + ": <" + map.get(name)+">" + " type: " + map.get(name).getClass().getName();
			}
			log(s);

			return true;

		case R.id.preferences:
			log("Preferences menu item pressed.");

			Intent settingsActivity = new Intent(getBaseContext(), DEWPreference.class);
			startActivity(settingsActivity);

			return true;

		default:
			log("Unknown menu item selected: " + item.getTitle());
		}
		return false;
	}
	*/

	DEW getDEW() {
		return (DEW) getApplication();
	}
	
	public static final String LOG_TAG = "PicPostCamera";
	
	public static void log(String msg) {
	  DEW.getDEW().log(LOG_TAG, msg);
	}

	/*
	void log(String s) {
		getDEW().log.addMessage(Log.INFO, LOG_TAG, s);
	}

	void logD(String s) {
		getDEW().log.addMessage(Log.DEBUG, LOG_TAG, s);
	}
	*/

	void alertInfo(String alert) {
		Toast.makeText(this,alert, Toast.LENGTH_LONG).show();
	}

	public void setOverlay(CameraOverlay overlay) {
		this.overlay = overlay;
	}

	public CameraOverlay getOverlay() {
		return overlay;
	}

	public void setShouldFetchImages(boolean shouldFetchImages) {
		this.shouldFetchImages = shouldFetchImages;
	}

	public boolean isShouldFetchImages() {
		return shouldFetchImages;
	}
} 