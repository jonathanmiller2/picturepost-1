package com.citizapps.dew.camera;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.hardware.Camera;
import android.view.MotionEvent;
import android.view.View;

import com.citizapps.dew.DEW;
import com.citizapps.dew.images.DEWImage;
import com.citizapps.dew.logging.MessageListener;
import com.citizapps.dew.logging.MessageLogger;

public class CameraOverlay extends View implements MessageListener /*, OnClickListener, OnTouchListener , OnKeyListener*/ {
  private static final String LOG_TAG = "CameraOverlay";
  
	Context mContext;
	Paint titlePaint;
	Paint textPaint;
	Paint linePaint;
	Paint backgroundPaint;

	Paint nearPaint;
	
	Paint uploadedPaint;
	Paint nonUploadedPaint;
	
	private float textSize = 32;	

	static float SQRT2 = 1.4142135623730951f;
	static float ANGLE = 4.5f; // 3degrees

	int currentOrientationIndex;
	float currentRealOrientation;
	float currentOrientation;

	int pictureOrientationIndex;
	float pictureRealOrientation;
	float pictureOrientation;
	
	float currentAccelX;
	float currentAccelY;
	float currentAccelZ;
	float currentRealNormedZ;

	//private int onionSkinAlpha = 180;
	private int onionSkinAlpha = 100;  // "turn down the opacity" according to Fabio
	private boolean showOnionSkin = true;

	private float dw;
	private float aw = 2f;
	private float friction = 1f;
	private String messageText;
	
	private boolean holdDraw = false;
	
	private static int instanceCount = 0;
	
	public void holdDrawing(boolean hold) {
	  holdDraw = hold;
	}
	
	public boolean getShowOnionSkin() {
	  return showOnionSkin;
	}
	
	public void setShowOnionSkin(boolean showIt) {
	  showOnionSkin = showIt;
	}
	
	public double getOnionSkinAlpha() {
	  return ((double) onionSkinAlpha) / 255.0; 
	}
	
	public void setOnionSkinAlpha(double alpha) {
	  onionSkinAlpha = (int) (alpha * 255);
	}

	public CameraOverlay(Context context) {
		super(context);
		
		mContext = context;
		
		backgroundPaint = new Paint();
		backgroundPaint.setARGB(150, 0, 0, 0);
		
		titlePaint = new Paint();
		titlePaint.setARGB(255, 255, 50, 50);
		titlePaint.setTextSize(textSize );
		
		textPaint = new Paint();
		textPaint.setARGB(255, 255, 255, 255);
		textPaint.setTextSize(textSize );

		linePaint = new Paint();
		linePaint.setARGB(255, 255, 0, 55);
		linePaint.setTextSize(textSize );
		linePaint.setStrokeWidth(3);

		nearPaint = new Paint();
		nearPaint.setARGB(255, 50, 255, 50);
		nearPaint.setTextSize(textSize );

		uploadedPaint = new Paint();
		uploadedPaint.setARGB(255, 50, 105, 250);
		uploadedPaint.setTextSize(textSize );
		uploadedPaint.setStrokeWidth(2);

		nonUploadedPaint = new Paint();
		nonUploadedPaint.setARGB(255, 250, 150, 55);
		nonUploadedPaint.setTextSize(textSize );
		nonUploadedPaint.setStrokeWidth(2);

		// getDEW().setupImages(true);
		
		// setOnClickListener(this);
		// setOnTouchListener(this);
		// setOnKeyListener(this);
		
		log("Inside CameraOverlay constructor, instance count: " + ++instanceCount);
    
	}


	protected double getLastLat() {
		double lastLat = 0;
		if (getDEW().service != null) {
			lastLat = getDEW().service.getLastLat();
		}
		return lastLat;
	}

	protected double getLastLon() {
		double lastLon = 0;
		if (getDEW().service != null) {
			lastLon = getDEW().service.getLastLon();
		}
		return lastLon;
	}
	
	protected double getLastAlt() {
	  double lastAlt = 0.0;
    if (getDEW().service != null) {
      lastAlt = getDEW().service.getLastAlt();
    }
    return lastAlt;
	}


	public void setCurrentOrientation() {
	  
		float targetRealOrientation = 0;
		if (getDEW().service != null) {
			targetRealOrientation = (getDEW().service.getLastDirection() + 90);
			targetRealOrientation = (targetRealOrientation >= 360) ? targetRealOrientation - 360.0f : targetRealOrientation;
		}

		float a = (targetRealOrientation - currentRealOrientation);
		if (a>180) {
			a = -360 + a;
		} else if (a<-180) {
			a = 360 + a;
		}


		dw = dw * friction;

		if (Math.abs(dw)>Math.abs(a)) {
			dw = a;
		} else if (Math.abs(a)>0.01f) {
			dw += ((a<0)?-aw:aw);
		}

		if (Math.abs(a) < Math.abs(aw)) dw = 0;
		
		currentRealOrientation += dw;
		currentRealOrientation = (currentRealOrientation >= 360) ? currentRealOrientation - 360.0f : (currentRealOrientation<0) ? currentRealOrientation + 360 : currentRealOrientation;

		currentOrientationIndex = (Math.round(currentRealOrientation/45)) % 8;
		currentOrientation = currentOrientationIndex * 45;
		
		currentAccelX = getDEW().service.getLastAccelX();
		currentAccelY = getDEW().service.getLastAccelY();
		currentAccelZ = getDEW().service.getLastAccelZ();
		currentRealNormedZ = getDEW().service.getLastNormalizedAccelZ();
		
    if (currentRealNormedZ <= -0.8f) {
      currentOrientationIndex = DEW.directions.length - 1;
    }  

		// log("dw:" + dw +" cro:" + currentRealOrientation + " tro:" + targetRealOrientation + " coi:" + currentOrientationIndex + " co:" + currentOrientation);

	}

	protected void onDraw(Canvas canvas) {	
	  if (holdDraw == false) {
	    drawOnionSkin(canvas);

	    if (getDEW().getShowDebugTextSetting()) {
	      getDEW().log.drawMessages(canvas);
	    }

	    drawLines(canvas);

	    //drawMemory(canvas);

	    drawController(canvas);

	    drawMessageText(canvas);
	  }
	}

	void drawMemory(Canvas canvas) {
		drawText(canvas, "Max Memory: " + Runtime.getRuntime().maxMemory(),0,textSize*3);
		drawText(canvas, "Total Memory: "+Runtime.getRuntime().totalMemory(),0,textSize*4);    
		drawText(canvas, "Free Memory: "+Runtime.getRuntime().freeMemory(),0,textSize*5);	

	}
	
	void drawController(Canvas canvas) {
		float r = 50, r2 = 20;
		float a;
		float x,y;
//		float cx = canvas.getWidth() - r - r2;
//		float cy = canvas.getHeight() - r - r2;
		float cx = r + r2 * 2;
		float cy = canvas.getHeight() - r - r2 * 2;
		RectF rect1 = new RectF();
		RectF rect2 = new RectF();
		RectF rect3 = new RectF();
		RectF rect4 = new RectF();
		// RectF rect5 = new RectF();
		float p = (float) Math.PI/8;
		Paint paint;
		float tw;
		
		
		canvas.drawLine(cx, cy-r-r2*3, cx, cy+r+r2*3, linePaint);
		canvas.drawLine(cx-r-r2*3, cy, cx+r+r2*3, cy, linePaint);
		rect1.set(cx-r-r2*2, cy-r-r2*2, cx+r+r2*2, cy+r+r2*2);
		rect2.set(cx-r, cy-r, cx+r, cy+r);
		rect3.set(cx-(r/3.0f), cy-(r/3.0f), cx+(r/3.0f), cy+(r/3.0f));
		rect4.set(cx-(r/2.0f), cy-(r/2.0f), cx+(r/2.0f), cy+(r/2.0f));
		
		for (int i=0; i<DEW.directions.length - 1; i++) {
			a = (float) Math.toRadians(270 + i * 45 - currentRealOrientation);
			if (getDEW().getImage(i) == null) {
			  log("Error: the dewImage at index " + i + " is missing");
			  continue;
			}
			
			paint = (Math.abs(a-3*Math.PI/2)<p/2) ? (currentOrientationIndex != DEW.directions.length - 1 ? nearPaint : (getDEW().getImage(i).isUploaded() ? uploadedPaint : nonUploadedPaint)) : (getDEW().getImage(i).isUploaded() ? uploadedPaint : nonUploadedPaint);
			paint.setAlpha( (int) ((1-Math.sin(a)) * 100) + 55 );

			canvas.drawArc(rect1, (float) Math.toDegrees(a - p), 45, false, paint);
			canvas.drawLine(cx + (float)Math.cos(a) * (r + r2*1.5f), cy + (float)Math.sin(a) *  (r + r2*1.5f), cx + (float)Math.cos(a) * (r + r2*2.5f), cy + (float)Math.sin(a) * (r + r2*2.5f) , paint);

			paint = getDEW().getImage(i).isUploaded() ? uploadedPaint : nonUploadedPaint;
			paint.setAlpha( (int) ((1-Math.sin(a)) * 100) + 55 );

			canvas.drawArc(rect2, (float) Math.toDegrees(a - p), 45, false, paint);
			
			//canvas.drawCircle(cx + (float)Math.cos(a) * (r + r2), cy + (float)Math.sin(a) * (r + r2), r2, paint);
			
			canvas.save();
			canvas.translate(cx + (float)Math.cos(a) * (r) , cy + (float)Math.sin(a) * (r) );
			canvas.rotate((float) Math.toDegrees(a) + 90);
			tw = paint.measureText(DEW.directions[i]);
			canvas.drawText(DEW.directions[i], -tw/2, 0,textPaint);
			canvas.restore();
		}
		
		if (currentOrientationIndex == DEW.directions.length -1) {
      // Draw a green circle around the center
      paint = nearPaint;
      // paint.setAlpha(Math.min(Math.max(55, (int) (((0.0f - currentRealNormedZ) * 100) + 100)), 255));
      paint.setAlpha(255);
      canvas.drawArc(rect4, 0.0f, 360.0f, false, paint);
    }
		
		// Draw in the center circle based on current elevation angle and whether or
		// not there's already a picture in the "up" direction.
		if (getDEW().getImage(DEW.directions.length - 1) != null) {
		  paint = getDEW().getImage(DEW.directions.length - 1).isUploaded() ? uploadedPaint : nonUploadedPaint;
		} else {
		  paint = uploadedPaint;
		}
		paint.setAlpha(Math.min(Math.max(55, (int) (((0.0f - currentRealNormedZ) * 100) + 100)), 255));
		canvas.drawArc(rect3, 0.0f, 360.0f, true, paint);
		
		
	}
	
	

	void drawMessageText(Canvas canvas) {
	  if (canvas != null) {
	    if (messageText == null) { 
	      log("Error: messageText is null");
 	      return;
	    }
	    if (textPaint == null) {
	      log("Error: textPaint is null");
	      return;
	    }
	    drawText(canvas, messageText, (canvas.getWidth() / 2) - (textPaint.measureText(messageText) / 2), canvas.getHeight() - textSize/2);	
	    Rect bounds = new Rect();
	    canvas.save();
	    canvas.translate(canvas.getWidth()/2 - textPaint.measureText(messageText)/2,canvas.getHeight() - textSize/2);
	    textPaint.getTextBounds(messageText, 0, messageText.length(), bounds);
	    canvas.drawRect(bounds, backgroundPaint);
	    drawText(canvas, messageText,0,0);		
	    canvas.restore();
	  }
	}
	
	void drawLines(Canvas canvas) {
		String s = DEW.directions[currentOrientationIndex];

		int l = 8;
		String dS = "" + currentRealOrientation;
		if (dS.length()>l) dS = dS.substring(0, l);

		//canvas.drawText(dS, 0, textSize, titlePaint);

		float a = (currentOrientation - currentRealOrientation);
		a = (a<-180) ? a + 360 : a; 
		String aS = "" +  a;
		if (aS.length() > l) aS = aS.substring(0, l);
//		canvas.drawText(s + ((a>0) ? " +" : " ") + aS, canvas.getWidth()/2,  textSize, titlePaint);

		String lat = "" + getLastLat();
		if (lat.length() > l) lat = lat.substring(0,l);
		String lon = "" + getLastLon();
		if (lon.length() > l) lon = lon.substring(0,l);
//		canvas.drawText("lat: " + lat, 0, textSize, titlePaint);
//		canvas.drawText("lon: " + lon, 0, textSize*2, titlePaint);

//		canvas.drawLine(0, textSize, canvas.getWidth(), textSize, titlePaint);

//		canvas.drawLine(canvas.getWidth()/2-1, 0, canvas.getWidth()/2-1, textSize, titlePaint);
//		canvas.drawLine(canvas.getWidth()/2+1, 0, canvas.getWidth()/2+1, textSize, titlePaint);


//		drawInDirection(canvas, currentOrientation, currentRealOrientation, s);
//		drawInDirection(canvas, currentOrientation - 45, currentRealOrientation, DEW.directions[(currentOrientationIndex-1)<0?(DEW.directions.length-1):currentOrientationIndex-1]);
//		drawInDirection(canvas, currentOrientation + 45, currentRealOrientation, DEW.directions[(currentOrientationIndex+1)>=DEW.directions.length?0:currentOrientationIndex+1]);

	}

	void drawText(Canvas canvas, String s, float x, float y) {
		textPaint.setTextSize(textSize);
		canvas.drawText(s, x, y, textPaint);
	}

	/*
	void drawOnionSkin(Canvas canvas) {
	  if (showOnionSkin == true) {
	    for (DEWImage image : getDEW().getImages()) {
	      if (image != null && image.getScreenImage() != null) {
	        if (Math.abs(image.getRealOrientation() - currentRealOrientation)<90 || Math.abs(image.getRealOrientation() - currentRealOrientation)>270) {
	          if (getDEW().service != null) {
	            //log("image O: " + image.getRealOrientation() + " cO: " + currentRealOrientation + " lO: " + getDEW().service.getLastDirection());
	          }   else {
	            //log("image O: " + image.getRealOrientation() + " cO: " + currentRealOrientation + " lO: SERVICE is NULL");
	            getDEW().startSensors();
	          }

	          Bitmap img = image.getScreenImage();
	          float w2 = img.getWidth()/2;
	          float cx = dirX(canvas.getWidth(), image.getRealOrientation(), currentRealOrientation);
	          if (cx+w2>0 && cx-w2<=canvas.getWidth()) {
	            Rect src = new Rect(0,0,img.getWidth(), img.getHeight());
					  	Rect dst = new Rect((int)(cx-w2),0,(int)(cx+w2),canvas.getHeight());
					  	log("src rect: " + src.toString() + ", dest rect: " + dst.toString());
					  	Paint paint = new Paint();
					  	paint.setAlpha(onionSkinAlpha);
					  	canvas.drawBitmap(img, src, dst, paint);
	          }
	        }
	      }
	    }
	  }
	}
	*/
	
	void drawOnionSkin(Canvas canvas) {
	  if (showOnionSkin == true) {
	    DEWImage[] images = getDEW().getImages();
	    DEWImage image = images[currentOrientationIndex];
	    if (image != null && image.getScreenImage() != null) {
	      if (Math.abs(image.getRealOrientation() - currentRealOrientation)<90 || Math.abs(image.getRealOrientation() - currentRealOrientation)>270) {
	        if (getDEW().service != null) {
	          //log("image O: " + image.getRealOrientation() + " cO: " + currentRealOrientation + " lO: " + getDEW().service.getLastDirection());
	        }   else {
	          //log("image O: " + image.getRealOrientation() + " cO: " + currentRealOrientation + " lO: SERVICE is NULL");
	          getDEW().startSensors();
	        }

	        Bitmap img = image.getScreenImage();
	        	        
	        Rect src = new Rect(0,0,img.getWidth(), img.getHeight());
	        Rect dst = new Rect(0,0,canvas.getWidth(),canvas.getHeight());
	        // log("src rect: " + src.toString() + ", dest rect: " + dst.toString());
	        Paint paint = new Paint();
	        paint.setAlpha(onionSkinAlpha);
	        canvas.drawBitmap(img, src, dst, paint);
	      }
	    }
	  }
	}

	float dirX(float width, double dir, double lastDir) {
		double a = Math.toRadians(dir - lastDir);	

		return  ((float) Math.sin(a) * SQRT2 * width/2 + width/2);
	}

	void drawInDirection(Canvas c, double a, float dir, String s) {
		float x = dirX(c.getWidth(), a, dir);

		c.drawLine(x, 0, x, textSize, Math.abs(a-dir)<ANGLE?nearPaint:titlePaint);
		c.drawText(s, x - nearPaint.measureText(s)/2, textSize, (Math.abs(a-dir)<ANGLE)?nearPaint:titlePaint);
	}


	DEW getDEW() {
		return (DEW) mContext.getApplicationContext();

	}

	/*
	void log(String s) {
		getDEW().log.addMessage(Log.INFO, LOG_TAG, s);
	}

	void logD(String s) {
		getDEW().log.addMessage(Log.DEBUG, LOG_TAG, s);
	}
	*/
	
	public static void log(String msg) {
	  DEW.getDEW().log(LOG_TAG, msg);
	}


	public void notify(MessageLogger logger) {
		//invalidate();  JBT this shouldn't be used to change screen,  putting the screen on a timer based system.
	}

	public void saveNewPictureOrientation() {
		pictureOrientationIndex = currentOrientationIndex;
		pictureOrientation = currentOrientation;
		pictureRealOrientation = currentRealOrientation;
	}


	// public void onClick(View v) {
	  /*
		PicPostCamera cam = getDEW().cam;
		if (cam == null) {
			log("On click but no PP Cam");
		} else {
			if (cam.preview == null) {
				log("Got button press but preview is null...");
				return;
			}
			Camera camera = cam.preview.getCamera();
			if (camera != null) {
			  // log("Stopping sensors temporarily during picture taking");
			  // getDEW().stopSensors();
			  // holdDrawing(true);
			  log("on click: adding error callback and taking picture");
				camera.setErrorCallback(cam.errorCallback);
        camera.takePicture(cam.shutterCallback, cam.rawCallback, cam.jpegCallback);
			} else {
				log("Click pressed but no camera...");
			}
		}
		*/
	// }


	public void setMessageText(String string) {
		messageText = string;
	}


	public boolean onTouchEvent(MotionEvent event) {
		log("onTouchEvent: " + event);
    PicPostCamera cam = getDEW().cam;
    if (cam == null) {
      log("onTouchEvent but no PP Cam");
      return false;
    } else {
      if (cam.preview == null) {
        log("Got button press but preview is null...");
        return true;
      }
      Camera camera = cam.preview.getCamera();
      if (camera != null) {
        // log("Stopping sensors temporarily during picture taking");
        // getDEW().stopSensors();
        // holdDrawing(true);
        log("onTouchEvent: adding error callback and taking picture");
        camera.setErrorCallback(cam.errorCallback);
        camera.takePicture(cam.shutterCallback, cam.rawCallback, cam.jpegCallback);
      } else {
        log("touch event fired but no camera...");
      }
    }
		return true;
	}


	// public boolean onKey(View v, int keyCode, KeyEvent event) {
	// 	log("onKey: <" + keyCode + "> " + event);
	// 	return false;
	// }
}
