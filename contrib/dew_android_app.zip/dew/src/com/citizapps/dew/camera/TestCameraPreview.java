package com.citizapps.dew.camera;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.hardware.Camera;
import android.hardware.Camera.ErrorCallback;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.hardware.Camera.Size;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.FrameLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Toast;

import com.citizapps.dew.DEW;
import com.citizapps.dew.R;
import com.citizapps.dew.images.DEWImage;
import com.citizapps.dew.io.PictureFileHandling;
import com.citizapps.dew.model.ImageRecord.Images;
import com.citizapps.dew.model.PicturePost;
import com.citizapps.dew.model.SensorDataBundle;
import com.citizapps.dew.service.ImageUploadService;

// ----------------------------------------------------------------------

public class TestCameraPreview extends Activity {
  private Preview mPreview;
  private CameraOverlay overlay = null;
  private static String LOG_TAG = "TestCameraPreview";
  
  public static final BitmapFactory.Options myDecodeOptions = new BitmapFactory.Options();
  
  private static final String[] PROJECTION = new String[] {
    Images.POST_ID,                    // 0
    Images.PICTURE_ORIENTATION,        // 1
    Images.FILE_NAME_AND_PATH,         // 2
  };
  
  public static final int OFFER_TO_UPLOAD_DIALOG = 0;
  public static final int PREVIEW_OPTIONS_DIALOG = 1;
  
  public TestCameraPreview() {
    super();
    
    myDecodeOptions.inSampleSize = 2;
  }
  
  protected Dialog onCreateDialog(int id) {
    log("Ok, I've got a chance to create my own dialog, id=" + id);
    final Dialog dialog;
    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    AlertDialog alert = null;
    switch (id) {
    case OFFER_TO_UPLOAD_DIALOG:
      builder.setMessage("You have a full set of pictures, would you like to upload them now?");
      builder.setCancelable(false);
      builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User clicked 'Yes' to upload offer");
          
          /// WSW: Hopefully I can just start this service here, and then 
          /// finish this activity once the upload has started.
          Intent uploadService = new Intent(getBaseContext(), ImageUploadService.class);
          startService(uploadService);

          /// WSW: Check this can be reached after startService()...
          // Now that the service has started, we can finish this activity, right?
          finish();
        }
      });
      builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User clicked 'No' to upload offer");
        }
      });
      alert = builder.create();
      dialog = alert;
      break;
    case PREVIEW_OPTIONS_DIALOG:
      // Context mContext = getApplicationContext();
      dialog = new Dialog(this);
      
      dialog.setContentView(R.layout.preview_options_dialog);
      dialog.setTitle("Preview Options");
      
      CheckBox myCheckBox = (CheckBox) dialog.findViewById(R.id.showOnionSkinCheckbox);
      myCheckBox.setChecked(overlay.getShowOnionSkin());
      myCheckBox.setOnCheckedChangeListener( new OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
          overlay.setShowOnionSkin(isChecked);
        }
      });
      
      final SeekBar mySeeker = (SeekBar) dialog.findViewById(R.id.osTransparencySeekbar);
      mySeeker.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
          log("Got a seekbar progress change: " + progress);
          if (overlay != null) {
            overlay.setOnionSkinAlpha(((float) progress) / 100.0);
          } 
        }
        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
          // TODO Auto-generated method stub
        }
        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
          // T  ODO Auto-generated method stub
        } 
      }); 
      
      // The progress of these things goes from 0 to getMax()
      mySeeker.setProgress((int) (overlay.getOnionSkinAlpha() * 100.0));
      
      Button dismissButton = (Button) dialog.findViewById(R.id.options_dismiss_button);
      dismissButton.setOnClickListener(new OnClickListener() {
        public void onClick(View v) {
          dialog.dismiss();
        }
      });
      
      break;
    default:
      dialog = null;
    }
    return dialog;
  }
  
  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    menu.add(R.string.preview_options);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    // example menu
    if (item.getTitle().equals(getResources().getString(R.string.preview_options))) {
      showDialog(PREVIEW_OPTIONS_DIALOG);
    }
    return true;
  }
  
  /*
   * This task is going to check the database for any un-uploaded pictures we have in
   * any direction and make note of which ones we have.  Then in post process function
   * we can set the isUploaded flag of each image in the DEWImage array.
   */
  private class SetUploadedStatusesTask extends AsyncTask<Long, Void, ArrayList<Boolean> > {
    protected ArrayList<Boolean> doInBackground(Long... postIds) {
      ArrayList<Boolean> returnValue = null;
      
      try {
        long postId = postIds[0].longValue(); 
        int numImages = DEW.getDEW().getImages().length;
        returnValue = new ArrayList<Boolean>();
        for (int i = 0; i < numImages; i++) {
          returnValue.add(new Boolean(false));
        }

        ContentResolver cResolver = DEW.getDEW().getApplicationContext().getContentResolver();
        if (cResolver != null) {
          String selection = Images.POST_ID + "=" + postId + " AND " + 
          Images.PICTURE_ID + "=-1";
          log("Selection string is: " + selection);
          final Cursor cursor = cResolver.query(Images.CONTENT_URI, PROJECTION, selection, null, null);

          if (cursor == null) {
            log("ERROR: Got a null SQLite database cursor");
            return returnValue;
          }

          int matchingRowCount = cursor.getCount();
          log("Found " + matchingRowCount + " un-uploaded pics for post " + postId);

          if (matchingRowCount > 0) {  // If we found at least one item
            for (int i = 0; i < matchingRowCount; i++) {
              // move to the next item and get the file name and orientation
              cursor.moveToNext();
              int dbPostId = cursor.getInt(0);
              String dbfName = cursor.getString(2);
              String dbOrient = cursor.getString(1);
              int oIdx = DEW.getDEW().getOrientationIndex(dbOrient);
              log("db row: postId => " + dbPostId + ", file => " + dbfName + ", (orientation " + dbOrient + " corresponds to image index " + oIdx + ")");
              returnValue.set(oIdx, new Boolean(true));
            }
          }
        }
      } catch (Exception e) {
        e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
      }
      
      return returnValue;
    }

    protected void onProgressUpdate() {
      // setProgressPercent(progress[0]);
    }

    protected void onPostExecute(ArrayList<Boolean> result) {
      try {
      for (int i = 0; i < result.size(); i++) {
        if (DEW.getDEW().getImage(i) == null) {
          DEW.getDEW().setImage(i, new DEWImage(DEW.getDEW()));
        }
        DEW.getDEW().getImage(i).setUploaded(result.get(i).booleanValue() == false);
      }
      } catch (Exception e) {
        e.printStackTrace();
        log("Encountered error: " + e.getMessage());
      }
    }
  }
  
  public static void log(String s) {
    DEW.getDEW().log(LOG_TAG, s);
  }

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    setContentView(R.layout.camera);
  }
  
  public void setupPreview() {
    mPreview = new Preview(this);
    
    FrameLayout layout = ((FrameLayout) findViewById(R.id.preview));   
    
    layout.removeAllViews();
    layout.addView(mPreview);
    log("In setupPreview: added SurfaceView (PicPostPreview) to the FrameLayout");
    
    overlay = new CameraOverlay(this);
    overlay.setMessageText("Touch Screen to take picture...");

    if (overlay != null) {
      DEW.getDEW().log.addListener(overlay);
      layout.addView(overlay);
      log("in setupPreview: added CameraOverlay to the FrameLayout");
    }
    
    mPreview.setCameraOverlay(overlay);

    int diff = 75; //(preview.getWidth() - preview.targetX)/2;
    layout.setPadding(diff, 0, diff, 0);
          
    log("Setting the DEW.cam reference to " + this.toString());
    // DEW.getDEW().cam = this;

    // Create our Preview view and set it as the content of our activity.
    
    // setContentView(mPreview);
    mPreview.startScreenUpdateTask();
    
    mPreview.setEnclosingActivity(this);
    
    Rect rect = new Rect();
    layout.getDrawingRect(rect);
    
    log("In setupPreview: drawing rectangle => w: " + rect.width() + ", h: " + rect.height() + 
        ", l: " + rect.left + ", r: " + rect.right + ", b: " + rect.bottom + 
        ", t: " + rect.top);
    
  }
  
  public void onResume() {
    super.onResume();
    log("Inside PicPostCamera.onResume()");   
    
    // setupPreview();
    
    PicturePost curPicPost = DEW.getDEW().getCurrentPicturePost();
    long postId = -1;
    
    if (curPicPost != null) {
      postId = Long.parseLong(curPicPost.postAttributeMap.get(PicturePost.POST_ID).toString());
    } else {
      log("ERROR: curPicPost should not !");
    }
    
    DEW.getDEW().setupImages(DEW.getDEW().getCurrentPicturePost());
    new SetUploadedStatusesTask().execute(postId);
    DEW.getDEW().startSensors();
    setupPreview();
  }

  public void onPause() {
    super.onPause();
    log("Inside PicPostCamera.onPause()");

    mPreview.releaseCamera();
    mPreview.setEnclosingActivity(null);
    mPreview.setCameraOverlay(null);
    
    FrameLayout layout = ((FrameLayout) findViewById(R.id.preview));
    layout.removeAllViews();
    
    DEW.getDEW().stopSensors();
    
    log("onPause");
  }

}

// ----------------------------------------------------------------------

class Preview extends SurfaceView implements SurfaceHolder.Callback {
  public static final String TAG = "Test Preview";
    SurfaceHolder mHolder;
    Camera mCamera;
    private CameraOverlay overlay;
    private Runnable updateScreenTask = null;
    private File iFile;
    Activity enclosingActivity = null;
    
    public void setEnclosingActivity(Activity a) {
      enclosingActivity = a;
    }
    
    /*
    private static final String[] PROJECTION = new String[] {
      Images._ID,                 // 0
      Images.POST_ID,             // 1
      Images.PICTURE_SET_ID,      // 2
      Images.PICTURE_ID,          // 3
      Images.PICTURE_ORIENTATION, // 4
      Images.FILE_NAME_AND_PATH,  // 5
      Images.RECORD_CREATE_TIME,  // 6
      Images.PICTURE_SIZE,        // 7
    };
    */
    
    private static final String[] PROJECTION = new String[] {
      Images.POST_ID,                    // 0
      Images.PICTURE_ID,                 // 1
      Images.FILE_NAME_AND_PATH,         // 2
      Images.PICTURE_ORIENTATION,        // 3
      
    };
    
    public void setCameraOverlay(CameraOverlay camOverlay) {
      overlay = camOverlay;
    }
    
    public void releaseCamera() {
      // mCamera.setPreviewCallback(null);
      mCamera.stopPreview();
      mCamera.release();
      mCamera = null;
    }
    
    private class WriteCameraImageTask extends AsyncTask<File, Void, Boolean> {
      private byte[] myImage;
      int picturePostId;
      int orientationIndex;
      SensorDataBundle dataBundle;
      Bitmap imageBitmap = null;
      Bitmap scaledImageBitmap = null;
      
      public WriteCameraImageTask(byte[] imageData, int picPostId, int orientIdx, SensorDataBundle dbundle) {
        myImage = imageData;
        picturePostId = picPostId;
        orientationIndex = orientIdx;
        dataBundle = dbundle;
      }
      
      protected Boolean doInBackground(File... files) {
        Boolean returnValue = Boolean.FALSE;
        
        try {
          if (myImage != null && files != null && files.length > 0) {
            iFile = files[0];

            ContentValues values = new ContentValues();

            // imageBitmap = null;
            
            try {
              // imageBitmap = BitmapFactory.decodeByteArray(myImage, 0, myImage.length);
              imageBitmap = BitmapFactory.decodeByteArray(myImage, 0, myImage.length, TestCameraPreview.myDecodeOptions);
            } catch (OutOfMemoryError err) {
              log("  ERROR!!! Caught out of memory error decoding byte array for image of length " + myImage.length);
              // Toast.makeText(getContext(), "Please try that again.", Toast.LENGTH_SHORT);
              return returnValue;
            }
            
            Float width  = new Float(imageBitmap.getWidth());
            Float height = new Float(imageBitmap.getHeight());
            Float ratio = width/height;
            scaledImageBitmap = Bitmap.createScaledBitmap(imageBitmap, (int)(DEW.THUMBNAIL_HEIGHT*ratio), DEW.THUMBNAIL_HEIGHT, false);
            // Bitmap scaledImageBitmap = Bitmap.createScaledBitmap(imageBitmap, (int)(DEW.THUMBNAIL_HEIGHT*ratio), DEW.THUMBNAIL_HEIGHT, false);
            
            // imageBitmap.recycle();
            
            ByteArrayOutputStream baos = new ByteArrayOutputStream();  
            scaledImageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] byteArray = baos.toByteArray();
            baos.flush();
            baos.close();

            values.put(Images.THUMBNAIL, byteArray);

            // int padding = (DEW.getDEW().THUMBNAIL_WIDTH - imageBitmap.getWidth())/2;
            // imageView.setPadding(padding, 0, padding, 0);
            // imageView.setImageBitmap(imageBitmap);

            // Get the record for this post and direction from the database,
            // if such a record exists.
            ContentResolver cResolver = DEW.getDEW().getApplicationContext().getContentResolver();
            if (cResolver != null) {
              String directionStr = DEW.directions[orientationIndex];
              String selection = Images.POST_ID + "=" + picturePostId + " AND " + 
              Images.PICTURE_ORIENTATION + "='" + directionStr + "'" + " AND " +
              Images.PICTURE_ID + "=-1";
              
              log("Selection string is: " + selection);
              
              final Cursor cursor = cResolver.query(Images.CONTENT_URI, PROJECTION, selection, null, null);

              if (cursor == null) {
                log("ERROR: Returned SQLite database cursor was null");
                return Boolean.FALSE;
              }

              int matchingRowCount = cursor.getCount();

              if (matchingRowCount > 0) {  // If we found an item

                log(matchingRowCount + " records returned from database, cursor is " + (cursor.isBeforeFirst() == true ? "" : "not") + " before first row");
                if (cursor.isBeforeFirst()) {
                  cursor.moveToNext();
                }

                // int postId = cursor.getInt(0);
                // int pictureId = cursor.getInt(1);
                String existingFileName = cursor.getString(2);         // 
                // String pictureOrientation = cursor.getString(3);              // "full", "medium", or "thumb"
                iFile = new File(existingFileName);
                // Update the record with the new thumbnail, everything else
                // stays the same for now
                int numberOfRowsUpdated = cResolver.update(Images.CONTENT_URI, values, selection, null);
                log(numberOfRowsUpdated + " were updated with the new thumbnail");
              } else {               // If we didn't find an item
                log("Didn't find a matching record, so I'm going to create one");
                String nameAndPath = iFile.getPath();
                log("Image file name: " + nameAndPath);

                values.put(Images.FILE_NAME_AND_PATH, nameAndPath);
                values.put(Images.PICTURE_ID, -1);
                values.put(Images.PICTURE_SET_ID, -1);
                values.put(Images.POST_ID, picturePostId);
                values.put(Images.RECORD_CREATE_TIME, PictureFileHandling.dewDateFormat.format(new Date()));
                values.put(Images.PICTURE_ORIENTATION, directionStr);
                values.put(Images.PICTURE_SIZE, "full");

                // Insert the row and get the resulting
                Uri resultUri = cResolver.insert(Images.CONTENT_URI, values);
                log("Result of inserting row into db: " + resultUri);
              }

              cursor.close();
            }

            // Preview.this.writeImageFile(myImage, iFile);
            PictureFileHandling.writeImageFile(myImage, iFile, dataBundle);
            
            // scaledImageBitmap.recycle();
            
            returnValue = Boolean.TRUE;
          }
        } catch (Exception e) {
          e.printStackTrace();
          log("Encountered error in WriteCameraImageTask: " + e.getMessage());
        }
        
        return returnValue;
      }

      protected void onProgressUpdate() {
        
      }

      protected void onPostExecute(Boolean value) {
        
        if (myImage != null) {
          log("Nulling out the byte array holding this image's data.");
          myImage = null;
        }
        
        if (imageBitmap != null) {
          log("Recycling and nulling out the imageBitmap.");
          imageBitmap.recycle();
          imageBitmap = null;
        }
        
        if (scaledImageBitmap != null) {
          log("Recycling and nulling out the scaledImageBitmap.");
          scaledImageBitmap.recycle();
          scaledImageBitmap = null;
        }
        
        System.gc();
        
        if (value == Boolean.FALSE) {
          log("Failed to write file, something bad happened");
          if (overlay != null) {
            overlay.setMessageText("Touch Screen to take picture...");
            Toast.makeText(getContext(), "Encountered an error taking picture, please restart DEW.", Toast.LENGTH_LONG);
          }
          return;
        }
        
        try {
          log("Finished writing image file: " + iFile.getName());
          if (overlay != null) {
            overlay.setMessageText("Touch Screen to take picture...");
            DEW.getDEW().getImage(orientationIndex).setUploaded(false);
            int uploadableCount = 0;
            for (DEWImage img : DEW.getDEW().getImages()) {
              if (img.isUploaded() == false) {
                uploadableCount++;
              }
            }
            if (uploadableCount == DEW.getDEW().getImages().length) {
              if (enclosingActivity != null) {
              log("Showing the upload offer");
              enclosingActivity.showDialog(TestCameraPreview.OFFER_TO_UPLOAD_DIALOG);
              }
            } else {
              log("Not showing the offer because the uploadable count was only " + uploadableCount);
            }
          }
        } catch (Exception e) {
          e.printStackTrace();
          log("Encountered error in WriteCameraImageTask: " + e.getMessage());
        }
      }
    }
    
    ShutterCallback myShutterCallback = new ShutterCallback() {
      public void onShutter() {
        log("Preview.onShutter() called");
      }
    };

    /** Handles data for raw picture */
    PictureCallback myRawCallback = new PictureCallback() {
      public void onPictureTaken(byte[] data, Camera camera) {
        log("Preview.onPictureTaken() called - raw");
      }
    };

    /** Handles data for jpeg picture */
    PictureCallback myJpegCallback = new PictureCallback() {
      public void onPictureTaken(byte[] data, Camera camera) {
        log("Preview.onPictureTaken() called - jpeg with " + ( data == null ? "NULL data" : (data.length + " bytes of data")));
        
        int idx = 0;
        float orient = 0.0f;
        
        if (overlay != null) {
          overlay.setMessageText("writing picture to disk...");
          idx = overlay.currentOrientationIndex;
          orient = overlay.pictureRealOrientation;
        }
        
        PicturePost curPicPost = DEW.getDEW().getCurrentPicturePost();
        int pId = -1;
        if (curPicPost != null) {
          try {
            pId = Integer.parseInt(curPicPost.postAttributeMap.get(PicturePost.POST_ID).toString());
          } catch (Exception e) {
            e.printStackTrace();
          }
        }
        
        String fileName = "img_" + (new Date()).getTime() + ".jpg" ;
        File imageFile = getFile(fileName);
        
        SensorDataBundle bundle = null;
        
     // if (doIncludeSensorDataInExif == true) {
        if (DEW.getDEW().getGpsToExif() == true) {
          log(" $$$$$$$$$$$$$$$$$$$$ Going to write extra exif data $$$$$$$$$$$$$$$$$$$$$ ");
          bundle = new SensorDataBundle();
          bundle.setAccelerometerX(overlay.currentAccelX);
          bundle.setAccelerometerY(overlay.currentAccelY);
          bundle.setAccelerometerZ(overlay.currentAccelZ);
          bundle.setAltitude(overlay.getLastAlt());
          bundle.setLatitude(overlay.getLastLat());
          bundle.setLongitude(overlay.getLastLon());
          bundle.setOrientationDirection(overlay.pictureRealOrientation);
        } else {
          log(" $$$$$$$$$$$$$$$$$$$$ Not going to write extra exif data $$$$$$$$$$$$$$$$$$$$$ ");
        }
        
        new WriteCameraImageTask(data, pId, idx, bundle).execute(imageFile);
        
        // File file = PictureFileHandling.writePicture(data, getOverlay().currentOrientationIndex); 
        data = null;
        // DEW.getDEW().setCurrentPicture(file.getAbsolutePath(), getOverlay().currentOrientationIndex, getOverlay().pictureRealOrientation, false);

        Runtime.getRuntime().gc();

        getHandler().postDelayed(new Runnable() {
          public void run() {         
            mCamera.startPreview();
          }
        }, 500);
      }
    };
    
    ErrorCallback myErrorCallback = new ErrorCallback() {
      @Override
      public void onError(int error, Camera camera) {
        log("Received an error with number <" + error + ">, camera is: " + camera.toString());
      }
    };

    Preview(Context context) {
        super(context);

        // Install a SurfaceHolder.Callback so we get notified when the
        // underlying surface is created and destroyed.
        mHolder = getHolder();
        mHolder.addCallback(this);
        mHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
    }

    public void surfaceCreated(SurfaceHolder holder) {
      log("Inside TestCameraPreview.surfaceCreated()");
        // The Surface has been created, acquire the camera and tell it where
        // to draw.
        mCamera = Camera.open();
        try {
           mCamera.setPreviewDisplay(holder);
        } catch (IOException exception) {
            mCamera.release();
            mCamera = null;
            // TODO: add more exception handling logic here
        }
    }

    public void surfaceDestroyed(SurfaceHolder holder) {
      log("Inside TestCameraPreview.surfaceDestroyed()");
        // Surface will be destroyed when we return, so stop the preview.
        // Because the CameraDevice object is not a shared resource, it's very
        // important to release it when the activity is paused.
      if (mCamera != null) {
        mCamera.stopPreview();
        mCamera.release();
        mCamera = null;
      }
    }
    
    
    public void startScreenUpdateTask() {
      log("Inside startScreenUpdateTask");
      if (overlay != null) {
        log("overlay is non-null");
        
        if (updateScreenTask == null) {
          log("updateScreenTask is null, so we need to initialize it");
          updateScreenTask = new Runnable() {
            public void run() {
              //log("Inside the updateScreenTask Runnable, going to set orientation and invalidate the overlay.");
              if (overlay != null) {
                overlay.setCurrentOrientation();
                overlay.invalidate();
                getHandler().postDelayed(updateScreenTask, DEW.uiFreq);
              }
            }
          };

          postDelayed(updateScreenTask, DEW.uiFreq);
        }
      }
    }


    private Size getOptimalPreviewSize(List<Size> sizes, int w, int h) {
      final double ASPECT_TOLERANCE = 0.05;
      double targetRatio = (double) w / h;
      if (sizes == null) return null;

      Size optimalSize = null;
      double minDiff = Double.MAX_VALUE;

      int targetHeight = h;

      // Try to find an size match aspect ratio and size
      for (Size size : sizes) {
        double ratio = (double) size.width / size.height;
        if (Math.abs(ratio - targetRatio) > ASPECT_TOLERANCE) continue;
        if (Math.abs(size.height - targetHeight) < minDiff) {
          optimalSize = size;
          minDiff = Math.abs(size.height - targetHeight);
        }
      }

      // Cannot find the one match the aspect ratio, ignore the requirement
      if (optimalSize == null) {
        log("Couldn't find a size to match the aspect ratio (width => " + w + 
            ", height =>" + h + "), ignoring that requirement");
        minDiff = Double.MAX_VALUE;
        for (Size size : sizes) {
          if (Math.abs(size.height - targetHeight) < minDiff) {
            optimalSize = size;
            minDiff = Math.abs(size.height - targetHeight);
          }
        }
      }

      log("Returning optimal size: width => " + optimalSize.width + ", height => " + optimalSize.height);
      return optimalSize;
    }

    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
      log("Inside TestCameraPreview.surfaceChanged(holder => " + holder.toString() + 
          ", format => " + format + ", width => " + w + ", height => " + h + ")");
      // Now that the size is known, set up the camera parameters and begin
      // the preview.
      Camera.Parameters parameters = mCamera.getParameters();
      
      Size selectedPictureSize = parameters.getPictureSize();
      log("Selected picture size: " + selectedPictureSize.width + " x " + selectedPictureSize.height + " pixels");

      List<Size> sizes = parameters.getSupportedPreviewSizes();
      Size optimalSize = getOptimalPreviewSize(sizes, w, h);
      parameters.setPreviewSize(optimalSize.width, optimalSize.height);
      
      log("Camera parameters:\n" + parameters.flatten());

      mCamera.setParameters(parameters);
      mCamera.startPreview();
    }
    
    public boolean onTouchEvent(MotionEvent evt) {
      log("Inside touch event handler");
      
      if (mCamera != null) {
        log("on click: adding error callback");
        mCamera.setErrorCallback(myErrorCallback);
        log("on click: takePicture");
        mCamera.takePicture(myShutterCallback, myRawCallback, myJpegCallback);
      } else {
        log("Click pressed but no camera...");
      }
      
      return false;
    }
    
    public static void log(String s) {
      DEW.getDEW().log(TAG, s);
    }
    
    private File getDirectory() {
      File root = Environment.getExternalStorageDirectory();
      File dir = new File(root, "DEW-PicturePost");
      log("Needed to make directory: " + dir.mkdirs());
      return dir;
    }

    private File getFile(String fname) {
      File file = new File(getDirectory(), fname);
      return file;    
    }
    
    

}
