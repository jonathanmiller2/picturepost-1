package com.citizapps.dew.camera;


import java.io.IOException;
import java.util.List;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.PreviewCallback;
import android.hardware.Camera.Size;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.citizapps.dew.DEW;


class PicPostPreview extends SurfaceView implements SurfaceHolder.Callback {
	private static final String LOG_TAG = "PicPostPreview";

	SurfaceHolder mHolder;
	private Camera _camera;
	private static final int defaultPreviewFrameRate = 15;
	
	int targetX, targetY;

	PicPostPreview(Context context) {
		super(context);

		// Install a SurfaceHolder.Callback so we get notified when the
		// underlying surface is created and destroyed.
		mHolder = getHolder();
		mHolder.addCallback(this);
		mHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		log("Leaving PicPostPreview constructor...");
	}

	public void surfaceCreated(SurfaceHolder holder) {
	  log("Inside PicPostPreview.surfaceCreated(holder => " + holder.toString() + ")");
		setup(holder);
	}
	
	public void setup(SurfaceHolder holder) {
		// The Surface has been created, acquire the camera and tell it where
		// to draw.
		getCamera();
	}
	
	public Camera getCamera() {
		if (_camera != null) return _camera;
		
		try {
		  log("STEP ONE: call Camera.open()");
			_camera = Camera.open();
			
			log("Ok, camera now open");
			
		} catch (RuntimeException e) {
			log("Uh Oh.  Failed to open camera.");
			log(e.getMessage());
			return null;
		}
		return _camera;
	}
	
	public Camera startPreview() {
		try {
			_camera.setPreviewDisplay(getHolder());
			log("STEP FOUR: call setPreviewDisplay");
			_camera.setPreviewCallback(new PreviewCallback() {
				public void onPreviewFrame(byte[] data, Camera arg1) {
					// invalidate();
				}
			});
			log("STEP FIVE: Calling _camera.startPreview()...");
			_camera.startPreview();
			log("STEP FIVE: called _camera.startPreview");
			// PicPostCamera ppcam = DEW.getDEW().cam;
		  // ppcam.getHandler().postDelayed(ppcam.updateScreenTask, DEW.uiFreq);
		} catch (IOException e) {
			e.printStackTrace();
			log("IO Exception when setting up camera.");
		}
		
		return _camera;
	}
	
	public void releaseCamera() {
		if (_camera  != null) {
		  log("RELEASING CAMERA!");
			_camera.setPreviewCallback(null);
			_camera.release();
			_camera = null;
		}
	}
	
	
	public void surfaceDestroyed(SurfaceHolder holder) {
		// Surface will be destroyed when we return, so stop the preview.
		// Because the CameraDevice object is not a shared resource, it's very
		// important to release it when the activity is paused.
		
		log("Surface Destroyed");
		if (_camera != null) _camera.stopPreview();
		//releaseCamera();
	}

	/**
	 * OptimalPreviewSize 
	 * from http://developer.android.com/resources/samples/ApiDemos/src/com/example/android/apis/graphics/CameraPreview.html
	 * @param sizes
	 * @param w
	 * @param h
	 * @return
	 */
	/*
	private Size getOptimalPreviewSize(List<Size> sizes, int w, int h, double targetRatio) {
	  final double ASPECT_TOLERANCE = 0.05;
	  if (sizes == null) return null;

	  Size optimalSize = null;
	  double minDiff = Double.MAX_VALUE;

	  int targetHeight = h;

	  // Try to find an size match aspect ratio and size
	  for (Size size : sizes) {
	    double ratio = (double) size.width / size.height;
	    if (Math.abs(ratio - targetRatio) > ASPECT_TOLERANCE) continue;
	    if (Math.abs(size.height - targetHeight) < minDiff) {
	      optimalSize = size;
	      minDiff = Math.abs(size.height - targetHeight);
	    }
	  }

	  // Cannot find the one match the aspect ratio, ignore the requirement
	  if (optimalSize == null) {
	    log("Couldn't find a size to match the aspect ratio (width => " + w + 
	        ", height =>" + h + "), ignoring that requirement");
	    minDiff = Double.MAX_VALUE;
	    for (Size size : sizes) {
	      if (Math.abs(size.height - targetHeight) < minDiff) {
	        optimalSize = size;
	        minDiff = Math.abs(size.height - targetHeight);
	      }
	    }
	  }

	  log("Returning optimal size: width => " + optimalSize.width + ", height => " + optimalSize.height);
	  return optimalSize;
	}
	*/
	
  private Size getOptimalPreviewSize(List<Size> sizes, int w, int h) {
    final double ASPECT_TOLERANCE = 0.05;
    double targetRatio = (double) w / h;
    if (sizes == null) return null;

    Size optimalSize = null;
    double minDiff = Double.MAX_VALUE;

    int targetHeight = h;

    // Try to find an size match aspect ratio and size
    for (Size size : sizes) {
      double ratio = (double) size.width / size.height;
      if (Math.abs(ratio - targetRatio) > ASPECT_TOLERANCE) continue;
      if (Math.abs(size.height - targetHeight) < minDiff) {
        optimalSize = size;
        minDiff = Math.abs(size.height - targetHeight);
      }
    }

    // Cannot find the one match the aspect ratio, ignore the requirement
    if (optimalSize == null) {
      log("Couldn't find a size to match the aspect ratio (width => " + w + 
          ", height =>" + h + "), ignoring that requirement");
      minDiff = Double.MAX_VALUE;
      for (Size size : sizes) {
        if (Math.abs(size.height - targetHeight) < minDiff) {
          optimalSize = size;
          minDiff = Math.abs(size.height - targetHeight);
        }
      }
    }

    log("Returning optimal size: width => " + optimalSize.width + ", height => " + optimalSize.height);
    return optimalSize;
  }
	
	private Size getPictureSize(List<Size> sizes) {
		Size best = null;
		
		// finds minimum size to avoid problems
		for (Size size : sizes) {
			if (best == null || (best.width > size.width && best.height > size.height)) {
				best = size;
			}
 		}
		
		return best;
	}
	
	private int getAppropriateFrameRate(List<Integer> supportedRates) {
	  int returnValue = defaultPreviewFrameRate;
	  if (supportedRates != null) {
	    Integer rate = supportedRates.get(supportedRates.size() - 1);
	    if (rate != null) {
	      returnValue = rate.intValue();
	    } 
	  }
	  log("selected frame rate: " + returnValue);
	  return returnValue;
	}
	 
	public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
	  log("Inside PicPostPreview.surfaceChanged(SurfaceHolder => " + holder.toString() + 
	      ", format => " + format + ", w => " + w + ", h => " + h + ")");
		// Now that the size is known, set up the camera parameters and begin
		// the preview.
		Camera camera = getCamera();
		if (camera != null) {
			Camera.Parameters parameters = camera.getParameters();
			log("STEP TWO: get parameters");
			CameraParameterManager.logCameraCapabilities(parameters);
      CameraParameterManager.logCameraParameters(parameters);
      
			Size camSize = getPictureSize(parameters.getSupportedPictureSizes());
      log("Selected picture size: " + camSize.width + " x " + camSize.height + " pixels");
      parameters.setPictureSize(camSize.width, camSize.height);
      
			// double targetAspect = (double)camSize.width/camSize.height;
			
			// Size p = getOptimalPreviewSize(parameters.getSupportedPreviewSizes(), w, h, targetAspect);
			Size p = getOptimalPreviewSize(parameters.getSupportedPreviewSizes(), w, h);
			
			log("target size: " + p.width + ", " + p.height);
			
			targetX = p.width;
			targetY = p.height;						
			
			parameters.setPreviewSize(targetX, targetY);
			// parameters.setPreviewSize(720, 480);
			
			// parameters.setPreviewFrameRate(15);
			int previewFrameRate = getAppropriateFrameRate(parameters.getSupportedPreviewFrameRates());
			parameters.setPreviewFrameRate(previewFrameRate);
			parameters.setJpegQuality(100);
			// parameters.setFocusMode(Parameters.FOCUS_MODE_INFINITY);
			parameters.setFocusMode(Parameters.FOCUS_MODE_AUTO);
			
			if (h!=targetY || w!=targetX) {
				holder.setFixedSize(targetX, targetY);
				holder.getSurface().setSize(targetX, targetY);
			}
						
			camera.setParameters(parameters);
			// log("STEP THREE: set parameters");
			// CameraParameterManager.logCameraParameters(parameters);
			
			log("Still handling SURFACE CHANGED, and now I'm going to call my function to start the camera preview"); 
			startPreview();
		} else {
			log("Camera not found...");
		}
	}

	@Override
	public void draw(Canvas canvas) {
		super.draw(canvas);
		Paint p = new Paint(Color.RED);
		log("draw");
		canvas.drawText("PREVIEW", canvas.getWidth() / 2,
				canvas.getHeight() / 2, p);
	}
	
	DEW getDEW() {
		return (DEW) getContext().getApplicationContext();
	}
	
	public static void log(String msg) {
	  DEW.getDEW().log(LOG_TAG, msg);
	}
	
	/*
	void log(String s) {
		getDEW().log.addMessage(Log.INFO, TAG, s);
	}
	void logD(String s) {
		getDEW().log.addMessage(Log.DEBUG, TAG, s);
	}
	*/

	public void startupCamera() {
		Camera camera = getCamera();
		camera.startPreview();		
	}
	
	
  /*
   * (non-Javadoc)
   * @see android.view.View#onTouchEvent(android.view.MotionEvent)
   */
	/*
  public boolean onTouchEvent(MotionEvent evt) {
    log("Inside touch event handler");
    PicPostCamera cam = getDEW().cam;
    if (cam == null) {
      log("On click but no PP Cam");
    } else {
      if (cam.preview == null) {
        log("Got button press but preview is null...");
        return false;
      }
      Camera camera = cam.preview.getCamera();
      if (camera != null) {
        log("Stopping sensors temporarily during picture taking");
        getDEW().stopSensors();
        log("on click: adding error callback");
        camera.setErrorCallback(cam.errorCallback);
        log("on click: takePicture");
        camera.takePicture(cam.shutterCallback, cam.rawCallback, cam.jpegCallback);
      } else {
        log("Click pressed but no camera...");
      }
    }

    return false;
  }
  */
}

