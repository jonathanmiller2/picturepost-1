package com.citizapps.dew.maps;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;

import com.citizapps.dew.DEW;
import com.citizapps.dew.PostViewActivity;
import com.citizapps.dew.model.PicturePost;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.OverlayItem;

public class PicPostItemizedOverlay extends ItemizedOverlay<OverlayItem> {
  
  private static final String LOG_TAG = "PicPostItemizedOverlay";
  
  static void log(String s) {
    DEW.getDEW().log(LOG_TAG, s);
  }

  private ArrayList<OverlayItem> mOverlays = new ArrayList<OverlayItem>();
  private Context mContext = null;

  
  public PicPostItemizedOverlay(Drawable defaultMarker) {
    super(boundCenterBottom(defaultMarker));
  }
  

  public PicPostItemizedOverlay(Drawable defaultMarker, Context context) {
    super(boundCenterBottom(defaultMarker));
    mContext = context;
  }

  
  @Override
  protected OverlayItem createItem(int i) {
    // log("createItem got called with " + i);
    return mOverlays.get(i);
  }

  
  @Override
  public int size() {
    return mOverlays.size();
  }
  
  
  @Override
  protected boolean onTap(int index) {
    PicPostOverlayItem item = (PicPostOverlayItem) mOverlays.get(index);
    int postId = item.myPostId;
    PicturePost post = item.myPost;
    
    DEW.getDEW().setPostID(new Integer(postId));
    DEW.getDEW().setCurrentPicturePost(post);
    Intent viewPostActivity = new Intent(mContext, PostViewActivity.class);
    mContext.startActivity(viewPostActivity);
    
    /*
    AlertDialog.Builder dialog = new AlertDialog.Builder(mContext);
    dialog.setTitle(item.getTitle());
    dialog.setMessage(item.getSnippet());
    dialog.show();
    */
    
    return true;
  }
  
  
  public void addOverlay(OverlayItem overlay) {
    // log("Adding overlay: " + overlay.toString());
    mOverlays.add(overlay);
    // populate();
  } 
  
  public void clearAllOverlays() {
    mOverlays.clear();
  }
  
  public void populateNow() {
    populate();
  }

}
