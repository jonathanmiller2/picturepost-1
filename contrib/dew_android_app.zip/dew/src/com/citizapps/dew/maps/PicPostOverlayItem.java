package com.citizapps.dew.maps;

import com.citizapps.dew.model.PicturePost;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.OverlayItem;

public class PicPostOverlayItem extends OverlayItem {
  
  public int myPostId;
  public PicturePost myPost;

  public PicPostOverlayItem(GeoPoint point, String title, String snippet) {
    super(point, title, snippet);
  }
  
  
  public PicPostOverlayItem(GeoPoint point, String title, String snippet, int postId, PicturePost post) {
    super(point, title, snippet);
    
    myPostId = postId;
    myPost = post;
  }
}
