package com.citizapps.dew;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.citizapps.dew.camera.TestCameraPreview;
import com.citizapps.dew.io.PictureFileHandling;
import com.citizapps.dew.model.ImageRecord.Images;
import com.citizapps.dew.model.PicturePost;
import com.citizapps.dew.service.ImageUploadService;

public class PostViewActivity extends Activity {
  
  public final static String LOG_TAG = "PostViewActivity";
  
  private static Handler mHandler = null;
  
  public static Handler getHandler() {
    return mHandler;
  }
  
  public static final int NO_PICTURES_TO_UPLOAD = 0;
  public static final int PICTURES_UPLOADED_IN_BACKGROUND = 1;
  public static final int FAILED_TO_UPLOAD_MOBILE_NUMBER = 2;
  
  protected Dialog onCreateDialog(int id) {
    Dialog dialog;
    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    AlertDialog alert = null;
    switch (id) {
    case NO_PICTURES_TO_UPLOAD:
      builder.setMessage("You must first take some pictures at this post before you can upload them!");
      builder.setCancelable(false);
      builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User clicked 'Ok' to the 'no pics to upload' message");
        }
      });
      alert = builder.create();
      dialog = alert;
      break;
    case PICTURES_UPLOADED_IN_BACKGROUND:
      builder.setMessage("Your pictures are being uploaded.  Please feel free to carry on.");
      builder.setCancelable(false);
      builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User clicked 'Ok' to the 'your pics are being uploaded' message");
        }
      });
      alert = builder.create();
      dialog = alert;
      break;
    case FAILED_TO_UPLOAD_MOBILE_NUMBER:
      builder.setMessage("Invalid mobile phone number, uploading pictures failed.  " + 
          "Please use the Preferences menu to enter the mobile phone number " +
          "associated with your DEW account");
      builder.setCancelable(false);
      builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User clicked 'Ok' to the 'your pics are being uploaded' message");
        }
      });
      alert = builder.create();
      dialog = alert;
      break;
    default:
      dialog = null;
    }
    return dialog;
  }
  
  private static final String[] PROJECTION = new String[] {
    Images.POST_ID,                    // 0
    Images.PICTURE_ID,                 // 1
    Images.THUMBNAIL,                  // 2
    Images.PICTURE_ORIENTATION,        // 3
  };
  
  
  static void log(String s) {
    // DEW.getDEW().log.addMessage(Log.INFO, LOG_TAG, s);
    DEW.getDEW().log(LOG_TAG, s);
  }
  
  public class ImageAdapter extends BaseAdapter {
    int mGalleryItemBackground;
    private Context mContext;
    private long pictureSetId;
    boolean myPics = false;
    private long postId;
    
    public ImageAdapter(Context c) {
        mContext = c;
        TypedArray a = obtainStyledAttributes(R.styleable.HelloGallery);
        mGalleryItemBackground = a.getResourceId(R.styleable.HelloGallery_android_galleryItemBackground, 0);
        a.recycle();
    }
    
    private class FetchThumbnailImageTask extends AsyncTask<Long, Void, Bitmap> {
      
      private int position;
      private String orientation;
      private ImageView imageView;
      
      public FetchThumbnailImageTask(ImageView v) {
        super();
        imageView = v;
      }
      
      protected Bitmap doInBackground(Long... vals) {
        Bitmap returnValue = null;
        
        try {
          position = (int) vals[0].longValue();
          orientation = DEW.getDEW().directions[position];

          if (myPics == false) {
            returnValue = PictureFileHandling.getImage(pictureSetId, orientation, "thumb");
          } else {
            ContentResolver cResolver = DEW.getDEW().getApplicationContext().getContentResolver();
            if (cResolver != null) {
              String selection = Images.POST_ID + "=" + postId + " AND " + 
              Images.PICTURE_ORIENTATION + "='" + orientation + "'" + " AND " +
              Images.PICTURE_ID + "=-1";
              log("Selection string is: " + selection + ", position in gallery is: " + position);
              final Cursor cursor = cResolver.query(Images.CONTENT_URI, PROJECTION, selection, null, null);

              if (cursor == null) {
                log("ERROR: Returned SQLite database cursor was null");
                return null;
              }

              int matchingRowCount = cursor.getCount();

              if (matchingRowCount > 0) {  // If we found an item
                log("We found an item");
                if (cursor.isBeforeFirst()) {
                  cursor.moveToNext();
                  byte[] imageData = cursor.getBlob(2);
                  log("returning a decoded byte array as an image of length: " + imageData.length);
                  returnValue = BitmapFactory.decodeByteArray(imageData, 0, imageData.length);
                }
              }

              cursor.close();
            }
          }
        } catch (Exception e) {
          e.printStackTrace();
          Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        
        return returnValue;
      }

      protected void onProgressUpdate() {
        // setProgressPercent(progress[0]);
      }

      protected void onPostExecute(Bitmap image) {
        try {
          imageView.setImageBitmap(image);
        } catch (Exception e) {
          e.printStackTrace();
          Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
      }
    }
    
    public void setMyPics(boolean b) {
      myPics = b;
    }
    
    public void setPictureSetId(long id) {
      pictureSetId = id;
    }
    
    public void setPostId(long id) {
      postId = id;
    }

    public int getCount() {
        return 9;
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView i = new ImageView(mContext);

        // i.setImageResource(mImageIds[position]);
        i.setLayoutParams(new Gallery.LayoutParams(150, 100));
        // i.setLayoutParams(new Gallery.LayoutParams(90, 60));
        i.setScaleType(ImageView.ScaleType.FIT_XY);
        i.setBackgroundResource(mGalleryItemBackground);
        
        new FetchThumbnailImageTask(i).execute(new Long(position));

        return i;
    }
  } // end:  public class ImageAdapter extends BaseAdapter {
  
  
  private class FetchPostPicImageTask extends AsyncTask<Long, Void, Bitmap> {
    public FetchPostPicImageTask() {
      super();
      PostViewActivity.log("Inside FetchPostPicImageTask() ");
    }
    
    protected Bitmap doInBackground(Long... vals) {
      Bitmap returnValue = null;
      try {
        long postId = vals[0].longValue();
        long pictureId = vals[1].longValue();
        PostViewActivity.log("Going to get post thumb for post " + postId + ", thumb " + pictureId);
        returnValue = PictureFileHandling.getPostThumb(postId, (int) pictureId);
      } catch (Exception e) {
        e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
      }
      return returnValue;
    }
    
    protected void onProgressUpdate() { /* TODO: progress updates */ }

    protected void onPostExecute(Bitmap image) {
      try {
        ImageView imageView = (ImageView) findViewById(R.id.post_thumb);
        imageView.setImageBitmap(image);
      } catch (Exception e) {
        e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
      }
    }
  }

  
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    
    setContentView(R.layout.postview);
    
    PicturePost currentPost = DEW.getDEW().getCurrentPicturePost();
    
    if (currentPost != null && currentPost.postAttributeMap != null) {  
      
      long currentPostId = Long.parseLong(currentPost.postAttributeMap.get(PicturePost.POST_ID).toString());
      DEW.getDEW().setPostID((int) currentPostId);
      
      Object obj = null;
      
      TextView postNameTextView = (TextView) findViewById(R.id.viewPost_name);
      obj = currentPost.postAttributeMap.get(PicturePost.NAME);
      String postName = obj != null ? obj.toString() : "";
      obj = null;
      postNameTextView.setText(postName);
      
      TextView postDescriptionTextView = (TextView) findViewById(R.id.viewPost_description);
      obj = currentPost.postAttributeMap.get(PicturePost.DESCRIPTION);
      String postDescription = obj != null ? obj.toString() : "";
      obj = null;
      postDescriptionTextView.setText(postDescription);
      
      TextView postLocationTextView = (TextView) findViewById(R.id.viewPost_location);
      obj = currentPost.postAttributeMap.get(PicturePost.LATITUDE);
      Object obj2 = currentPost.postAttributeMap.get(PicturePost.LONGITUDE);
      String postLocation = obj != null && obj2 != null ? "Lat: " + obj.toString() + ", Lon: " + obj2.toString() : "";
      obj = null;
      postLocationTextView.setText(postLocation);
      
      TextView postCreatedDateTextView = (TextView) findViewById(R.id.viewPost_created);
      obj = currentPost.postAttributeMap.get(PicturePost.RECORD_TIME_STAMP);
      String postCreatedDate = obj != null ? obj.toString() : "";
      obj = null;
      postCreatedDateTextView.setText(postCreatedDate);
      
      TextView postIdTextView = (TextView) findViewById(R.id.viewPost_id);
      obj = currentPost.postAttributeMap.get(PicturePost.POST_ID);
      String postId = obj != null ? obj.toString() : "";
      postIdTextView.setText(postId);
     
    }
    
    Button uploadPicsButton = (Button) findViewById(R.id.viewPost_upload);
    uploadPicsButton.setOnClickListener(new OnClickListener() {
      public void onClick(View v) {
        log("Upload button clicked");
        Intent uploadService = new Intent(getBaseContext(), ImageUploadService.class);
        startService(uploadService);
      }
    });
    
    Button takePictureButton = (Button) findViewById(R.id.viewPost_take_picture);
    takePictureButton.setOnClickListener(new OnClickListener() {
      public void onClick(View v) {
        // Intent takePictureActivity = new Intent(getBaseContext(), PicPostCamera.class);
        
        log("takePicturesButton handler, about to check if ImageUploadServiceIsRunning");
        
        /// WSW: Is this the only place where the camera activity can be started?  If
        /// so, then we only need to do this here: Check if the upload service is
        /// running, and if it is, we need a way to find out which post's pictures
        /// are being uploaded.
        int uploadingPostId = DEW.getDEW().isIUServiceRunning();
        if (uploadingPostId != -1) {
          log("  !!!!!!!!!!!!! WARNING: The image upload service is currently " + 
              "uploading pictures for post " + uploadingPostId + "!");
        } else {
          log("  The ImageUploadService appears not to be running, it's safe to start the camera activity");
        }
        
        Intent takePictureActivity = new Intent(getBaseContext(), TestCameraPreview.class);
        startActivity(takePictureActivity);
      }
    });
    
    /*
    Button viewPicsButton = (Button) findViewById(R.id.viewPost_view_pictures);
    viewPicsButton.setOnClickListener(new OnClickListener() {
      public void onClick(View v) {
        log("View button clicked");
      }
    });
    */
    
    mHandler = new Handler() {
      public void handleMessage(Message msg) { 
        int whichDialog = msg.getData().getInt("dialogSelection");
        showDialog(whichDialog);
      } 
    };
    
  }
  
  
  /* (non-Javadoc)
   * @see android.app.Activity#onDestroy()
   */
  @Override
  protected void onDestroy() {
    // TODO Auto-generated method stub
    super.onDestroy();
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onPause()
   */
  @Override
  protected void onPause() {
    // TODO Auto-generated method stub
    super.onPause();
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onResume()
   */
  @Override
  protected void onResume() {
    // TODO Auto-generated method stub
    super.onResume();
    
    PicturePost currentPost = DEW.getDEW().getCurrentPicturePost();
    
    if (currentPost != null && currentPost.postAttributeMap != null) {  
      long currentPostId = Long.parseLong(currentPost.postAttributeMap.get(PicturePost.POST_ID).toString());
      DEW.getDEW().setPostID((int) currentPostId);
      
      Gallery g = (Gallery) findViewById(R.id.refPicsGallery);
      ImageAdapter adapter = new ImageAdapter(this);
      long id = -1;
      try {
        id = Long.parseLong(currentPost.postAttributeMap.get(PicturePost.REFERENCE_PICTURE_SET_ID).toString());
      } catch (Exception e){
        e.printStackTrace();
      }
      adapter.setPictureSetId(id);
      adapter.setMyPics(false);
      adapter.setPostId(currentPostId);
      g.setAdapter(adapter);
      g.setOnItemClickListener(new OnItemClickListener() {
        public void onItemClick(AdapterView parent, View v, int position, long id) {
          // Toast.makeText(PostViewActivity.this, "" + position, Toast.LENGTH_SHORT).show();
        }
      });

      g = (Gallery) findViewById(R.id.myPicsGallery);
      adapter = new ImageAdapter(this);
      adapter.setPictureSetId(-1);
      adapter.setMyPics(true);
      adapter.setPostId(currentPostId);
      g.setAdapter(adapter);
      g.setOnItemClickListener(new OnItemClickListener() {
        public void onItemClick(AdapterView parent, View v, int position, long id) {
          //Toast.makeText(PostViewActivity.this, "" + position, Toast.LENGTH_SHORT).show();
        }
      });
      
      Object obj = currentPost.postAttributeMap.get(PicturePost.POST_PICTURE_ID);
      if (obj != null) {
        long postPictureId = -1;
        
        try {
          postPictureId = Long.parseLong(obj.toString());
          
        } catch (Exception e) {
          log("Caught exception parsing " + obj.toString() + " as a long");
        }
        
        if (postPictureId >= 0) {
          new FetchPostPicImageTask().execute(currentPostId, postPictureId);
        }
      } else {
        log("Whoops, there appears to be no such key as " + PicturePost.POST_PICTURE_ID + 
            " in the map, existing keys are: ");
        for (String key : currentPost.postAttributeMap.keySet()) {
          log("  " + key);
        }
      }
    }
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onStart()
   */
  @Override
  protected void onStart() {
    // TODO Auto-generated method stub
    super.onStart();
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onStop()
   */
  @Override
  protected void onStop() {
    // TODO Auto-generated method stub
    super.onStop();
  }
  
}
