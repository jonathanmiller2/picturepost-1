package com.citizapps.dew;

import java.util.Date;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.citizapps.dew.io.PictureFileHandling;
import com.citizapps.dew.model.PicturePost;

public class CreatePostActivity extends Activity {
  private static final String LOG_TAG = "CreatePostActivity";
  
  private ProgressDialog pDiag = null;
  
  static final int CREATE_POST_FAILED = 0;
  static final int FETCH_POST_FAILED_GO_BACK = 1;
  static final int CREATE_POST_FAILED_MOBILE_NUMBER = 2;
  static final int SUSPECT_LOCATION_VALUES = 3;
  
  private int newlyCreatedPostId = -1;
  
  protected Dialog onCreateDialog(int id) {
    log("Ok, I'm going to get a chance to create my own dialog, id=" + id);
    Dialog dialog;
    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    AlertDialog alert = null;
    switch (id) {
    case CREATE_POST_FAILED:
      builder.setMessage("Failed to create post.  Check your internet connection and try again.");
      builder.setCancelable(false);
      builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User clicked 'Ok' to the post creation failure message");
        }
      });
      alert = builder.create();
      dialog = alert;
      break;
    case FETCH_POST_FAILED_GO_BACK:
      builder.setMessage("Post was created successfully with id " + newlyCreatedPostId + 
                         ", but it could not be retrieved afterwards.  Please check your " + 
                         "internet connection, and then retrieve the post list and look " +
                         "for your new post");
      builder.setCancelable(false);
      builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User clicked 'Ok' to the post creation failure message");
          newlyCreatedPostId = -1;
          CreatePostActivity.this.finish();
        }
      });
      alert = builder.create();
      dialog = alert;
      break;
    case CREATE_POST_FAILED_MOBILE_NUMBER:
      builder.setMessage("Invalid mobile phone number, create post failed.  " + 
          "Please use the Preferences menu to enter the mobile phone number " +
          "associated with your DEW account");
      builder.setCancelable(false);
      builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          CreatePostActivity.this.finish();
        }
      });
      alert = builder.create();
      dialog = alert;
      break;
    case SUSPECT_LOCATION_VALUES:
      builder.setMessage("The location values (both 0.0) indicate you may need to turn on location and/or wait a few minutes until you get a GPS signal");
      builder.setCancelable(false);
      builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("Ok clicked on suspect location values dialog");
        }
      });
      alert = builder.create();
      dialog = alert;
      break;
    default:
      dialog = null;
    }
    return dialog;
  }
  
  /*
   * Instances of this task send post data to the server to create a
   * new picture post, then either show a failure dialog and user
   * stays on create page, or else start another async task which
   * fetches the newly create post from the server
   */
  private class CreatePostTask extends AsyncTask<PicturePost, Void, Integer> {
    protected Integer doInBackground(PicturePost... posts) {
      Integer returnValue = null;
      try {
        returnValue = PictureFileHandling.createPicturePost(posts[0]);
      } catch (Exception e) {
        e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
      }
      return returnValue;
    }

    protected void onProgressUpdate() {
      // setProgressPercent(progress[0]);
    }

    protected void onPostExecute(Integer postId) {
      try {
        if (postId == null) {
          pDiag.cancel();
          log("Failed to create the new post");
          showDialog(CREATE_POST_FAILED);
        } else if (postId.intValue() == -42) {
          // This is the magic number telling us that the request failed because
          pDiag.cancel();
          // of an invalid mobile phone number.
          showDialog(CREATE_POST_FAILED_MOBILE_NUMBER);
        } else {
          log("The new post has been created and the new post id is: " + postId);
          // Start the next async task which now fetches the post we just 
          // created, so that we can get any of the automatically generated 
          // values into our post view screen.
          new RetrievePostTask().execute(postId);
        }
      } catch (Exception e) {
        e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
      }
    }
  }
  
  /*
   * Instances of this task send a post id to the server and then either 
   * show a failure dialog and the user stays on same page, or else
   * start the view post activity with the picture post we received.
   */
  private class RetrievePostTask extends AsyncTask<Integer, Void, PicturePost> {
    int postId;
    protected PicturePost doInBackground(Integer... postIds) {
      PicturePost post = null;
      try {
      newlyCreatedPostId = postId = postIds[0].intValue();
      post = PictureFileHandling.getPicturePostById(postId);
      } catch (Exception e) {
        e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
      }      
      return post;
    }

    protected void onProgressUpdate() {
      // setProgressPercent(progress[0]);
    }

    protected void onPostExecute(PicturePost post) {
      try {
        // Inside here, we know we successfully created the post, so if we failed to
        // retrieve the newly created post, we need to mention that.  Or else we
        // start the viewpost activity after setting the current post 
        pDiag.cancel();

        if (post == null) {        
          log("Failed to fetch the newly created post (id: " + postId + ")");
          // show the dialog which, when 'Ok' is clicked, finishes the create activity
          // so user is taken back to the post list page, which they'll have to back
          // out of and reload if they want to see their post.
          showDialog(FETCH_POST_FAILED_GO_BACK);
        } else {
          log("Retrieved the PicturePost: " + post.toString());

          DEW.getDEW().setPostID((Integer) post.postAttributeMap.get("postId"));
          DEW.getDEW().setCurrentPicturePost(post);
          Intent viewPostActivity = new Intent(getBaseContext(),PostViewActivity.class);
          startActivity(viewPostActivity); 
          CreatePostActivity.this.finish();
        }
      } catch (Exception e) {
        e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
      }
    }
  }
  
  /*
  Intent postListActivity = new Intent(getBaseContext(), PostListActivity.class);
  startActivity(postListActivity);
  */
  
  private EditText postNameTextView;
  private EditText postDescriptionTextView;
  private EditText postLatitudeTextView;
  private EditText postLongitudeTextView;
  private TextView postCreatedDateTextView;
  
  static void log(String s) {
    DEW.getDEW().log(LOG_TAG, s);
  }

  
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    
    setContentView(R.layout.postcreate);
  }
  
  
  /* (non-Javadoc)
   * @see android.app.Activity#onDestroy()
   */
  @Override
  protected void onDestroy() {
    // TODO Auto-generated method stub
    super.onDestroy();
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onPause()
   */
  @Override
  protected void onPause() {
    // TODO Auto-generated method stub
    super.onPause();
    
    DEW.getDEW().stopSensors();
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onResume()
   */
  @Override
  protected void onResume() {
    // TODO Auto-generated method stub
    super.onResume();
    
    // DEW.getDEW().startSensors();
    
    // I don't put this here because I'm calling it before I launch this activity, so 
    // when I get here, the service variable in DEW won't be null.  But I'll still stop
    // the service from here.
    // DEW.getDEW().startSensors();
    postNameTextView = (EditText) findViewById(R.id.createPost_name);
    postNameTextView.setHint("Sample Post Name");
    postDescriptionTextView = (EditText) findViewById(R.id.createPost_description);
    postDescriptionTextView.setHint("Sample Post Description");

    postLatitudeTextView = (EditText) findViewById(R.id.createPost_latitude);
    
    double latitude = 0.0;
    double longitude = 0.0;

    try {
      String value = null;
      try {
        latitude = DEW.getDEW().service.getLastLat();
        value = Double.toString(latitude);
      } catch (Exception e) {
        e.printStackTrace();
      }
      postLatitudeTextView.setText(value == null ? "" : value);
    } catch (Exception e) {
      e.printStackTrace();
    }

    postLongitudeTextView = (EditText) findViewById(R.id.createPost_longitude);

    try {
      String value = null;
      try {
        longitude = DEW.getDEW().service.getLastLon();
        value = Double.toString(longitude);
      } catch (Exception e) {
        e.printStackTrace();
      }
      postLongitudeTextView.setText(value == null ? "" : value);
    } catch (Exception e) {
      e.printStackTrace();
    }

    postCreatedDateTextView = (TextView) findViewById(R.id.createPost_created);
    postCreatedDateTextView.setText(PictureFileHandling.createPostDateFormat.format(new Date()));
    
    Button createPostButton = (Button) findViewById(R.id.createPost_create);
    createPostButton.setOnClickListener(new OnClickListener() {
      public void onClick(View v) {
        PicturePost newPicturePost = new PicturePost();
        String postName = ((TextView) postNameTextView).getText().toString();
        if (postName.compareTo("") == 0) {
          postName = postNameTextView.getHint().toString();
        }
        newPicturePost.postAttributeMap.put(PicturePost.NAME, postName);
        String postDescription = ((TextView) postDescriptionTextView).getText().toString();
        if (postDescription.compareTo("") == 0) {
          postDescription = postDescriptionTextView.getHint().toString();
        }
        newPicturePost.postAttributeMap.put(PicturePost.DESCRIPTION, postDescription);
        newPicturePost.postAttributeMap.put(PicturePost.LATITUDE, ((TextView) postLatitudeTextView).getText().toString());
        newPicturePost.postAttributeMap.put(PicturePost.LONGITUDE, ((TextView) postLongitudeTextView).getText().toString());
        newPicturePost.postAttributeMap.put(PicturePost.INSTALL_DATE, ((TextView) postCreatedDateTextView).getText().toString());
        
        new CreatePostTask().execute(newPicturePost);
        pDiag = ProgressDialog.show(CreatePostActivity.this, "Creating Post", "Please wait while post is created", true, true);
      }
    });
    
    Button cancelButton = (Button) findViewById(R.id.createPost_cancel);
    cancelButton.setOnClickListener(new OnClickListener() {
      public void onClick(View v) {
        log("Cancel button clicked");
        finish();
      }
    });
    
    if (latitude == 0.0 && longitude == 0.0) {
      showDialog(SUSPECT_LOCATION_VALUES);
    }
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onStart()
   */
  @Override
  protected void onStart() {
    // TODO Auto-generated method stub
    super.onStart();
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onStop()
   */
  @Override
  protected void onStop() {
    // TODO Auto-generated method stub
    super.onStop();
  }
  
}
