package com.citizapps.dew.service;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Binder;
import android.os.IBinder;
import android.os.Message;
import android.widget.Toast;

import com.citizapps.dew.DEW;
import com.citizapps.dew.IntroActivity;
import com.citizapps.dew.PostViewActivity;
import com.citizapps.dew.R;
import com.citizapps.dew.io.PictureFileHandling;
import com.citizapps.dew.model.ImageRecord.Images;
import com.citizapps.dew.model.PicturePost;

public class ImageUploadService extends IntentService {
  
  public static final int NOTIF_ID_UPLOADING = 13765;
  
  private int uploadingPostId = -1;
  
  //Binder given to clients
  private final IBinder mBinder = new ImageUploadServiceBinder();
  
  private static final String[] PROJECTION = new String[] {
    Images.POST_ID,                    // 0
    Images.PICTURE_SET_ID,             // 1
    Images.PICTURE_ID,                 // 2
    Images.PICTURE_ORIENTATION,        // 3
    Images.FILE_NAME_AND_PATH,         // 4
    Images._ID,                        // 5
  };
  
  
  /*
   * Here's a hook to allow accessing the post id of the post whose pictures
   * are currently uploading.
   */
  public int getUploadingPostId() {
    return uploadingPostId;
  }
  
  
  @Override
  public IBinder onBind(Intent intent) {
      return mBinder;
  }
  
  
  /**
   * Class used for the client Binder.  Because we know this service always
   * runs in the same process as its clients, we don't need to deal with IPC.
   */
  public class ImageUploadServiceBinder extends Binder {
    public ImageUploadService getService() {
      // Return this instance of LocalService so clients can call public methods
      return ImageUploadService.this;
    }
  }
  
  
  /*
   * A constructor is required, and must call the super IntentService(String)
   * constructor with a name for the worker thread.
   */
  public ImageUploadService() {
    super("ImageUploadService");
  }
  
  @Override
  protected void onHandleIntent(Intent intent) {
    try {
      PicturePost curPicPost = DEW.getDEW().getCurrentPicturePost();
      int postId = Integer.parseInt(curPicPost.postAttributeMap.get(PicturePost.POST_ID).toString());
      uploadingPostId = postId;
      int refPicSetId = Integer.parseInt(curPicPost.postAttributeMap.get(PicturePost.REFERENCE_PICTURE_SET_ID).toString());
      NotificationManager notifMgr = null;
      
      // 2) Get the database handle and query for images with the current post id,
      // whose pictureId is also set to -1;
      ContentResolver cResolver = DEW.getDEW().getApplicationContext().getContentResolver();
      if (cResolver != null) {
        String selection = Images.POST_ID + "=" + postId + " AND " + 
        Images.PICTURE_ID + "=-1";
        log("Selection string is: " + selection);
        final Cursor cursor = cResolver.query(Images.CONTENT_URI, PROJECTION, selection, null, null);

        if (cursor == null) {
          log("ERROR: Got a null SQLite database cursor");
          uploadingPostId = -1;
          return;
        }

        int matchingRowCount = cursor.getCount();
        log("Found " + matchingRowCount + " items to upload for post " + postId);

        if (matchingRowCount > 0) {  // If we found at least one item
          // Create a new picture set and get it's id.  This is going to block,
          // but that's ok because we're running in an IntentService onHandleIntent 
          // method, and it's taking care of the multi-threading for us.
          int pictureSetId = PictureFileHandling.createPictureSet(curPicPost);

          if (pictureSetId == -42) {
            Message message = new Message();
            message.getData().putInt("dialogSelection", PostViewActivity.FAILED_TO_UPLOAD_MOBILE_NUMBER);
            PostViewActivity.getHandler().sendMessage(message);
            if (cursor != null) {
              cursor.close();
            }
            uploadingPostId = -1;
            return;
          }

          Message msg = new Message();
          msg.getData().putInt("dialogSelection", PostViewActivity.PICTURES_UPLOADED_IN_BACKGROUND);
          PostViewActivity.getHandler().sendMessage(msg);
          
          // TODO: 1) This is where we can set up and create the notification.  For
          //       progress purposes, conditionally add 1 to the number of pictures 
          //       to upload and make the setting of the reference id a unit of progress
                // icon from resources
          String ns = Context.NOTIFICATION_SERVICE;
          notifMgr = (NotificationManager) getSystemService(ns);
          
          CharSequence tickerText = "Uploading";              // ticker-text
          long when = System.currentTimeMillis();         // notification time
          Context context = getApplicationContext();      // application Context
          CharSequence contentTitle = "DEW Picture Upload";  // expanded message title
          CharSequence contentText = "Your pictures for post " + postId + " are uploading";      // expanded message text

          Intent notificationIntent = new Intent(this, IntroActivity.class);
          PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);

          // the next two lines initialize the Notification, using the configurations above
          Notification notification = new Notification(R.drawable.upload, tickerText, when);
          notification.flags |= Notification.FLAG_NO_CLEAR | Notification.FLAG_ONGOING_EVENT;
          notification.setLatestEventInfo(context, contentTitle, contentText, contentIntent);
          
          notifMgr.notify(NOTIF_ID_UPLOADING, notification);

          long dbItemId = -1;
          int imageId = -1;
          int numberOfRowsUpdated = -1;
          ContentValues values = new ContentValues();

          for (int i = 0; i < matchingRowCount; i++) {
            // move to the next item and get the file name and orientation
            cursor.moveToNext();
            dbItemId = cursor.getLong(5);
            String curFileName = cursor.getString(4);
            String orientation = cursor.getString(3);

            // Now upload the image file and get the server-generated pictureId
            log("Uploading next file () : " + curFileName);
            String imageIdStr = PictureFileHandling.uploadImage(curFileName, curPicPost, pictureSetId, orientation, true);
            
            imageId = -1;
            
            try {
              imageId = Integer.parseInt(imageIdStr);
            } catch (Exception e) {
              // Could make a note to user in the notification here or cancel the upload or something.
              String errMsg = "Detected an error while attempting to upload: " + imageIdStr;
              log(errMsg);
              Toast.makeText(getBaseContext(), errMsg, Toast.LENGTH_LONG).show();
            }
            
            if (imageId > 0) {
              // Now we need to update the db record with the pictureSetId and pictureId 
              // we got back during this process.
              values.clear();
              values.put(Images.PICTURE_ID, imageId);
              values.put(Images.PICTURE_SET_ID, pictureSetId);
              selection = Images._ID + "=" + "'" + dbItemId + "'";
              numberOfRowsUpdated = cResolver.update(Images.CONTENT_URI, values, selection, null);
              log("Update (" + numberOfRowsUpdated + " rows updated), dbItemId: " + dbItemId + 
                  ", new pictureSetId: " + pictureSetId + ", new pictureId: " + imageId);
            } else {
              log("There was an error uploading the picture, nothing stored in database.");
            }
            
            // TODO: 2) this is probably where we can put progress updates
            
          }
          
          if (refPicSetId <= 0) {
            log("Should be setting " + pictureSetId + " as the ref pic set for post " + postId);
            // Make this newly uploaded picture set the reference picture set
            PictureFileHandling.setReferencePictureSetId(postId, pictureSetId);
            curPicPost.postAttributeMap.put(PicturePost.REFERENCE_PICTURE_SET_ID, new Integer(pictureSetId));
            // TODO: 4) the final progress update.
          } else {
            log("Oh, apparently there's already a ref pic set (" + pictureSetId + ") for post " + postId);
          }
        } else {
          Message msg = new Message();
          msg.getData().putInt("dialogSelection", PostViewActivity.NO_PICTURES_TO_UPLOAD);
          PostViewActivity.getHandler().sendMessage(msg);
        }

        cursor.close();
        
        // TODO: 5) Here's probably where we should take down the notification.
        if (notifMgr != null) {
          notifMgr.cancel(NOTIF_ID_UPLOADING);
        }
        
        uploadingPostId = -1;
      }
    } catch (Exception e) {
      e.printStackTrace();
      Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
    }
  }
        
  private static final String LOG_TAG = "ImageUploadService";
  
  private static void log(String s) {
    DEW.getDEW().log(LOG_TAG, s);
  }
}
