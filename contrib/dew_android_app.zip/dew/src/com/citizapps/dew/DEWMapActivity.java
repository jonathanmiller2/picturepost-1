package com.citizapps.dew;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.telephony.TelephonyManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.Toast;

import com.citizapps.dew.io.PictureFileHandling;
import com.citizapps.dew.maps.CurrentLocationItemizedOverlay;
import com.citizapps.dew.maps.PicPostItemizedOverlay;
import com.citizapps.dew.maps.PicPostOverlayItem;
import com.citizapps.dew.model.PicturePost;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;


public class DEWMapActivity extends MapActivity {
  
  private static final String LOG_TAG = "DEWMapActivity";
  
  static void log(String s) {
    DEW.getDEW().log(LOG_TAG, s);
  }
  
  private String picturePostHost = null;
  private ProgressDialog pDiag = null;
  
  public static boolean stopSensorsOnPause = true;
  
  private static final int YOU_FAILED_GO_BACK = 0;
  private static final int MOBILE_NUMBER_SET = 1;
  private static final int MOBILE_NUMBER_NONE = 2;
  
  private String phoneMobileNumber = null;
  
  
  protected Dialog onCreateDialog(int id) {
    Dialog dialog;
    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    AlertDialog alert = null;
    switch (id) {
    case MOBILE_NUMBER_SET:
      builder.setMessage("You have not yet set up the mobile phone number for your DEW account, " + 
                         "do you want to you use the number of this phone " + 
                         "(" + phoneMobileNumber + ")?  If not, click 'No' " +
                         "and use the Preferences menu to enter the mobile number " +
                         "associated with your DEW account");
      builder.setCancelable(false);
      builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User clicked 'Yes' to using the current phone's mobile number");
          DEW.getDEW().setMobilePhoneNumber(phoneMobileNumber);
        }
      });
      builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User clicked 'No' to using the current phone's mobile number");
        }
      });
      builder.setNeutralButton("Registration Site", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User chose to visit registration site");
          Intent i = new Intent(Intent.ACTION_VIEW);
          String url = getString(R.string.registration_site);
          log("Sending user to registration site at: " + url);
          i.setData(Uri.parse(url));
          startActivity(i);
        }
      });
      alert = builder.create();
      dialog = alert;
      break;
    case MOBILE_NUMBER_NONE:
      builder.setMessage("You have not yet set up the mobile phone number for your DEW account, " + 
                         "and your phone doesn't seem to have a mobile number.  Please use the " + 
                         "Preferences menu to enter the mobile number " +
                         "associated with your DEW account before you attempt to create a post.");
      builder.setCancelable(false);
      builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User clicked 'Ok' to using the current phone's mobile number");
        }
      });
      builder.setNeutralButton("Registration Site", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User chose to visit registration site");
          Intent i = new Intent(Intent.ACTION_VIEW);
          String url = getString(R.string.registration_site);
          log("Sending user to registration site at: " + url);
          i.setData(Uri.parse(url));
          startActivity(i);
        }
      });
      alert = builder.create();
      dialog = alert;
      break;
    default:
      dialog = null;
    }
    return dialog;
  }
  
  
  private class RetrievePostListTask extends AsyncTask<String, Void, ArrayList<PicturePost>> {
    protected ArrayList<PicturePost> doInBackground(String... urls) {
      ArrayList<PicturePost> returnValue = null;      
      try {
        returnValue = PictureFileHandling.getAllPicturePosts(urls[0]);
      } catch (Exception e) {
        e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
      }
      return returnValue;
    }

    protected void onProgressUpdate() {
      // setProgressPercent(progress[0]);
    }

    protected void onPostExecute(ArrayList<PicturePost> picturePostList) {
      try {
        pDiag.cancel();
        if (picturePostList == null) {
          showDialog(YOU_FAILED_GO_BACK);
        } else {
          
          MapView mapView = (MapView) findViewById(R.id.mapview);
          mapView.setBuiltInZoomControls(true);
          
          GeoPoint gp = new GeoPoint((int) (DEW.getDEW().service.getLastLat() * 1e6), 
                                     (int) (DEW.getDEW().service.getLastLon() * 1e6));
          
          mapView.getController().setCenter(gp);
          
          List<Overlay> mapOverlays = mapView.getOverlays();
          
          PicPostItemizedOverlay itemizedOverlay = null;
          CurrentLocationItemizedOverlay clOverlay = null;
          
          log("   PAY ATTENTION!  I'm about to print out the types of overlay");
          for (Overlay overlay : mapOverlays) {
            log("  overlay: " + overlay.getClass().getName());
            if (overlay instanceof PicPostItemizedOverlay) {
              itemizedOverlay = (PicPostItemizedOverlay) overlay;
              itemizedOverlay.clearAllOverlays();
            } else if (overlay instanceof CurrentLocationItemizedOverlay) {
              clOverlay = (CurrentLocationItemizedOverlay) overlay;
              clOverlay.clearAllOverlays();
            }
          }
          
          if (clOverlay == null) {
            Drawable currentLocationDrawable = DEWMapActivity.this.getResources().getDrawable(R.drawable.current_loc);
            clOverlay = new CurrentLocationItemizedOverlay(currentLocationDrawable, DEWMapActivity.this);
          }
          
          GeoPoint currentLoc = new GeoPoint((int) (DEW.getDEW().service.getLastLat() * 1e6),
              (int) (DEW.getDEW().service.getLastLon() * 1e6));
          OverlayItem oItem = new OverlayItem(currentLoc, "Current Location", "This is your current location");
          
          clOverlay.addOverlay(oItem);
          clOverlay.populateNow();
          mapOverlays.add(clOverlay);
          
          if (itemizedOverlay == null) {
            Drawable drawable = DEWMapActivity.this.getResources().getDrawable(R.drawable.redcircle);
            itemizedOverlay = new PicPostItemizedOverlay(drawable, DEWMapActivity.this);
          } 
          
          for (PicturePost picPost : picturePostList) {
            double lat = ((Double) picPost.postAttributeMap.get(PicturePost.LATITUDE)).doubleValue();
            double lon = ((Double) picPost.postAttributeMap.get(PicturePost.LONGITUDE)).doubleValue();
            
            String postName = picPost.postAttributeMap.get(PicturePost.NAME).toString();
            String postDescr = picPost.postAttributeMap.get(PicturePost.DESCRIPTION).toString();
            
            int postId = ((Integer) picPost.postAttributeMap.get(PicturePost.POST_ID)).intValue();
            
            GeoPoint point = new GeoPoint((int) (lat * 1e6), (int) (lon * 1e6));
            OverlayItem overlayitem = new PicPostOverlayItem(point, postName, postDescr, postId, picPost);
            
            itemizedOverlay.addOverlay(overlayitem);
          }
          
          itemizedOverlay.populateNow();
          mapOverlays.add(itemizedOverlay);
          
          mapView.invalidate();
        }
        
        DEW.getDEW().getLoggingToFile();
        
      } catch (Exception e) {
        e.printStackTrace();
        Toast.makeText(getBaseContext(), "Error encountered: " + e.getMessage(), Toast.LENGTH_LONG).show();
      }
    }
  }
  
  
  @Override
  protected boolean isRouteDisplayed() {
      return false;
  }
  
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
      
    setContentView(R.layout.mapview);
    
    ImageButton currentLocationButton = (ImageButton) findViewById(R.id.maps_go_home_button);
    currentLocationButton.setOnClickListener(new OnClickListener() {
      public void onClick(View v) {
        MapView mapView = (MapView) findViewById(R.id.mapview);
        GeoPoint gp = new GeoPoint((int) (DEW.getDEW().service.getLastLat() * 1e6), 
                                   (int) (DEW.getDEW().service.getLastLon() * 1e6));
        mapView.getController().setCenter(gp);
      }
    });
    
    ImageButton listViewButton = (ImageButton) findViewById(R.id.maps_list_button);
    listViewButton.setOnClickListener(new OnClickListener() {
      public void onClick(View v) {
        Intent postListActivity = new Intent(getBaseContext(), PostListActivity.class);
        startActivity(postListActivity);
      }
    });
    
    ImageButton addPostButton = (ImageButton) findViewById(R.id.maps_add_button);
    addPostButton.setOnClickListener(new OnClickListener() {
      public void onClick(View v) {
        DEW.getDEW().startSensors();
        Intent createPostActivity = new Intent(getBaseContext(), CreatePostActivity.class);
        stopSensorsOnPause = false;
        startActivity(createPostActivity);
      }
    });
    
    picturePostHost = DEW.getDEW().getPicturePostHost();
      
    /*
    String url = picturePostHost + "/app/GetPostList?orderBy=name&includePosts=all";
    new RetrievePostListTask().execute(url);
    
    pDiag = ProgressDialog.show(this, "Retrieving Post List", "Please wait while post list is retrieved", true, true);
    */      
  }
  
  @Override
  public void onResume() {
    String configuredMobileNumber = DEW.getDEW().getMobilePhoneNumber();
    long number = -1;
    
    try {
      number = Long.parseLong(configuredMobileNumber);
    } catch (Exception e) {
      e.printStackTrace();
      log("This must be a bad mobile number: " + configuredMobileNumber + ", exception msg: " + e.getMessage());
    }
    
    if (configuredMobileNumber.length() != 10 ||
        number == -1) {
      log("User has not entered their mobile number");
      TelephonyManager mTelephonyMgr;
      mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE); 
      phoneMobileNumber = mTelephonyMgr.getLine1Number();
      log("Telephony service tells us that our phone number is: " + phoneMobileNumber);
      if (phoneMobileNumber != null) {
        showDialog(MOBILE_NUMBER_SET);
      } else {
        showDialog(MOBILE_NUMBER_NONE);
      }
    }
    
    super.onResume();
    
    String url = picturePostHost + "/app/GetPostList?orderBy=name&includePosts=all";
    new RetrievePostListTask().execute(url);
    
    pDiag = ProgressDialog.show(this, "Retrieving Post List", "Please wait while post list is retrieved", true, true);
    
    stopSensorsOnPause = true;
    DEW.getDEW().startSensors();
  }
  
  @Override
  public void onPause() {
    super.onPause();
    
    if (stopSensorsOnPause == true) {
      DEW.getDEW().stopSensors();
    }
  }
  
  
  //  MENUS ------------------------------------------------------------------------
  /* Creates the menu items */
  public static final int MENU_QUIT = 43;

  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.options_menu, menu);
    return true;      
  }

  /* Handles item selections */
  public boolean onOptionsItemSelected(MenuItem item) {
    String url;
    Uri u;
    switch (item.getItemId()) {
    case R.id.quit:
      log("Quit");
      finish();       
      return true;

    // case R.id.downloadimages:
      // setShouldFetchImages(true);
    //   return true;

    case R.id.ppwebpage:
      url = getString(R.string.ppwebpage);
      Intent i = new Intent(Intent.ACTION_VIEW);
      u = Uri.parse(url);
      i.setData(u);
      try {
        startActivity(i);
      } catch (ActivityNotFoundException e) {
        alertInfo("Browser not found.");
      }
      
      return true;

    case R.id.info:
      String s =   "DEW!\n\tusername: " + getDEW().getUsername() 
      + "\n\t\t\t\tversion: " + DEW.VERSION;
      log(s);
      alertInfo(s);


      s = "Preferences:\n";

      SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
      Map<String, ?> map = prefs.getAll();

      for (String name: map.keySet()) {
        s += "\t" + name + ": <" + map.get(name)+">" + " type: " + map.get(name).getClass().getName();
      }
      log(s);

      return true;

    case R.id.preferences:
      log("Preferences menu item pressed.");

      Intent settingsActivity = new Intent(getBaseContext(), DEWPreference.class);
      startActivity(settingsActivity);

      return true;

    default:
      log("Unknown menu item selected: " + item.getTitle());
    }
    return false;
  }
  
  DEW getDEW() {
    return (DEW) getApplication();
  }

  void alertInfo(String alert) {
    Toast.makeText(this,alert, Toast.LENGTH_LONG).show();
  }
  
}
