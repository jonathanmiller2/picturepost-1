package com.citizapps.dew.logging;

import java.util.ArrayList;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.Log;


public class MessageLogger {
	int textSize = 16;
	
	private boolean ignoreMessages = false;
	
	public void disableLogging() {
	  ignoreMessages = true;
	}
	
	public void enableLogging() {
	  ignoreMessages = false;
	}
	
	private ArrayList<String> messages = new ArrayList<String>();
	private int numMessages = 20;
	private ArrayList<MessageListener> listeners = new ArrayList<MessageListener>();

	
	public void addListener(MessageListener listener) {
		listeners.add(listener);
	}
	
	void removeListener(MessageListener listener) {
		listeners.remove(listener);
	}
	

	/**
	 * @return the message
	 */
	ArrayList<String> getMessages() {
		return messages;
	}
	
	public void disable() {
	  ignoreMessages = true;
	}


	/**
	 * @param message the message to set
	 */
	public void addMessage(int type, String tag, String message) {
	  if (ignoreMessages == false) {
	    switch (type) {
	    case Log.WARN:
	      Log.w(tag, message);
	      break;
	    case Log.DEBUG:
	      Log.d(tag, message);
	      break;
	    case Log.ERROR:
	      Log.e(tag, message);
	      break;
	    case Log.INFO:
	      Log.i(tag, message);
	      break;
	    case Log.VERBOSE:
	    default:
	      Log.v(tag, message);
	      break;

	    }
	  }
		
		messages.add(message);
		if (messages.size()>numMessages) messages.remove(0);
		notifyListeners();
	}

	void notifyListeners() {
		for (MessageListener listener : listeners) listener.notify(this);
	}
	
	String lastMessage() {
		if (messages.size() == 0) return null;
		
		return messages.get(messages.size()-1);
	}
	
	public void drawMessages(Canvas c) {
		float y = c.getHeight() - textSize * (messages.size() - 1) ;
		Paint paint = new Paint();
		paint.setARGB(255, 100, 150, 200);
		paint.setTextSize(textSize);
		
		for (String s : messages) {
			c.drawText(s, 0, y, paint);
			y += textSize;
		}
			
	}
}
