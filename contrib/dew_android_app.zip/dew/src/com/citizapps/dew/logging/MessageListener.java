package com.citizapps.dew.logging;



public interface MessageListener {
	public void notify(MessageLogger logger);
}
