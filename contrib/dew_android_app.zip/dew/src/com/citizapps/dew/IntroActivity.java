package com.citizapps.dew;


import java.util.Map;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.telephony.TelephonyManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;


public class IntroActivity extends Activity {
  private static final String LOG_TAG = "IntroActivity";
  
  static void log(String s) {
    DEW.getDEW().log(LOG_TAG, s);
  }
  
  private String phoneMobileNumber = null;
  
  static final int MOBILE_NUMBER_SET = 0;
  static final int MOBILE_NUMBER_NONE = 1;
  
  protected Dialog onCreateDialog(int id) {
    Dialog dialog;
    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    AlertDialog alert = null;
    switch (id) {
    case MOBILE_NUMBER_SET:
      builder.setMessage("You have not yet set up the mobile phone number for your DEW account, " + 
                         "do you want to you use the number of this phone " + 
                         "(" + phoneMobileNumber + ")?  If not, click 'No' " +
                         "and use the Preferences menu to enter the mobile number " +
                         "associated with your DEW account");
      builder.setCancelable(false);
      builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User clicked 'Yes' to using the current phone's mobile number");
          DEW.getDEW().setMobilePhoneNumber(phoneMobileNumber);
        }
      });
      builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User clicked 'No' to using the current phone's mobile number");
        }
      });
      builder.setNeutralButton("Registration Site", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User chose to visit registration site");
          Intent i = new Intent(Intent.ACTION_VIEW);
          String url = getString(R.string.registration_site);
          log("Sending user to registration site at: " + url);
          i.setData(Uri.parse(url));
          startActivity(i);
        }
      });
      alert = builder.create();
      dialog = alert;
      break;
    case MOBILE_NUMBER_NONE:
      builder.setMessage("You have not yet set up the mobile phone number for your DEW account, " + 
                         "and your phone doesn't seem to have a mobile number.  Please use the " + 
                         "Preferences menu to enter the mobile number " +
                         "associated with your DEW account before you attempt to create a post.");
      builder.setCancelable(false);
      builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User clicked 'Ok' to using the current phone's mobile number");
        }
      });
      builder.setNeutralButton("Registration Site", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
          log("User chose to visit registration site");
          Intent i = new Intent(Intent.ACTION_VIEW);
          String url = getString(R.string.registration_site);
          log("Sending user to registration site at: " + url);
          i.setData(Uri.parse(url));
          startActivity(i);
        }
      });
      alert = builder.create();
      dialog = alert;
      break;
    default:
      dialog = null;
    }
    return dialog;
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onCreate(android.os.Bundle)
   */
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    
    super.onCreate(savedInstanceState);
    
    /*
    final Window win = getWindow();
    
    // No Statusbar
    win.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);    
    
    // No Titlebar
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    
    // setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    getWindow().setFormat(Window.FEATURE_NO_TITLE);
    */
    
    setContentView(R.layout.main);
        
    /*
    Button takePictureButton = (Button) findViewById(R.id.take_picture);
    takePictureButton.setOnClickListener(new OnClickListener() {
      public void onClick(View v) {
        Intent takePictureActivity = new Intent(getBaseContext(), TestCameraPreview.class);
        startActivity(takePictureActivity);
      }
    });
    */
    
    Button getPostListButton = (Button) findViewById(R.id.get_post_list);
    getPostListButton.setOnClickListener(new OnClickListener() {
      public void onClick(View v) {
        Intent postListActivity = new Intent(getBaseContext(), PostListActivity.class);
        startActivity(postListActivity);
      }
    });
    
    /*
    Button alternatePreviewButton = (Button) findViewById(R.id.alt_preview);
    alternatePreviewButton.setOnClickListener(new OnClickListener() {
      public void onClick(View v) {
        Intent altPreviewActivity = new Intent(getBaseContext(), TestCameraPreview.class);
        startActivity(altPreviewActivity);
      }
    });
    */
    
    Button createPostButton = (Button) findViewById(R.id.create_post);
    createPostButton.setOnClickListener(new OnClickListener() {
      public void onClick(View v) {
        DEW.getDEW().startSensors();
        Intent createPostActivity = new Intent(getBaseContext(), CreatePostActivity.class);
        startActivity(createPostActivity);
      }
    });
    
    Button showMapViewButton = (Button) findViewById(R.id.show_map_view);
    showMapViewButton.setOnClickListener(new OnClickListener() {
      public void onClick(View v) {
        // DEW.getDEW().startSensors();
        Intent mapViewActivity = new Intent(getBaseContext(), DEWMapActivity.class);
        startActivity(mapViewActivity);
      }
    });
    
    DEW.getDEW().getLoggingToFile();
    
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onDestroy()
   */
  @Override
  protected void onDestroy() {
    // TODO Auto-generated method stub
    super.onDestroy();
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onPause()
   */
  @Override
  protected void onPause() {
    // TODO Auto-generated method stub
    super.onPause();
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onResume()
   */
  @Override
  protected void onResume() {
    log("Inside IntroActivity onResume()");
    String configuredMobileNumber = DEW.getDEW().getMobilePhoneNumber();
    long number = -1;
    
    try {
      number = Long.parseLong(configuredMobileNumber);
    } catch (Exception e) {
      e.printStackTrace();
      log("This must be a bad mobile number: " + configuredMobileNumber + ", exception msg: " + e.getMessage());
    }
    
    if (configuredMobileNumber.length() != 10 ||
        number == -1) {
      log("User has not entered their mobile number");
      TelephonyManager mTelephonyMgr;
      mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE); 
      phoneMobileNumber = mTelephonyMgr.getLine1Number();
      log("Telephony service tells us that our phone number is: " + phoneMobileNumber);
      if (phoneMobileNumber != null) {
        showDialog(MOBILE_NUMBER_SET);
      } else {
        showDialog(MOBILE_NUMBER_NONE);
      }
    }
    
    // TODO Auto-generated method stub
    super.onResume();
    
    // DEW.getDEW().startSensors();
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onStart()
   */
  @Override
  protected void onStart() {
    // TODO Auto-generated method stub
    super.onStart();
  }

  /* (non-Javadoc)
   * @see android.app.Activity#onStop()
   */
  @Override
  protected void onStop() {
    // TODO Auto-generated method stub
    super.onStop();
  }
  
  
  //  MENUS ------------------------------------------------------------------------
  /* Creates the menu items */
  public static final int MENU_QUIT = 43;

  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.options_menu, menu);
    return true;      
  }

  /* Handles item selections */
  public boolean onOptionsItemSelected(MenuItem item) {
    String url;
    Uri u;
    switch (item.getItemId()) {
    case R.id.quit:
      log("Quit");
      finish();       
      return true;

    // case R.id.downloadimages:
      // setShouldFetchImages(true);
    //   return true;

    case R.id.ppwebpage:
      url = getString(R.string.ppwebpage);
      Intent i = new Intent(Intent.ACTION_VIEW);
      u = Uri.parse(url);
      i.setData(u);
      try {
        startActivity(i);
      } catch (ActivityNotFoundException e) {
        alertInfo("Browser not found.");
      }
      
      return true;

    case R.id.info:
      String s =   "DEW!\n\tusername: " + getDEW().getUsername() 
      + "\n\t\t\t\tversion: " + DEW.VERSION;
      log(s);
      alertInfo(s);


      s = "Preferences:\n";

      SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
      Map<String, ?> map = prefs.getAll();

      for (String name: map.keySet()) {
        s += "\t" + name + ": <" + map.get(name)+">" + " type: " + map.get(name).getClass().getName();
      }
      log(s);

      return true;

    case R.id.preferences:
      log("Preferences menu item pressed.");

      Intent settingsActivity = new Intent(getBaseContext(), DEWPreference.class);
      startActivity(settingsActivity);

      return true;

    default:
      log("Unknown menu item selected: " + item.getTitle());
    }
    return false;
  }
  
  DEW getDEW() {
    return (DEW) getApplication();
  }

  /*
  void log(String s) {
    getDEW().log.addMessage(Log.INFO, DEW.TAG, s);
  }

  void logD(String s) {
    getDEW().log.addMessage(Log.DEBUG, DEW.TAG, s);
  }
  */

  void alertInfo(String alert) {
    Toast.makeText(this,alert, Toast.LENGTH_LONG).show();
  }
}