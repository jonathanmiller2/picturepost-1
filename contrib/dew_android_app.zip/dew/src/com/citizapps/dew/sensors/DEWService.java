package com.citizapps.dew.sensors;

import android.app.Service;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;

import com.citizapps.dew.DEW;

public class DEWService extends Service implements SensorEventListener, LocationListener  {

	private SensorManager sm;
	private LocationManager lm;
	
	private double lastLat;
	private double lastLon;
	private double lastAlt;
	private float lastSpeed;
	private float lastBearing;
	private boolean foundLocation;
	private float lastDirection;
	private float lastHorizon;
	private float lastAccelX;
	private float lastAccelY;
	private float lastAccelZ;
	private float lastNormalizedAccelZ;

	public void onCreate() {
		super.onCreate();
		log("Inside DEWService onCreate()");
		getDEW().service = this;
		
		// get reference to SensorManager
		sm = (SensorManager) getSystemService(SENSOR_SERVICE);

		//---use the LocationManager class to obtain GPS locations---
		lm = (LocationManager) getSystemService(LOCATION_SERVICE); 

		Criteria criteria = new Criteria();
		criteria.setAccuracy(Criteria.ACCURACY_FINE);
		String provider = lm.getBestProvider(criteria, false);
		
		log("Provider: " + provider);
		
		
		if (provider != null) {
			Location locM = lm.getLastKnownLocation(provider);
			if (locM != null) {
				lastLat = locM.getLatitude();
				lastLon = locM.getLongitude();
			}
		}

		for (Sensor s : sm.getSensorList(Sensor.TYPE_ALL)) log("" + s.getType() + " " + s.getName());

		// register this class as a listener for the orientation and accelerometer sensors
		// sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ORIENTATION),SensorManager.SENSOR_DELAY_FASTEST); 
		sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ORIENTATION),SensorManager.SENSOR_DELAY_GAME);
		sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),SensorManager.SENSOR_DELAY_GAME); 
		//sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD),SensorManager.SENSOR_DELAY_FASTEST); 

		lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
	}
	
	public void onDestroy() {
		sm.unregisterListener(this);
		lm.removeUpdates(this);
		
		if (getDEW().service != null) getDEW().service = null;
		
		log("--------------------------------------The DEWService is being destroyed!-------------------------------------");
		
	}
	
	@Override
	public IBinder onBind(Intent arg0) {
		log("onBind");
		return null;
	}
	
	private static final String LOG_TAG = "DEWService";
	
	public static void log(String s) {
		DEW.getDEW().log(LOG_TAG, s);
	}
	
	DEW getDEW() {
		return (DEW) getApplication();
	}

	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		//log("onAccuracy changed. sensor: " + sensor.getName() + " accuracy: " + accuracy);
	}

	public void onSensorChanged(SensorEvent event) {
		float[] values = event.values;
		
		//log("onSensorChanged. sensor: " + event.sensor.getName());		
		switch (event.sensor.getType()) {
		case Sensor.TYPE_ACCELEROMETER:
		  // log("x: " + values[0] + ", y:" + values[1] + ", z:" + values[2]);
		  setLastAccelX(values[0]);
		  setLastAccelY(values[1]);
		  setLastAccelZ(values[2]);
		  setLastNormalizedAccelZ(values[2] / 9.8f);
		  getDEW().notifyAccelerometerChange();
			break;
		case Sensor.TYPE_ORIENTATION:
			setLastDirection(values[0]);
			setLastHorizon(values[2]);
			getDEW().notifyOrientationChange();
			break;
		default:
			log("onSensorChanged, " + event.sensor.getName());
			break;			
		}
		
		// checkAlive();
	}
	
	public void checkAlive() {
		if (getDEW().cam == null) {
			log("checkAlive camera is null, stopping");
			this.stopSelf();
		}
	}

	public void onLocationChanged(Location location) {
		log("Location: (" + location.getLatitude() + ", " + location.getLongitude() + ") <--> bearing: " + location.getBearing() + " speed: " + location.getSpeed() + " alt: " + location.getAltitude());		
		
		lastLon = location.getLongitude();
		lastLat = location.getLatitude();
		lastSpeed = location.getSpeed();
		lastBearing = location.getBearing();
		lastAlt = location.getAltitude();

		foundLocation = true;
		
		// checkAlive();
	}

	public void onProviderDisabled(String provider) {
		log("Provider disabled: " + provider);
	}

	public void onProviderEnabled(String provider) {
		log("Provider enabled: " + provider);
	}

	public void onStatusChanged(String provider, int status, Bundle extras) {
		log("onStatusChanged: " + provider + " status: " + status);
	}
	

	/**
	 * @return the sm
	 */
	SensorManager getSm() {
		return sm;
	}

	/**
	 * @param sm the sm to set
	 */
	void setSm(SensorManager sm) {
		this.sm = sm;
	}

	/**
	 * @return the lm
	 */
	LocationManager getLm() {
		return lm;
	}

	/**
	 * @param lm the lm to set
	 */
	void setLm(LocationManager lm) {
		this.lm = lm;
	}

	/**
	 * @return the lastLat
	 */
	public double getLastLat() {
		return lastLat;
	}

	/**
	 * @param lastLat the lastLat to set
	 */
	void setLastLat(double lastLat) {
		this.lastLat = lastLat;
	}

	/**
	 * @return the lastLon
	 */
	public double getLastLon() {
		return lastLon;
	}

	/**
	 * @param lastLon the lastLon to set
	 */
	void setLastLon(double lastLon) {
		this.lastLon = lastLon;
	}
	
	public double getLastAlt() {
	  return lastAlt;
	}
	
	public void setLastAlt(double alt) {
	  lastAlt = alt;
	}

	/**
	 * @return the lastSpeed
	 */
	float getLastSpeed() {
		return lastSpeed;
	}

	/**
	 * @param lastSpeed the lastSpeed to set
	 */
	void setLastSpeed(float lastSpeed) {
		this.lastSpeed = lastSpeed;
	}

	/**
	 * @return the lastBearing
	 */
	float getLastBearing() {
		return lastBearing;
	}

	/**
	 * @param lastBearing the lastBearing to set
	 */
	void setLastBearing(float lastBearing) {
		this.lastBearing = lastBearing;
	}

	/**
	 * @return the foundLocation
	 */
	boolean isFoundLocation() {
		return foundLocation;
	}

	/**
	 * @param foundLocation the foundLocation to set
	 */
	void setFoundLocation(boolean foundLocation) {
		this.foundLocation = foundLocation;
	}

	public float getLastDirection() {
		return lastDirection;
	}

	void setLastDirection(float lastDirection) {
		this.lastDirection = lastDirection;
	}

	/**
	 * @return the lastHorizon
	 */
	float getLastHorizon() {
		return lastHorizon;
	}

	/**
	 * @param lastHorizon the lastHorizon to set
	 */
	void setLastHorizon(float lastHorizon) {
		this.lastHorizon = lastHorizon;
	}
	
	public float getLastAccelX() {
	  return lastAccelX;
	}
	
	public float getLastAccelY() {
    return lastAccelY;
  }
	
	public float getLastAccelZ() {
    return lastAccelZ;
  }
	
	public void setLastAccelX(float accelX) {
	  lastAccelX = accelX;
	}
	
  public void setLastAccelY(float accelY) {
    lastAccelY = accelY;
  }
  
  public void setLastAccelZ(float accelZ) {
    lastAccelZ = accelZ;
  }
	
	public void setLastNormalizedAccelZ(float zVal) {
	  lastNormalizedAccelZ = zVal;
	}
	
	public float getLastNormalizedAccelZ() {
	  return lastNormalizedAccelZ;
	}
}
