package com.citizapps.dew.model;

public class SensorDataBundle {
  private double latitude;
  private double longitude;
  private double altitude;
  private double speed;
  private double bearing;
  private double orientationDirection;
  private double accelerometerX;
  private double accelerometerY;
  private double accelerometerZ;
  
  
  public SensorDataBundle() {
    
  }
  
  
  /**
   * @return the latitude
   */
  public double getLatitude() {
    return latitude;
  }
  /**
   * @param latitude the latitude to set
   */
  public void setLatitude(double latitude) {
    this.latitude = latitude;
  }
  /**
   * @return the longitude
   */
  public double getLongitude() {
    return longitude;
  }
  /**
   * @param longitude the longitude to set
   */
  public void setLongitude(double longitude) {
    this.longitude = longitude;
  }
  /**
   * @return the altitude
   */
  public double getAltitude() {
    return altitude;
  }
  /**
   * @param altitude the altitude to set
   */
  public void setAltitude(double altitude) {
    this.altitude = altitude;
  }
  /**
   * @return the speed
   */
  public double getSpeed() {
    return speed;
  }
  /**
   * @param speed the speed to set
   */
  public void setSpeed(double speed) {
    this.speed = speed;
  }
  /**
   * @return the bearing
   */
  public double getBearing() {
    return bearing;
  }
  /**
   * @param bearing the bearing to set
   */
  public void setBearing(double bearing) {
    this.bearing = bearing;
  }
  /**
   * @return the orientationDirection
   */
  public double getOrientationDirection() {
    return orientationDirection;
  }
  /**
   * @param orientationDirection the orientationDirection to set
   */
  public void setOrientationDirection(double orientationDirection) {
    this.orientationDirection = orientationDirection;
  }
  /**
   * @return the accelerometerX
   */
  public double getAccelerometerX() {
    return accelerometerX;
  }
  /**
   * @param accelerometerX the accelerometerX to set
   */
  public void setAccelerometerX(double accelerometerX) {
    this.accelerometerX = accelerometerX;
  }
  /**
   * @return the accelerometerY
   */
  public double getAccelerometerY() {
    return accelerometerY;
  }
  /**
   * @param accelerometerY the accelerometerY to set
   */
  public void setAccelerometerY(double accelerometerY) {
    this.accelerometerY = accelerometerY;
  }
  /**
   * @return the accelerometerZ
   */
  public double getAccelerometerZ() {
    return accelerometerZ;
  }
  /**
   * @param accelerometerZ the accelerometerZ to set
   */
  public void setAccelerometerZ(double accelerometerZ) {
    this.accelerometerZ = accelerometerZ;
  }
}
