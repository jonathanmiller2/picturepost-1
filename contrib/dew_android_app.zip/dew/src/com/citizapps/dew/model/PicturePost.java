package com.citizapps.dew.model;

import java.util.HashMap;


public class PicturePost {
  
  // Available attributes of a Picture Post
  public static final String LONGITUDE = "lon";
  public static final String INSTALL_DATE = "installDate";
  public static final String DESCRIPTION = "description";
  public static final String NAME = "name";
  public static final String PERSON_ID = "personId";
  public static final String REFERENCE_PICTURE_SET_ID = "referencePictureSetId";
  public static final String READY = "ready";
  public static final String RECORD_TIME_STAMP = "recordTimestamp";
  public static final String LATITUDE = "lat";
  public static final String POST_ID = "postId";
  public static final String POST_PICTURE_ID = "postPictureId";
  
  
  /* This is an example JSONArray returned by the getPostList servlet 
  [
    {
      "lon":-70.262,
      "installDate":"2009-08-06",
      "description":"A demonstration project shows newly planted plant and shrubs.",
      "name":"Portland, ME - Back Cove (Yardscaping Project)",
      "personId":10,
      "referencePictureSetId":1297,
      "ready":true,
      "recordTimestamp":"2009-08-07 16:01:34.024",
      "lat":43.666,
      "postId":42
    }
  ]
  */
  public HashMap<String, Object> postAttributeMap = new HashMap<String, Object>();
  
  @Override
  public String toString() {
    
    StringBuilder bldr = new StringBuilder();
    bldr.append((String) postAttributeMap.get("name"));
    bldr.append(" (ID: " + (Integer) postAttributeMap.get("postId") + ")");
    return bldr.toString();
    
    // return (String) postAttributeMap.get("name");
  }
}
