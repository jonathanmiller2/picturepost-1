package com.citizapps.dew.model;

import android.net.Uri;
import android.provider.BaseColumns;

public final class ImageRecord {
  
  public static final String AUTHORITY = "com.citizapps.dew.provider.ImageRecord";
  
  /**
   * Images table
   */
  public static final class Images implements BaseColumns {
    /**
     * The content:// style URL for this table
     */
    public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/images");

    /**
     * The MIME type of {@link #CONTENT_URI} providing a directory of imagess.
     */
    public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.google.dewimage";

    /**
     * The MIME type of a {@link #CONTENT_URI} sub-directory of a single image.
     */
    public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.google.dewimage";


    /**
     * The default sort order for this table
     */
    public static final String DEFAULT_SORT_ORDER = "associatedPostId DESC";

    /**
     * The file path and name where the image can be found on the disk
     * <P>Type: TEXT</P>
     */
    public static final String FILE_NAME_AND_PATH = "fileNameAndPath";

    /**
     * The post id of the post this image belongs to
     * <P>Type: INTEGER (long)</P>
     */
    public static final String POST_ID = "associatedPostId";

    /**
     * The picture set id of the picture set to which this image belongs. 
     * <P>Type: INTEGER (long)</P>
     */
    public static final String PICTURE_SET_ID = "associatedPictureSetId";

    /**
     * The picture id of this picture
     * <P>Type: INTEGER (long)</P>
     */
    public static final String PICTURE_ID = "pictureId";

    /**
     * The orientation of this picture
     * <P>Type: TEXT</P>
     */
    public static final String PICTURE_ORIENTATION = "pictureOrientation";

    /**
     * The timestamp corresponding to the creation of the ImageRecord database record
     * <P>Type: INTEGER (long)</P>
     */
    public static final String RECORD_CREATE_TIME = "recordCreateTime";
    
    /**
     * The size of this picture, can be "full", "medium", or "thumb"
     * <P>Type: TEXT</P>
     */
    public static final String PICTURE_SIZE = "pictureSize";
    
    /**
     * A thumbnail for this picture, this is going to be a blob
     * <P>Type: BLOB</P>
     */
    public static final String THUMBNAIL = "thumbNail";
    
  }
}
