package com.citizapps.dew.io;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



/**
 *  Modified from an example from http://svn.apache.org/repos/asf/httpcomponents/httpclient/trunk/httpclient/src/examples/org/apache/http/examples/client/ClientFormLogin.java
 */
public class PicPostSession {
	DefaultHttpClient httpclient;

	static String hostname = "http://picturepost-dev.sr.unh.edu";
	String loginURL = hostname + "/login.jsp";
	String postId =  hostname + "/post_test.jsp?postId=";
	String allPosts = hostname + "/all_posts.jsp";
	
	public PicPostSession() {
		httpclient = new DefaultHttpClient();
	}
	
	public boolean login(String username, String password) {
        boolean success = false;

        HttpGet httpget = new HttpGet(loginURL);
        try {
			httpclient.execute(httpget);
	        
	        //System.out.println("Pre logon, post get cookies:");
	        //printCookies();

	        httpget.abort();
	        
	        HttpPost httpost = new HttpPost(loginURL);

	        List <NameValuePair> nvps = new ArrayList <NameValuePair>();
	        nvps.add(new BasicNameValuePair("submitted", "Login"));
	        nvps.add(new BasicNameValuePair("email", username));
	        nvps.add(new BasicNameValuePair("password", password));

	        UrlEncodedFormEntity uefe = new UrlEncodedFormEntity(nvps, HTTP.UTF_8);
	        httpost.setEntity(uefe);

	        HttpResponse response = httpclient.execute(httpost);

	        //System.out.println("Login form : " + response.getStatusLine());
	        //System.out.println("Post logon cookies:");
	        //printCookies();

	        //The login was a success if we get a redirect to the index.jsp page...
	        for (Header msg : response.getAllHeaders()) {
	        	if (msg.getName().equalsIgnoreCase("Location") && msg.getValue().endsWith("index.jsp")) success = true;
	        	//System.out.println(msg.getName() + ": <" + msg.getValue() + "> suc:" + success);
	        }
	        httpost.abort();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return success;
	}
	
	public void logout() {
        // When HttpClient instance is no longer needed, 
        // shut down the connection manager to ensure
        // immediate deallocation of all system resources
        httpclient.getConnectionManager().shutdown();        
	}

	public void printCookies() {
        List<Cookie> cookies = httpclient.getCookieStore().getCookies();
        if (cookies.isEmpty()) {
            System.out.println("None");
        } else {
            for (int i = 0; i < cookies.size(); i++) {
                System.out.println("- " + cookies.get(i).toString());
            }
        }		
	}
	
	public void printResponseEntity(HttpResponse response) {
		System.out.println(getResonseContentString(response));
	}
	
	public JSONObject getAllPosts() {
        System.out.println("Getting: " + allPosts);
        HttpGet httpget = new HttpGet(allPosts);
        HttpResponse response;
        JSONObject json = null;
        
		try {
			response = httpclient.execute(httpget);
			
			json = new JSONObject(getResonseContentString(response));
			System.out.println(json.get("all"));

		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		httpget.abort();
		return json;
	}
	
	public String getResonseContentString(HttpResponse response) {
    	StringBuffer sb = new StringBuffer();
        HttpEntity entity = response.getEntity();
        if (entity != null) {
        	InputStream is;
			try {
				is = entity.getContent();
	        	BufferedReader br = new BufferedReader(new InputStreamReader(is));
	        	int bufChar;
				while ((bufChar = br.read())!=-1){
					sb.append((char)bufChar);
	        	} 
			} catch (IllegalStateException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}			
        }

		return sb.toString();
	}

	public JSONArray getPostImageList(int i) {
        System.out.println("Getting: " + postId + i);
        HttpGet httpget = new HttpGet(postId+i);
        HttpResponse response;
        String s;
        JSONArray json = null;
        
		try {
			response = httpclient.execute(httpget);
			s = getResonseContentString(response);
			json = new JSONArray(s);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return json;
	}
	
    public static void main(String[] args) throws Exception {
    	String username = "joshua@stigmergic.net";
    	String password = "p4ssw0rd";

    	PicPostSession s = new PicPostSession();
    	s.login(username, password);
    	
    	JSONObject o = s.getAllPosts();
    	JSONArray allPosts = o.getJSONArray("all");
    	System.out.println(o.get("all"));
    	
    	for (int j=0; j<allPosts.length(); j++) {
    		int i = allPosts.getJSONObject(j).getInt("id");
    		JSONArray imgList = s.getPostImageList(i);
    		System.out.println("Found " + imgList.length() + " image sets...");
    		System.out.println("   " + imgList);
    	}
    	
    	System.out.println("finished...");
    	s.logout();
    }
}
