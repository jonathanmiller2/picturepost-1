package com.citizapps.dew.io;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.sanselan.ImageReadException;
import org.apache.sanselan.ImageWriteException;
import org.apache.sanselan.Sanselan;
import org.apache.sanselan.common.IImageMetadata;
import org.apache.sanselan.formats.jpeg.JpegImageMetadata;
import org.apache.sanselan.formats.jpeg.exifRewrite.ExifRewriter;
import org.apache.sanselan.formats.tiff.TiffImageMetadata;
import org.apache.sanselan.formats.tiff.constants.TiffConstants;
import org.apache.sanselan.formats.tiff.write.TiffOutputDirectory;
import org.apache.sanselan.formats.tiff.write.TiffOutputField;
import org.apache.sanselan.formats.tiff.write.TiffOutputSet;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ExifInterface;
import android.os.Environment;
import android.os.SystemClock;

import com.citizapps.dew.DEW;
import com.citizapps.dew.model.PicturePost;
import com.citizapps.dew.model.SensorDataBundle;

public class PictureFileHandling {
	static long lastTime;
	static long delta;
	static Context myContext;
	static String fname;
	
	public static final String pictureSetDateFormatString = "yyyy-MM-dd HH:mm:ss.S";
	public static final SimpleDateFormat pictureSetDateFormat = new SimpleDateFormat(pictureSetDateFormatString, Locale.US);
	
	public static final String createPostDateFormatString = "yyyy-MM-dd";
	public static final SimpleDateFormat createPostDateFormat = new SimpleDateFormat(createPostDateFormatString, Locale.US);
	
	public static final String dewDateFormatString = "yyyy-MM-dd HH:mm:ss";
  public static final SimpleDateFormat dewDateFormat = new SimpleDateFormat(dewDateFormatString, Locale.US);
  
  public static final String gpsDateFormatString = "yyyy:MM:dd";
  public static final SimpleDateFormat gpsDateFormat = new SimpleDateFormat(gpsDateFormatString, Locale.US);
  

	public PictureFileHandling(Context context) {
		lastTime = SystemClock.elapsedRealtime();
		myContext = context;
		delta =  System.currentTimeMillis() - lastTime;
	}

	public static long timeStamp() {
		lastTime =  SystemClock.elapsedRealtime() + delta;
		return lastTime;
	}


	private static File getDirectory() {
		File root = Environment.getExternalStorageDirectory();
		File dir = new File(root, "DEW-PicturePost");
		log("Directory success: " + dir.mkdirs() + ", full path: " + dir.getPath());
		return dir;
	}

	private static File getFile() {
		File file = new File(getDirectory(), fname);
		return file;		
	}


	public static File getNewFile(int index) {
		fname =  "DEW-"+ index + ".jpg";
		return getFile();
	}
	
	
	public static void writeImageFile(byte[] data, File outputFile, SensorDataBundle bundle) throws Exception {
    FileOutputStream outStream = null;
    
    boolean success = false;
    try {
      File tmpFile = new File(getDirectory() + File.separator + "tmp.jpg");
      outStream = new FileOutputStream(tmpFile);
      outStream.write(data);
      outStream.close();
      log("onPictureTaken: " + tmpFile.getName() + " -- wrote bytes: " + data.length);
      if (bundle != null) {
        // writeExifData(outputFile.getAbsolutePath(), bundle);
        // setExifGPSTag(tmpFile, outputFile, bundle);
        setExifGPSTagAlt(tmpFile, outputFile, bundle);
        if (tmpFile != null) {
          tmpFile.delete();
        }
      } else {
        if (tmpFile != null) {
          tmpFile.renameTo(outputFile);
        }
      }
      success = true;
    } catch (FileNotFoundException e) {
      e.printStackTrace();
      log("File Not Found when writing picture");
      outputFile = null;
    } catch (IOException e) {
      e.printStackTrace();
      log("IOException when writing picture");
      outputFile = null;
    } finally {
      if (success) {
        log("Finally: succeeded in picture write.");
      } else {
        log("Finally: failed to write.");
      }
    }
  }
	
	
	public static void writeImageFile(byte[] data, File outputFile) throws Exception {
    writeImageFile(data, outputFile, null);
  }
	
	
	public static File writePicture(byte[] data, int orientationIndex, SensorDataBundle bundle) {
	  FileOutputStream outStream = null;
    File file = getNewFile(orientationIndex);
    boolean success = false;
    
    try {
      outStream = new FileOutputStream(file);
      outStream.write(data);
      outStream.close();
      
      log("onPictureTaken: " + file.getName() + " -- wrote bytes: " + data.length);
      success = true;
      
      if (bundle != null) {
        writeExifData(file.getAbsolutePath(), bundle);
      }
    } catch (FileNotFoundException erp) {
      erp.printStackTrace();
      log("File Not Found when writing picture: " + erp.getMessage());
      file = null;
    } catch (IOException e) {
      e.printStackTrace();
      log("IOException when writing picture: " + e.getMessage());
      file = null;
    } catch (Exception exp) {
      exp.printStackTrace();
      log("Exception when writing picture: " + exp.getMessage());
      file = null;
    } finally {
      if (success) {
        log("Finally: succeeded in picture write.");
      } else {
        log("Finally: failed to write.");
      }
    }

    return file;    
	}
	
	public static void writeExifData(String filePath, SensorDataBundle dataBundle) throws Exception {
	  log("Image file path: " + filePath);

	  ExifInterface exifInterface = new ExifInterface(filePath);
	  
	  exifInterface.setAttribute("GPSVersionID", "2 2 0 0");
    
	  Date now = new Date();
	  String timeStamp = now.getHours() + "/1," + now.getMinutes() + "/1," + now.getSeconds() + "/1";
    exifInterface.setAttribute(ExifInterface.TAG_GPS_TIMESTAMP, timeStamp);
	  
	  String gpsLatitudeRef = dataBundle.getLatitude() >= 0.0 ? "N" : "S";
    exifInterface.setAttribute(ExifInterface.TAG_GPS_LATITUDE_REF, gpsLatitudeRef);
	  
	  long degrees = (long) Math.floor(Math.abs(dataBundle.getLatitude()));
	  double remainder = Math.abs(dataBundle.getLatitude()) - degrees;
	  double min = remainder * 60;
	  remainder = min - Math.floor(min);
	  long minutes = (long) Math.floor(min);
	  double sec = remainder * 60;
	  long seconds = (long) Math.floor(sec);
	  String gpsLatitude = degrees + "/1," + minutes + "/1," + seconds + "/1";
	  log("Here's the GPSLatitude string: " + gpsLatitude);
	  
    exifInterface.setAttribute(ExifInterface.TAG_GPS_LATITUDE, gpsLatitude);
    
    String gpsLongitudeRef = dataBundle.getLongitude() >= 0.0 ? "E" : "W";
    exifInterface.setAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF, gpsLongitudeRef);
    
    degrees = (long) Math.floor(Math.abs(dataBundle.getLongitude()));
    remainder = Math.abs(dataBundle.getLongitude()) - degrees;
    min = remainder * 60;
    remainder = min - Math.floor(min);
    minutes = (long) Math.floor(min);
    sec = remainder * 60;
    seconds = (long) Math.floor(sec);
    String gpsLongitude = degrees + "/1," + minutes + "/1," + seconds + "/1";
    log("Here's the GPSLongitude string: " + gpsLongitude);
    
    exifInterface.setAttribute(ExifInterface.TAG_GPS_LONGITUDE, gpsLongitude);
    
    exifInterface.setAttribute(ExifInterface.TAG_GPS_PROCESSING_METHOD, "ASCIIGPS");
    
    exifInterface.setAttribute(ExifInterface.TAG_GPS_DATESTAMP, gpsDateFormat.format(now));
    
    exifInterface.setAttribute("GPSAltitudeRef", "0");
    exifInterface.setAttribute("GPSAltitude", Math.round(dataBundle.getAltitude()) + "/1");
    
    exifInterface.saveAttributes();
	}
	
	
	public static void setExifGPSTag(File jpegImageFile, 
	                                 File dst,
	                                 SensorDataBundle dataBundle) throws IOException, 
	                                                                     ImageReadException, 
	                                                                     ImageWriteException {
	  OutputStream os = null;
	  
	  try {
	    TiffOutputSet outputSet = null;

	    // note that metadata might be null if no metadata is found.
	    IImageMetadata metadata = Sanselan.getMetadata(jpegImageFile);
	    JpegImageMetadata jpegMetadata = (JpegImageMetadata) metadata;

	    if (jpegMetadata != null) {
	      // note that exif might be null if no Exif metadata is found.
	      TiffImageMetadata exif = jpegMetadata.getExif();

	      if (exif != null) {
	        // TiffImageMetadata class is immutable (read-only).
	        // TiffOutputSet class represents the Exif data to write.
	        //
	        // Usually, we want to update existing Exif metadata by
	        // changing
	        // the values of a few fields, or adding a field.
	        // In these cases, it is easiest to use getOutputSet() to
	        // start with a "copy" of the fields read from the image.
	        log("Going to start with the original Exif metadata");
	        outputSet = exif.getOutputSet();
	      }
	    }

	    // if file does not contain any exif metadata, we create an empty
	    // set of exif metadata. Otherwise, we keep all of the other
	    // existing tags.
	    if (outputSet == null) {
	      log("Going to have to create a new Exif metadata");
	      outputSet = new TiffOutputSet();
	    }

	    {
	      Date now = new Date();
	      
        TiffOutputDirectory gpsDirectory = outputSet.getOrCreateGPSDirectory();
	      
	      {
	        // GPSLongitudeRef expects 1 values: ASCII
	        String logMsg = "GPSLongitudeRef expects " + 
                          TiffConstants.GPS_TAG_GPS_LONGITUDE_REF.dataTypes.length + 
                          " values: ";
	        for (int i = 0; i < TiffConstants.GPS_TAG_GPS_LONGITUDE_REF.dataTypes.length; i++) {
	          logMsg += TiffConstants.GPS_TAG_GPS_LONGITUDE_REF.dataTypes[i].name + ", ";
	        }
	        log(logMsg);

	        String gpsLongitudeRef = dataBundle.getLongitude() >= 0.0 ? "E" : "W";
	        TiffOutputField longitudeRefField = 
	          TiffOutputField.create(TiffConstants.GPS_TAG_GPS_LONGITUDE_REF, 
	                                 outputSet.byteOrder,
	                                 gpsLongitudeRef);
	        gpsDirectory.removeField(TiffConstants.GPS_TAG_GPS_LONGITUDE_REF);
	        gpsDirectory.add(longitudeRefField);
	      }

	      {
	        // GPSLatitudeRef expects 1 values: ASCII
	        String logMsg = "GPSLatitudeRef expects " + 
                          TiffConstants.GPS_TAG_GPS_LATITUDE_REF.dataTypes.length + 
                          " values: ";
	        for (int i = 0; i < TiffConstants.GPS_TAG_GPS_LATITUDE_REF.dataTypes.length; i++) {
	          logMsg += TiffConstants.GPS_TAG_GPS_LATITUDE_REF.dataTypes[i].name + ", ";
	        }
	        log(logMsg);

          String gpsLatitudeRef = dataBundle.getLatitude() >= 0.0 ? "N" : "S";
	        TiffOutputField latitudeRefField = 
	          TiffOutputField.create(TiffConstants.GPS_TAG_GPS_LATITUDE_REF, 
	                                 outputSet.byteOrder,
	                                 gpsLatitudeRef);
	        gpsDirectory.removeField(TiffConstants.GPS_TAG_GPS_LATITUDE_REF);
	        gpsDirectory.add(latitudeRefField);
	      }

	      {
	        // GPSLongitude expects 1 values: Rational
	        String logMsg = "GPSLongitude expects " + 
                          TiffConstants.GPS_TAG_GPS_LONGITUDE.dataTypes.length + 
                          " values: ";
	        for (int i = 0; i < TiffConstants.GPS_TAG_GPS_LONGITUDE.dataTypes.length; i++) {
	          logMsg += TiffConstants.GPS_TAG_GPS_LONGITUDE.dataTypes[i].name + ", ";
	        }
	        log(logMsg);

          double value = Math.abs(dataBundle.getLongitude());
	        double longitudeDegrees = (long) value;
	        value %= 1;
	        value *= 60.0;
	        double longitudeMinutes = (long) value;
	        value %= 1;
	        value *= 60.0;
	        double longitudeSeconds = value;
	        Double values[] = {
	            new Double(longitudeDegrees), new Double(longitudeMinutes),
	            new Double(longitudeSeconds),
	        };

	        TiffOutputField longitudeField = 
	          TiffOutputField.create(TiffConstants.GPS_TAG_GPS_LONGITUDE,
	                                 outputSet.byteOrder, 
	                                 values);
	        gpsDirectory.removeField(TiffConstants.GPS_TAG_GPS_LONGITUDE);
	        gpsDirectory.add(longitudeField);
	      }

	      {
	        // GPSLatitude expects 1 values: Rational
	        String logMsg = "GPSLatitude expects " + 
                          TiffConstants.GPS_TAG_GPS_LATITUDE.dataTypes.length + 
                          " values: ";
	        for (int i = 0; i < TiffConstants.GPS_TAG_GPS_LATITUDE.dataTypes.length; i++) {
	          logMsg += TiffConstants.GPS_TAG_GPS_LATITUDE.dataTypes[i].name + ", ";
	        }
	        log(logMsg);

          double value = Math.abs(dataBundle.getLatitude());
	        double latitudeDegrees = (long) value;
	        value %= 1;
	        value *= 60.0;
	        double latitudeMinutes = (long) value;
	        value %= 1;
	        value *= 60.0;
	        double latitudeSeconds = value;
	        Double values[] = {
	            new Double(latitudeDegrees), 
	            new Double(latitudeMinutes),
	            new Double(latitudeSeconds),
	        };

	        TiffOutputField latitudeField = 
	          TiffOutputField.create(TiffConstants.GPS_TAG_GPS_LATITUDE, 
	                                 outputSet.byteOrder, 
	                                 values);
	        gpsDirectory.removeField(TiffConstants.GPS_TAG_GPS_LATITUDE);
	        gpsDirectory.add(latitudeField);
	      }
	      
	      {
	        // GPSAltitudeRef expects 1 values: Byte 
	        String logMsg = "GPSAltitudeRef expects " + 
	                         TiffConstants.GPS_TAG_GPS_ALTITUDE_REF.dataTypes.length + 
	                         " values: ";
	        for (int i = 0; i < TiffConstants.GPS_TAG_GPS_ALTITUDE_REF.dataTypes.length; i++) {
	          logMsg += TiffConstants.GPS_TAG_GPS_ALTITUDE_REF.dataTypes[i].name + ", ";
	        }
	        log(logMsg);
	        
	        // Byte[] values = new Byte[1];
	        // values[0] = new Byte((byte) 0);
	        TiffOutputField altitudeRefField = 
	          TiffOutputField.create(TiffConstants.GPS_TAG_GPS_ALTITUDE_REF,
	                                 outputSet.byteOrder,
	                                 new Byte((byte) TiffConstants.GPS_TAG_GPS_ALTITUDE_REF_VALUE_ABOVE_SEA_LEVEL));
	        gpsDirectory.removeField(TiffConstants.GPS_TAG_GPS_ALTITUDE_REF);
	        gpsDirectory.add(altitudeRefField);
	      }
	      
	      {
	        // GPSAltitude expects 1 values: Rational
	        String logMsg = "GPSAltitude expects " + 
                          TiffConstants.GPS_TAG_GPS_ALTITUDE.dataTypes.length + 
                          " values: ";
          for (int i = 0; i < TiffConstants.GPS_TAG_GPS_ALTITUDE.dataTypes.length; i++) {
            logMsg += TiffConstants.GPS_TAG_GPS_ALTITUDE.dataTypes[i].name + ", ";
          }
          log(logMsg);
          
          Double[] values = new Double[1];
          values[0] = new Double(dataBundle.getAltitude());
	        TiffOutputField altitudeField =
	          TiffOutputField.create(TiffConstants.GPS_TAG_GPS_ALTITUDE, 
	                                 outputSet.byteOrder, 
	                                 values);
	        gpsDirectory.removeField(TiffConstants.GPS_TAG_GPS_ALTITUDE);
	        gpsDirectory.add(altitudeField);
	      }
	      
	      {
	        // GPSDateStamp expects 1 values: ASCII
	        String logMsg = "GPSDateStamp expects " + 
                          TiffConstants.GPS_TAG_GPS_DATE_STAMP.dataTypes.length + 
                          " values: ";
          for (int i = 0; i < TiffConstants.GPS_TAG_GPS_DATE_STAMP.dataTypes.length; i++) {
            logMsg += TiffConstants.GPS_TAG_GPS_DATE_STAMP.dataTypes[i].name + ", ";
          }
          log(logMsg);
          
	        TiffOutputField dateStampField =
	          TiffOutputField.create(TiffConstants.GPS_TAG_GPS_DATE_STAMP, 
	                                 outputSet.byteOrder, 
	                                 gpsDateFormat.format(now));
	        gpsDirectory.removeField(TiffConstants.GPS_TAG_GPS_DATE_STAMP);
	        gpsDirectory.add(dateStampField);
	      }
	      
	      {
	        // GPSTimeStamp expects 1 values: Rational
          String logMsg = "GPSTimeStamp expects " + 
                          TiffConstants.GPS_TAG_GPS_TIME_STAMP.dataTypes.length + 
                          " values: ";
          for (int i = 0; i < TiffConstants.GPS_TAG_GPS_TIME_STAMP.dataTypes.length; i++) {
            logMsg += TiffConstants.GPS_TAG_GPS_TIME_STAMP.dataTypes[i].name + ", ";
          }
          log(logMsg);
          
	        // String timeStamp = now.getHours() + "/1," + now.getMinutes() + "/1," + now.getSeconds() + "/1";
	        Double[] values = new Double[3];
	        values[0] = new Double(now.getHours());
	        values[1] = new Double(now.getMinutes());
	        values[2] = new Double(now.getSeconds());
	        TiffOutputField timeStampField = 
	          TiffOutputField.create(TiffConstants.GPS_TAG_GPS_TIME_STAMP, 
	                                 outputSet.byteOrder, 
	                                 values);
	        gpsDirectory.removeField(TiffConstants.GPS_TAG_GPS_TIME_STAMP);
	        gpsDirectory.add(timeStampField);
	      }
	      
	      {
	        // GPSVersionId expects 1 values: Byte
	        String logMsg = "GPSVersionId expects " + 
                          TiffConstants.GPS_TAG_GPS_VERSION_ID.dataTypes.length + 
                          " values: ";
          for (int i = 0; i < TiffConstants.GPS_TAG_GPS_VERSION_ID.dataTypes.length; i++) {
            logMsg += TiffConstants.GPS_TAG_GPS_VERSION_ID.dataTypes[i].name + ", ";
          }
          log(logMsg);
          
	        Byte[] values = new Byte[4];
	        values[0] = new Byte((byte) 2);
	        values[1] = new Byte((byte) 2);
	        values[2] = new Byte((byte) 0);
	        values[3] = new Byte((byte) 0);
	        
	        log("Type of values for GPSVersionId: " + values.getClass().getName());
	        
	        TiffOutputField gpsVersionIdField = 
	          TiffOutputField.create(TiffConstants.GPS_TAG_GPS_VERSION_ID,
	                                 outputSet.byteOrder, 
	                                 values);
	        gpsDirectory.removeField(TiffConstants.GPS_TAG_GPS_VERSION_ID);
	        gpsDirectory.add(gpsVersionIdField);
	      }
	      
	      {
          String logMsg = "GPSProcessingMethod expects " + 
                          TiffConstants.GPS_TAG_GPS_PROCESSING_METHOD.dataTypes.length + 
                          " values: ";
          for (int i = 0; i < TiffConstants.GPS_TAG_GPS_PROCESSING_METHOD.dataTypes.length; i++) {
            logMsg += TiffConstants.GPS_TAG_GPS_PROCESSING_METHOD.dataTypes[i].name + ", ";
          }
          log(logMsg);
          
	        String processingMethod = "ASCIIGPS";
	        TiffOutputField procMethodField = 
	          TiffOutputField.create(TiffConstants.GPS_TAG_GPS_PROCESSING_METHOD,
	                                 outputSet.byteOrder, 
	                                 processingMethod);
	        gpsDirectory.removeField(TiffConstants.GPS_TAG_GPS_PROCESSING_METHOD);
	        gpsDirectory.add(procMethodField);
	      }
	      
	      {
	        
	      }
	      
	      {
	        
	      }
	      
	      TiffOutputDirectory exifDirectory = outputSet.getOrCreateExifDirectory();
	      
	      {
	        
	        String userComment = "{ AccelerometerValues=(" + dataBundle.getAccelerometerX() + "," + dataBundle.getAccelerometerY() + "," + dataBundle.getAccelerometerZ() + "); }";
	        TiffOutputField userCommentField = 
            TiffOutputField.create(TiffConstants.EXIF_TAG_USER_COMMENT,
                                   outputSet.byteOrder, 
                                   userComment);
          exifDirectory.removeField(TiffConstants.EXIF_TAG_USER_COMMENT);
          exifDirectory.add(userCommentField);
	      }
	    }

	    os = new FileOutputStream(dst);
	    os = new BufferedOutputStream(os);

	    // new ExifRewriter().updateExifMetadataLossless(jpegImageFile, os, outputSet);
	    new ExifRewriter().updateExifMetadataLossy(jpegImageFile, os, outputSet);

	    os.close();
	    os = null;
	  } finally {
	    if (os != null) {
	      try {
	        os.close();
	      } catch (IOException e) {
          e.printStackTrace();
	      }
	    }
	  }
	}
	
 
	/// WSW: Here's another approach to doing EXIF data I just found on stackoverflow,
  /// though I'm not sure it's actually supported.  I believe I tried using this
  /// interface awhile back and it didn't work. 

	public static void setExifGPSTagAlt(File jpegImageFile, 
	                                    File dst,  
	                                    SensorDataBundle dataBundle) throws IOException, 
	                                                                        ImageReadException, 
	                                                                        ImageWriteException {
	  
	  String srcImageFilePath = jpegImageFile.getPath();
	  log("Source image file path is: " + srcImageFilePath);
	  
	  String dstImageFilePath = dst.getPath();
	  log("Destination image file path is: " + dstImageFilePath);
	  
	  ExifInterface exif = null;

	  double latitude = dataBundle.getLatitude();
	  double longitude = dataBundle.getLongitude();

	  try {
	    exif = new ExifInterface(srcImageFilePath);
	    int num1Lat = (int)Math.floor(Math.abs(latitude));
	    int num2Lat = (int)Math.floor((Math.abs(latitude) - num1Lat) * 60);
	    double num3Lat = (Math.abs(latitude) - ((double)num1Lat+((double)num2Lat/60))) * 3600000;
	    
	    log("Latitude values: num1Lat=" + num1Lat + ", num2Lat=" + num2Lat + ", num3Lat=" + num3Lat);

	    int num1Lon = (int)Math.floor(Math.abs(longitude));
	    int num2Lon = (int)Math.floor((Math.abs(longitude) - num1Lon) * 60);
	    double num3Lon = (Math.abs(longitude) - ((double)num1Lon+((double)num2Lon/60))) * 3600000;
	    
	    log("Longitude values: num1Lon=" + num1Lon + ", num2Lon=" + num2Lon + ", num3Lon=" + num3Lon);

	    exif.setAttribute(ExifInterface.TAG_GPS_LATITUDE, num1Lat+"/1,"+num2Lat+"/1,"+num3Lat+"/1000");
	    exif.setAttribute(ExifInterface.TAG_GPS_LONGITUDE, num1Lon+"/1,"+num2Lon+"/1,"+num3Lon+"/1000");


	    if (latitude > 0) {
	      exif.setAttribute(ExifInterface.TAG_GPS_LATITUDE_REF, "N"); 
	    } else {
	      exif.setAttribute(ExifInterface.TAG_GPS_LATITUDE_REF, "S");
	    }

	    if (longitude > 0) {
	      exif.setAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF, "E");    
	    } else {
	      exif.setAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF, "W");
	    }

	    exif.saveAttributes();
	    
	    log("Ok, I guess it's all done, all that's left is to rename the file");
	    jpegImageFile.renameTo(dst);

	  } catch (IOException e) {
	    log("Caught exception attempting to write exif data: " + e.getLocalizedMessage());
 	  }
	}
	

	public static File writePicture(byte[] data, int orientationIndex) {
		return writePicture(data, orientationIndex, null);
	}

	static DEW getDEW() {
		return DEW.getDEW();
	}
	
	private static final String LOG_TAG = "PictureFileHandling";

	public static void log(String s) {
		DEW.getDEW().log(LOG_TAG, s);
	}

	public static void removeFiles() {
		File dir = getDirectory();
		File[] files = dir.listFiles(new FileFilter() {

			public boolean accept(File pathname) {
				return pathname.getName().endsWith("jpg");
			}
		}); 

		
		if (files != null) {
			for (File f : files) {
				log("Deleting " + f.getAbsolutePath());
				f.delete();
			}
		}
		
	}

	public static boolean orientationExists(int i) {
		File f = getNewFile(i);
		return f.exists();
	}

	public static void downloadImagesOnThread() {
		Runnable download = new Runnable() {			
			public void run() {
				downloadImages();
			}
		};
		
		Thread thread = new Thread(download);
		thread.start();
	}
	
	public static ArrayList<PicturePost> readPostFile(InputStream inputStream) {
	  ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
	  ArrayList<PicturePost> postList = new ArrayList<PicturePost>();

	  int j;
	  try {
	    j = inputStream.read();
	    while (j != -1) {
	      byteArrayOutputStream.write(j);
	      j = inputStream.read();
	    }
	    inputStream.close();
	  } catch (IOException e) {
	    e.printStackTrace();
	  }
	  
	  String jsonString = byteArrayOutputStream.toString();
	  JSONArray json = null;
	  
	  try {
	    json = new JSONArray(jsonString);
	  } catch (Exception e) {
	    e.printStackTrace();
	  }
	  
	  if (json != null) {
	    JSONObject jObj = null;
	    
	    for (int i = 0; i < json.length(); i++) {
	      try {
	        jObj = json.getJSONObject(i);
	      } catch (Exception e) {
	        e.printStackTrace();
	        continue;
	      }
	      if (jObj != null) {
	        PicturePost post = new PicturePost();
	        try {
	          post.postAttributeMap.put("postId", (Integer) jObj.get("postId"));
	          post.postAttributeMap.put("personId",  (Integer) jObj.get("personId"));
	          post.postAttributeMap.put("name",  (String) jObj.get("name"));
	          post.postAttributeMap.put("description",  (String) jObj.get("description"));
	          post.postAttributeMap.put("installDate",  (String) jObj.get("installDate"));
	          post.postAttributeMap.put("referencePictureSetId",  (Integer) jObj.get("referencePictureSetId"));
	          post.postAttributeMap.put("recordTimestamp",  (String) jObj.get("recordTimestamp"));
	          post.postAttributeMap.put("ready",  (Boolean) jObj.get("ready"));
	          post.postAttributeMap.put("lat",  (Double) jObj.get("lat"));
	          post.postAttributeMap.put("lon",  (Double) jObj.get("lon"));
	          post.postAttributeMap.put("postPictureId",  (Integer) jObj.get("postPictureId"));
	        } catch (Exception e) {
	          e.printStackTrace();
	        }
	        if ((Integer) post.postAttributeMap.get("referencePictureSetId") >= 0) postList.add(post);
	      }
	      jObj = null;
	    }
	  }

	  return postList;
	}
	
  public static ArrayList<PicturePost> getAllPicturePosts(String url) {
    DefaultHttpClient httpclient = new DefaultHttpClient();
    ArrayList<PicturePost> postList = new ArrayList<PicturePost>();
    
    HttpGet httpget = new HttpGet(url);
    HttpResponse response;
    String s;
    JSONArray json = null;
    
    try {
      response = httpclient.execute(httpget);
      s = getResponseContentString(response);
      json = new JSONArray(s);
      // log("Result of getAllPicturePosts(): " + json.toString());
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
    
    if (json == null) {
      log("Error: expected a json object and didn't get one, returning now.");
      return null;
    }
    
    JSONObject jObj = null;
    
    for (int i = 0; i < json.length(); i++) {
      try {
        jObj = json.getJSONObject(i);
      } catch (Exception e) {
        e.printStackTrace();
        continue;
      }
      if (jObj != null) {
        PicturePost post = new PicturePost();
        try {
          post.postAttributeMap.put("postId", (Integer) jObj.get("postId"));
          post.postAttributeMap.put("personId",  (Integer) jObj.get("personId"));
          post.postAttributeMap.put("name",  (String) jObj.get("name"));
          post.postAttributeMap.put("description",  (String) jObj.get("description"));
          post.postAttributeMap.put("installDate",  (String) jObj.get("installDate"));
          post.postAttributeMap.put("referencePictureSetId",  (Integer) jObj.get("referencePictureSetId"));
          post.postAttributeMap.put("recordTimestamp",  (String) jObj.get("recordTimestamp"));
          post.postAttributeMap.put("ready",  (Boolean) jObj.get("ready"));
          post.postAttributeMap.put("lat",  (Double) jObj.get("lat"));
          post.postAttributeMap.put("lon",  (Double) jObj.get("lon"));
          post.postAttributeMap.put("postPictureId",  (Integer) jObj.get("postPictureId"));
          // log("postPictureId is: " + jObj.get("postPictureId").toString());
        } catch (Exception e) {
          e.printStackTrace();
        }
        if ((Integer) post.postAttributeMap.get("referencePictureSetId") >= 0) postList.add(post);
        // postList.add(post);
      }
      jObj = null;
    }
    
    return postList;
  }
  
  public static PicturePost getPicturePostById(int postId) {
    DefaultHttpClient httpclient = new DefaultHttpClient();
    PicturePost post = null;
    
    // http://picturepost-dev.sr.unh.edu/app/GetPost?postId=1
    StringBuilder urlBldr = new StringBuilder(getDEW().getPicturePostHost() + "/app/GetPost?");
    urlBldr.append("postId=" + postId);
    
    String url = urlBldr.toString();
    HttpGet httpget = new HttpGet(url);
    
    HttpResponse response;
    String s;
    JSONArray jArray = null;
    JSONObject json = null;
    
    try {
      response = httpclient.execute(httpget);
      s = getResponseContentString(response);
      jArray = new JSONArray(s);
      // log("Result of getPicturePostById(" + postId +"): " + jArray != null ? jArray.toString() : "NULL");
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    if (jArray == null) {
      log("Error: expected a json array and didn't get one, returning now.");
      return null;
    }
    
    try {
      json = jArray.getJSONObject(0);
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    if (json == null) {
      log("Error, expected the 0th element of the json array to be our picture post, returning now.");
      return null;
    }
    
    post = new PicturePost();
    try {
      post.postAttributeMap.put("postId", (Integer) json.get("postId"));
      post.postAttributeMap.put("personId",  (Integer) json.get("personId"));
      post.postAttributeMap.put("name",  (String) json.get("name"));
      post.postAttributeMap.put("description",  (String) json.get("description"));
      post.postAttributeMap.put("installDate",  (String) json.get("installDate"));
      post.postAttributeMap.put("referencePictureSetId",  (Integer) json.get("referencePictureSetId"));
      post.postAttributeMap.put("recordTimestamp",  (String) json.get("recordTimestamp"));
      post.postAttributeMap.put("ready",  (Boolean) json.get("ready"));
      post.postAttributeMap.put("lat",  (Double) json.get("lat"));
      post.postAttributeMap.put("lon",  (Double) json.get("lon"));
      post.postAttributeMap.put("postPictureId",  (Integer) json.get("postPictureId"));
      // log("postPictureId is: " + json.get("postPictureId").toString());
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    return post;
  }
  
  public static String uploadImage(String dewImage, PicturePost post, int picSetId, String orient, boolean cleanUp) {
    DefaultHttpClient httpClient = new DefaultHttpClient();
    
    HttpResponse response;
    String str;
    JSONObject json = null;
    
    String pictureId = "none";

    try {
      
      String url = getDEW().getPicturePostHost() + "/app/AddPicture";
      HttpPost postRequest = new HttpPost(url);
      
      File file = new File(dewImage);
      
      if (file == null || !file.exists() || !file.canRead()) {
        String msg = "DEW image " + dewImage + " doesn't exist.";
        log(msg);
        pictureId = msg;
        return pictureId;
      }
      
      FileBody bin = new FileBody(file);
      
      MultipartEntity reqEntity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);
      reqEntity.addPart("image", bin);
      reqEntity.addPart("pictureSetId", new StringBody(Integer.toString(picSetId)));
      reqEntity.addPart("orientation", new StringBody(orient));
      postRequest.setEntity(reqEntity);
      
      response = httpClient.execute(postRequest);

      str = getResponseContentString(response);
      json = new JSONObject(str);
      
      log("Response to AddPicture request: " + (str != null ? str : "NULL"));
      
      // {"error":[Invalid mobilePhone value: 1 508 615 5333]}
      
      try {
        String error = json.get("error").toString();
        if (error != null && error.compareTo("") != 0) {
          String msg = "The server reported an error upon upload attempt: " + error;
          log(msg);
          pictureId = msg;
          return pictureId;
        }
      } catch (Exception eep) {
        // Nothing to do here, there's just no error to find
      }
            
      // pictureId = ((Integer) json.get("pictureId")).intValue();
      pictureId = json.get("pictureId").toString();
      
      // Now delete the file and update the db record if that was requested
      if (cleanUp == true) {
        // This is not implemented yet....
      }
      
    } catch (Exception e) {
      // handle exception here
      log(e.getClass().getName() + " : " +  e.getMessage());
    }
    
    return pictureId;

  }
  
  
  public static Integer createPicturePost(PicturePost newPost) {
    DefaultHttpClient httpclient = new DefaultHttpClient();
    // int postId = -1;
    Integer postId = null;
    
    /*
     * Here's what the request should look like: 
     
http://picturepost-dev.sr.unh.edu/app/AddPost?mobilePhone=123&name=bill1&description=the description&installDate=2010-01-07&lat=43.67&lon=-72.123
     
     * When you create a new post and it's successful, you should get a
     * response like this back (below)
{
"postId":119
}
     * I'm not sure what you see if it's unsuccessful
     */
    
    StringBuilder urlBldr = new StringBuilder(getDEW().getPicturePostHost() + "/app/AddPost?");
    
    String timeStamp = (String) newPost.postAttributeMap.get(PicturePost.INSTALL_DATE);
    
    try {
      timeStamp = URLEncoder.encode(timeStamp, "UTF-8");
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    String name = (String) newPost.postAttributeMap.get(PicturePost.NAME);
    
    try {
      name = URLEncoder.encode(name, "UTF-8");
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    String description = "";

    try {
      description = URLEncoder.encode((String) newPost.postAttributeMap.get(PicturePost.DESCRIPTION), "UTF-8");
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    urlBldr.append("name=" + name + "&");
    urlBldr.append("description=" + description + "&");
    urlBldr.append("lat=" + newPost.postAttributeMap.get(PicturePost.LATITUDE) + "&");
    urlBldr.append("lon=" + newPost.postAttributeMap.get(PicturePost.LONGITUDE) + "&");
    urlBldr.append("installDate=" + timeStamp + "&");
    urlBldr.append("mobilePhone=" + getDEW().getMobilePhoneNumber() + "&");
    
    String url = urlBldr.toString();
    
    log("The encoded url is: " + url);
    
    HttpGet httpget = new HttpGet(url);
    
    HttpResponse response;
    String s;
    JSONObject json = null;
    
    try {
      response = httpclient.execute(httpget);
      s = getResponseContentString(response);
      
      log("HERE I AM GUV'NAH!");
      
      if (!s.contains("Invalid mobilePhone value")) {
        log("Plip");
        json = new JSONObject(s);
      } else {
        // This function is probably being called from an AsyncTask, so
        // we need to get the word back to the user that he forgot to
        // enter his mobile phone number.  Let's use a magic number.
        log("Plop");
        return new Integer(-42);
      }
      
      log(json.toString());
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    if (json == null) {
      log("Error: expected a json object and didn't get one, returning now.");
      return null;
    }
    
    try {
      postId = ((Integer) json.get("postId")).intValue();
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    if (postId == -1) {
      return null;
    }
    
    return new Integer(postId);
  }
  
  
  public static int setReferencePictureSetId(int postId, int pictureSetId) {
    int returnValue = -1;
    
    DefaultHttpClient httpclient = new DefaultHttpClient();
    
    StringBuilder urlBldr = new StringBuilder(getDEW().getPicturePostHost() + "/app/SetReferencePictureSetId?");
    urlBldr.append("postId=" + postId + "&");
    urlBldr.append("pictureSetId=" + pictureSetId + "&");
    urlBldr.append("mobilePhone=" + getDEW().getMobilePhoneNumber());
    
    String url = urlBldr.toString();
    
    log("The url is: " + url);
    
    HttpGet httpget = new HttpGet(url);
    
    HttpResponse response;
    String s;
    JSONObject json = null;
    
    try {
      response = httpclient.execute(httpget);
      s = getResponseContentString(response);
      
      if (!s.contains("Invalid mobilePhone value")) {
        json = new JSONObject(s);
      } else {
        // This function is probably being called from an AsyncTask, so
        // we need to get the word back to the user that he forgot to
        // enter his mobile phone number.  It's 2:30 am and I need to get
        // undpate out before I can pass out, so let's use a magic number.
        return -42;
      }
      
      log(json.toString());
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    if (json == null) {
      log("Error: expected a json object and didn't get one, returning now.");
      return -2;
    }
    
    return returnValue;
  }
  
  
  public static int createPictureSet(PicturePost post) {
    DefaultHttpClient httpclient = new DefaultHttpClient();
    
    /*
     * http://picturepost-dev.sr.unh.edu/app/AddPictureSet?postId=1&mobilePhone=5052283573&pictureSetTimestamp=2011-04-20 13:03:29.0&annotation=freetext
     *
     * When you create a new picture set successfully, you see something like this:
     
     {
     "pictureSetId":1786
     }
     
     * 
     */
    
    int pictureSetId = -1;
    
    StringBuilder urlBldr = new StringBuilder(getDEW().getPicturePostHost() + "/app/AddPictureSet?");
    urlBldr.append("postId=" + post.postAttributeMap.get(PicturePost.POST_ID) + "&");
    urlBldr.append("mobilePhone=" + getDEW().getMobilePhoneNumber() + "&");
    String timeStamp = "";
    
    try {
      timeStamp = URLEncoder.encode(pictureSetDateFormat.format(new Date()), "UTF-8");
    } catch (Exception e) {
      e.printStackTrace();
    }
    urlBldr.append("pictureSetTimestamp=" + timeStamp + "&");
    // urlBldr.append("annotation=freetext");
    
    String url = urlBldr.toString();
    
    log("The encoded url is: " + url);
    
    HttpGet httpget = new HttpGet(url);
    
    HttpResponse response;
    String s;
    JSONObject json = null;
    
    try {
      response = httpclient.execute(httpget);
      s = getResponseContentString(response);
      
      if (!s.contains("Invalid mobilePhone value")) {
        json = new JSONObject(s);
      } else {
        // This function is probably being called from an AsyncTask, so
        // we need to get the word back to the user that he forgot to
        // enter his mobile phone number.  It's 2:30 am and I need to get
        // undpate out before I can pass out, so let's use a magic number.
        return -42;
      }
      
      log(json.toString());
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    if (json == null) {
      log("Error: expected a json object and didn't get one, returning now.");
      return -1;
    }
    
    try {
      pictureSetId = ((Integer) json.get("pictureSetId")).intValue();
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    return pictureSetId;
  }  
  
  public static void fetchImagesOnThread(final String url) {
    Runnable fetch = new Runnable() {      
      public void run() {
        fetchImages(url);
      }
    };
    
    Thread thread = new Thread(fetch);
    thread.start();
  }
  
  
  public static Bitmap getImage(long pictureSetId, String orientation, String size) {
    Bitmap img = null;
    
    String imageURL = getDEW().getPicturePostHost() + "/app/GetPicture?pictureSetId=" + 
                      pictureSetId + "&orientation=" + orientation + "&size=" + size;
    
    log("getImage(long, String, String): image url: " + imageURL);

    try {
      InputStream is = (InputStream) fetch(imageURL);
      img = BitmapFactory.decodeStream(is);
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    return img;
  }
  
  
  public static Bitmap getImage(long pictureId, String size) {
    Bitmap img = null;
    
    String imageURL = getDEW().getPicturePostHost() + "/app/GetPicture?pictureId=" + pictureId + "&size=" + size;

    log("getImage(long, String): image url: " + imageURL);

    try {
      InputStream is = (InputStream) fetch(imageURL);
      img = BitmapFactory.decodeStream(is);
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    return img;
  }
  
  
  public static Bitmap getPostThumb(long postId, int postThumbId) {
    // http://picturepost-dev.sr.unh.edu/images/pictures/post_136/post_picture_148_medium.jpg
    Bitmap img = null;
    String imageURL = getDEW().getPicturePostHost() + "/images/pictures/post_" + 
                      postId + "/post_picture_" + postThumbId + "_thumb.jpg";
    
    // log("@@@@@@@@@@@@@@ image url: " + imageURL + " @@@@@@@@@@@@@@@");
    
    try {
      InputStream is = (InputStream) fetch(imageURL);
      img = BitmapFactory.decodeStream(is);
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    return img;
  }
  
  
  public static void fetchImages(String url) {
    DefaultHttpClient httpclient = new DefaultHttpClient();
    
    log("fetchingImages: " + url);
    
    int pictureSetId = getDEW().getPostID();
    
    // String host = "http://picturepost-dev.sr.unh.edu";
    String host = getDEW().getPicturePostHost();
   
    HttpGet httpget = new HttpGet(url);
    HttpResponse response;
    String s;
    JSONArray json = null;
    
    try {
      response = httpclient.execute(httpget);
      s = getResponseContentString(response);
      json = new JSONArray(s);
      log(json.toString());
    } catch (ClientProtocolException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    } catch (JSONException e) {
      e.printStackTrace();
    }

    if (json != null) {
      try {
        JSONObject jObject = json.getJSONObject(0);
        JSONArray orientationsArray = (JSONArray) jObject.get("orientations");
        for (int i = 0; i < orientationsArray.length(); i++) {
          
          String orientationStr = (String) orientationsArray.get(i);
          String imageURL = host + "/app/GetPicture?pictureSetId=" + pictureSetId + "&orientation=" + orientationStr + "&size=medium";
          
          log("fetchImages(String): image url: " + imageURL);

          InputStream is = (InputStream) fetch(imageURL);
          Bitmap bitmap = BitmapFactory.decodeStream(is);
          if (bitmap == null) continue;
          
          if (orientationExists(i)) {
            getNewFile(i).delete();
          }
          
          FileOutputStream out = new FileOutputStream(getNewFile(i));
          bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
          out.close();
          
          bitmap.recycle();
          if (!orientationStr.equalsIgnoreCase("up")) {    /// right now there's no room for this guy, we'll fix that though...
            getDEW().setCurrentPicture(getNewFile(i).getAbsolutePath(), i, i*45, true);
          }
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
      
    } else {
      log("JSON was null");
    }
  }
	
  public static void downloadImages() {
	  removeFiles();
	  getDEW().removeImages();
	    
		DefaultHttpClient httpclient = new DefaultHttpClient();
		
		String host = getDEW().getPicturePostHost();
		
		String url = host + "/app/GetPost?postId=" + getDEW().getPostID();
		log("Getting: " + url);
		HttpGet httpget = new HttpGet(url);
		HttpResponse response;
		String s;
		JSONArray json = null;

		try {
			response = httpclient.execute(httpget);
			s = getResponseContentString(response);
			json = new JSONArray(s);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		if (json == null) {
		  log("Error: expected a json object and didn't get one, returning now.");
		  return;
		}
		
		log(json.toString());
		
		Integer pictureSetId = null;
		
		try {
		  JSONObject jObj = json.getJSONObject(0);
		  pictureSetId = (Integer) jObj.get("referencePictureSetId");
		  if (pictureSetId == null) {
		    log("Failed to get the 'referencePictureSetId' from this JSONObject, bye.");
		    return;
		  } else {
        log("Here's the canonical picture set id: " + pictureSetId.intValue());
		  }
		} catch (Exception e) {
		  e.printStackTrace();
		}
		
		url = host + "/app/GetPictureSet?pictureSetId=" + pictureSetId.intValue();
		httpget = new HttpGet(url);
		response = null;
		s = null;
		json = null;
		
		try {
      response = httpclient.execute(httpget);
      s = getResponseContentString(response);
      json = new JSONArray(s);
      log(json.toString());
    } catch (ClientProtocolException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    } catch (JSONException e) {
      e.printStackTrace();
    }

		if (json != null) {
		  try {
		    JSONObject jObject = json.getJSONObject(0);
		    JSONArray orientationsArray = (JSONArray) jObject.get("orientations");
		    for (int i = 0; i < orientationsArray.length(); i++) {
		      String orientationStr = (String) orientationsArray.get(i);
		      String imageURL = host + "/app/GetPicture?pictureSetId=" + pictureSetId.intValue() + "&orientation=" + orientationStr + "&size=medium";
		      log("image url: " + imageURL);

          InputStream is = (InputStream) fetch(imageURL);
          Bitmap bitmap = BitmapFactory.decodeStream(is);
          if (bitmap == null) continue;
          
          if (orientationExists(i)) {
            getNewFile(i).delete();
          }
          
          FileOutputStream out = new FileOutputStream(getNewFile(i));
          bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
          out.close();
          
          bitmap.recycle();
          if (!orientationStr.equalsIgnoreCase("up")) {    /// right now there's no room for this guy, we'll fix that though...
            getDEW().setCurrentPicture(getNewFile(i).getAbsolutePath(), i, i*45, true);
          }
		    }
		  } catch (Exception e) {
		    e.printStackTrace();
		  }
		} else {
			log("JSON was null");
		}
	}	
	
  

	public static Object fetch(String address) throws MalformedURLException,IOException {
		URL url = new URL(address);
		Object content = url.getContent();
		return content;
	}


	public static String getResponseContentString(HttpResponse response) {
		StringBuffer sb = new StringBuffer();
		HttpEntity entity = response.getEntity();
		if (entity != null) {
			InputStream is;
			try {
				is = entity.getContent();
				BufferedReader br = new BufferedReader(new InputStreamReader(is));
				int bufChar;
				while ((bufChar = br.read())!=-1){
					sb.append((char)bufChar);
				} 
			} catch (IllegalStateException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}			
		}

		return sb.toString();
	}

}
